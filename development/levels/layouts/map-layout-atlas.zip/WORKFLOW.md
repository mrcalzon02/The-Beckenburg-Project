# Layout planning checkpoints

21 October 2026. User authorized all proposed maps, including campaign outdoor and distant locations, to receive rough layouts with individual commits before refinement.

Each completed entry means JSON bounds, named spaces, route reservations, two graph cycles, three ritual areas, van placement, story/system notes, measured SVG and OBJ volume study have been authored and planning-checked. It does **not** mean a playable graybox, collision pass, measured escape timing or completed campaign.

Unrelated in-progress scene, library, lighting and preview edits were present at intake and are excluded from layout commits. Concurrent remote character work is reconciled separately without replacing these local edits.

## Completed checkpoints

- **HOUSE / The Briar House**: 15 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **FARMHOUSE / Hollowmere Farm**: 15 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **SCHOOL / Ravenshade School**: 15 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **MANSION / Blackthorn Manor**: 17 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **PRISON / Beckenburg Penitentiary**: 16 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **ASYLUM / St. Dymphna Hospital**: 16 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **ACADEMY / St. Alban Academy**: 17 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **COLLEGE / Beckenburg College**: 17 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **CHURCH / St. Brigid Parish**: 15 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-01 / Blackpine Logging Camp**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-02 / Camp Hollow Creek**: 13 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-03 / Red Mesa Ancestral Caves**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-04 / Widow's Peak Fire Lookout**: 13 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-05 / Dead Man's Claim**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-06 / Drowned Fisherman's Wharf**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-07 / Saint Bartholomew's Forgotten Cemetery**: 13 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-08 / Northwatch Research Station**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-09 / Blackwater Hydroelectric Dam**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-10 / Monastery of Ashen Bells**: 17 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-11 / Mourning Marsh**: 13 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-12 / Gallows Pass Railway**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **WLD-13 / Greywater Cannery**: 14 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.
- **CASTLE / Castle Beckenburg**: 23 space reservations authored. Planning validation passed; runtime geometry and physical access remain pending.

## Full planning pass / visual QA

All 23 packets passed the complete roster check, bounds/overlap checks, connected route graph, two declared cycles per map, three distinct clear rite reservations and van-ramp transform checks. Rendered all 23 SVGs to PNG and inspected the complete contact sheet plus full House, Red Mesa and Marsh plans. Corrected ground support drawing order, moved original exterior labels out of building footprints, retained exact existing door centres/widths and stair endpoints, and routed adjacent-space connections through shared thresholds. Corrected the monastery gatehouse/cloister overlap. These remain planning checks, not runtime navigation acceptance.

The local browser preview could not reach the Windows localhost server, so no browser interaction acceptance is claimed. The portable HTML atlas and rendered PNGs are delivered directly. Package CRC and per-file SHA-256 checks cover the archive. No Java runtime or site unlock changed in the planning pass.

## Next unfinished work after the complete roster

User requested reuse-first construction, normal building sizes with large exposed places, sparse outdoor shrub hiding and real crouching. Follow [REUSE_BUILD_ORDER.md](REUSE_BUILD_ORDER.md). Blackpine is the first build: compact timber/industrial structures, exposed yard and transferable woodland/refuge systems. Crouching was absent at intake; existing hiding was cupboard-only. Implement and verify posture and cover rather than describing a lowered camera as completed crouch collision.
