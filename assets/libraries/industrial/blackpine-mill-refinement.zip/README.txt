Beckenburg original working-place kit, 22 October 2026.
12 static scenery models. CC0-1.0 original geometry and procedural textures.
GLBs use metre dimensions, Y up and a floor pivot. Editable Blender sources are Z up.
Circular headrig and raised log carriage are aligned in the included original assembly.
No powered cutting, moving log carriage, inventory or healing simulation.
The complete map uses separately licensed scenery and is not included in this CC0 archive.
