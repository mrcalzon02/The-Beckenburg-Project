package org.beckenburg;

import java.util.Random;
final class SurfaceParity {
    public static void main(String[] args) {
        var random=new Random(908734);
        int count=0;
        for(int shell=0;shell<8;shell++){
            double radius=.1+random.nextDouble()*12,shoulder=.2+random.nextDouble()*5;
            var a=new SafeAreaBarrier.Volume(3,0,-1,radius,shoulder,shoulder+.1+random.nextDouble()*4);
            for(int i=0;i<300000;i++){
                double angle=random.nextDouble()*Math.PI*2;
                double radial=switch(i%7){case 0->radius;case 1->Math.nextUp(radius);case 2->Math.nextDown(radius);default->random.nextDouble()*2*radius;};
                double x=radial*Math.cos(angle),z=radial*Math.sin(angle);
                double y=switch(i%11){case 0->0;case 1->shoulder;case 2->Math.nextDown(shoulder);case 3->Math.nextUp(shoulder);default->random.nextDouble()*a.height()*2-.5;};
                double dx=random.nextDouble()*2-1,dz=random.nextDouble()*2-1,dy=i%9==0?0:random.nextDouble()*2-1;
                double ref=RefSurface.surface(a,x,y,z,dx,dy,dz);
                double value=SafeAreaHaze.surface(a,x,y,z,dx,dy,dz);
                if(Double.doubleToLongBits(ref)!=Double.doubleToLongBits(value))
                    throw new AssertionError("Range "+ref+" vs "+value+" at "+i);
                count++;
            }
        }
        System.out.println("PASS "+count+" raw-bit analytic hit distances across shell sizes, shoulder/radius boundaries and inside/outside rays");
    }
}
