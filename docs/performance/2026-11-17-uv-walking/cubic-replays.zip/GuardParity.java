package org.beckenburg;
import java.lang.invoke.*;
import java.util.Random;
class GuardParity {
    public static void main(String[] args)throws Throwable{
        var area=new SafeAreaBarrier.Volume(23.134,0,36.0,5,1.8,4.5);
        var privateAccess=MethodHandles.privateLookupIn(SafeAreaHaze.class,MethodHandles.lookup());
        var method=privateAccess.findStatic(SafeAreaHaze.class,"shade",MethodType.methodType(int.class,
            int.class,SafeAreaBarrier.Volume.class,double.class,double.class,double.class,double.class));
        var random=new Random(72073);
        for(int i=0;i<3000000;i++){
            double x=random.nextDouble()*100-50,y=random.nextDouble()*4.5,z=random.nextDouble()*100-50,t=random.nextDouble()*2000;
            int rgb=random.nextInt(1<<24);
            rgb=switch(i%5){case 0->(rgb&0xffff)|0xa90000;case 1->(rgb&0xff00ff)|0xdf00;case 2->rgb|0xff;default->rgb;};
            int before=OpacityParity.blend(rgb,OriginalOpacity.opacity(area,x,y,z,t));
            int after=(int)method.invokeExact(rgb,area,x,y,z,t);
            if(before!=after)throw new AssertionError("RGB mismatch at "+i);
        }
        System.out.println("PASS 3000000 exact guarded shader colors, including quantization boundaries");
    }
}
