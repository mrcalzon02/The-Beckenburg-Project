package org.beckenburg;

import java.util.Random;
public class OpacityParity{
 static int blend(int rgb,double a) {
  int out=0;
  for(int i=0;i<24;i+=8)out|=((int)(((rgb>>i)&255)*(1-a)+((0xa9dfff>>i)&255)*a))<<i;
  return out;
 }
 public static void main(String[] args){
  var area=new SafeAreaBarrier.Volume(23.134,0,36,5,1.8,4.5);
  var rng=new Random(72073);
  int differentAlphas=0,differentPixels=0;double max=0;
  for(int i=0;i<3000000;i++){
   double x=rng.nextDouble()*100-50,y=rng.nextDouble()*4.5,z=rng.nextDouble()*100-50,t=rng.nextDouble()*2000;
   double before=OriginalOpacity.opacity(area,x,y,z,t),after=SafeAreaHaze.opacity(area,x,y,z,t);
   if(Double.doubleToLongBits(before)!=Double.doubleToLongBits(after))differentAlphas++;
   int rgb=rng.nextInt(1<<24);
   if(blend(rgb,before)!=blend(rgb,after))differentPixels++;
   max=Math.max(max,Math.abs(before-after));
  }
  System.out.println("samples=3000000 different_alpha="+differentAlphas+" different_blended_rgb="+differentPixels+" max_alpha_error="+max);
 }
}
