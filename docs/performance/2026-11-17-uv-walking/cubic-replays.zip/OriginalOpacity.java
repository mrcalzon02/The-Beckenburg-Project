package org.beckenburg;
final class OriginalOpacity {
    static double opacity(SafeAreaBarrier.Volume a,double wx,double localY,double wz,double clock){
        double rise=Math.max(0,Math.min(1,localY/a.shoulder()));
        double smooth=rise*rise*(3-2*rise),fade=1-.78*smooth;
        if(localY>a.shoulder()){
            rise=Math.max(0,Math.min(1,(localY-a.shoulder())/(a.height()-a.shoulder())));
            smooth=rise*rise*(3-2*rise);fade=.002+.218*(1-smooth)*(1-smooth);
        }
        // Broad clouds slide through finer, curling wisps; coordinates remain world-anchored.
        double drift=Math.sin(wx*.73+wz*.45-localY*.85+clock*.43);
        double broad=.5+.5*Math.sin(wx*1.15+wz*.62+localY*1.4-clock*.68+drift*.9);
        double wisps=Math.pow(.5+.5*Math.sin(wz*2.2-wx*.8-localY*2.7+clock*1.06+drift),3);
        double mist=.055+.15*broad+.055*wisps;
        return fade*mist+.045*Math.exp(-Math.max(0,localY)*4);
    }
}
