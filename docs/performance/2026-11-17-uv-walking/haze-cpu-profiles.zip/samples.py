"""Summarize JDK Flight Recorder execution samples on the sanctuary shader call stack."""
import collections
import json
import sys
from pathlib import Path

def summarize(path):
    events = json.loads(path.read_text())["recording"]["events"]
    threads = collections.Counter()
    methods = collections.Counter()
    lines = collections.Counter()
    kinds = collections.Counter()
    for event in events:
        kinds[event["type"]] += 1
        if event["type"] not in ("jdk.ExecutionSample", "jdk.NativeMethodSample"):
            continue
        values = event["values"]
        trace = values.get("stackTrace")
        if not trace:
            continue
        frames = [f for f in trace["frames"] if f["method"]["type"]["name"] == "org/beckenburg/SafeAreaHaze"]
        if not frames:
            continue
        frame = frames[0]
        method = frame["method"]["name"]
        methods[method] += 1
        lines[f"{method} line {frame['lineNumber']}"] += 1
        threads[values["sampledThread"]["javaName"]] += 1
    return {"event_counts": dict(kinds), "samples_with_shader": sum(methods.values()),
            "innermost_shader_method": dict(methods.most_common()),
            "innermost_shader_line": dict(lines.most_common()),
            "shader_threads": dict(threads.most_common())}

if __name__ == "__main__":
    print(json.dumps(summarize(Path(sys.argv[1])), indent=2))
