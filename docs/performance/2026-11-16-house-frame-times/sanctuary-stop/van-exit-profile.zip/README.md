# Residual cost while exiting the House van

The local candidate applies `directional-cull.patch` after the four-lane `shading.patch`. It uses the same 30 ms repeating viewport timer in both arms. `stage.patch` instruments the same scene renderer in both arms. The patch affects the sanctuary raster's near-plane fallback.

For the House van, the authored volume is centered at (23.134, 0, 36.0), radius 5.0. All eight first outward crossings of the four-lane/repeating30 physical run (43993545950) ended at (18.11, 1.62, 36.25), yaw −π/2 and pitch −0.08. Those eight physical interval ends spent 55.7–71.1 ms in aggregate post-geometry work. The following attribution uses local CPU/llvmpipe.

The renderer casts rays `dx = -u·cos(yaw) + (cos(pitch) - v·sin(pitch))·sin(yaw)` and `dz = u·sin(yaw) + (cos(pitch) - v·sin(pitch))·cos(yaw)`. The variables u and v are centered screen coordinates scaled by the focal length. For the X test, the ray's signed X velocity away from the box is at least

    sign(eyeX-centerX)·cos(pitch)·sin(yaw)
    − |cos(yaw)|·width/(2·focal)
    − |sin(pitch)·sin(yaw)|·height/(2·focal).

If the eye is already outside an X face, and this lower bound is positive for the whole viewport, every ray moves further from that face for all positive distances. No ray can intersect the enclosing box or the optical shell. The Z test uses the corresponding Z direction. Full viewport extents rather than the smaller pixel-center extents and conservative margins of 1e-8 and 1e-10 protect the boundaries. The helper runs only when the original projected box straddles the near plane.

`CrossingReview.java` replays the observed preceding and outer poses, using deterministic colors and mixed near/far scene depths, then compares all output pixels and verifies the raw depth under changing occluders and view-dependent cache reuse. Its 2,400 randomized views cover all four sides, near-boundary positions, 50–120-degree fields of view and inward/outward/grazing orientations. A further 300 frames repeat departures and arrivals with changing depths and held clocks. Both Java 17 runs passed. The source constructs the authored shape using the real House map. For its control and guard classes, rename `SafeAreaHaze` in the four-lane source to `ControlHaze`, and rename the patched four-lane source to `GuardHaze`. Compile those classes and the probe with the game's Java 17 classpath. Invoke `org.beckenburg.CrossingReview <output-csv>`. The probe alternates which implementation runs first in each of 60 measured pairs after 15 warmup pairs.

The profile/ subdirectories retain fresh JVMs on Mesa llvmpipe. `high-solo` and `control-2-solo` are controls. `guarded-1-solo` and `guarded-2-solo` use the directional guard. All ran the same House test driver with the sanctuary stop enabled. The second guarded process captured the crossing but later timed out while returning, leaving its full route and phase gaps unverified. `join-stages.py` extracts the stage records and joins complete moving traces by pose and monotonic time. `first-crossings.csv` keeps completed-panel gaps and enclosing distinct-GL-frame gaps separate. The first control reused a GL ID on the crossing callback. The guard is a local experiment pending matched physical measurement.
