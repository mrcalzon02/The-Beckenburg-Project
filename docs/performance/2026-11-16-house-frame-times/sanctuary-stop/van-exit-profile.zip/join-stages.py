"""Join each real House route's recorded outward crossing to its last completed renderer diagnostic."""
from pathlib import Path
import csv

root=Path(__file__).resolve().parent
names=['high-solo','guarded-1-solo','control-2-solo','guarded-2-solo']
cols='render_finish_ns camera_x eye camera_z yaw pitch clock sprites_ns distance_ns weather_ns van_and_safe_area_ns hiding_ns psx_ns graphics_effects_ns room_and_haunt_ns van_and_safe_area_shaded_px total_safe_area_shaded_px render_width'.split()
report=[]
for run in names:
    directory=root/'profile'/run
    rc=int((directory/'exit-code.txt').read_text())
    lines=[l[6:].split(',') for l in (directory/'console.log').read_text().splitlines() if l.startswith('CROSS,')]
    assert lines and all(len(l)==len(cols) for l in lines)
    with (directory/'stage.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(cols);writer.writerows(lines)
    if rc:
        event=next(dict(zip(cols,r)) for r in lines if r[1]=='18.1100')
        report.append([run,rc,event['render_width'],'',event['camera_x'],event['eye'],event['camera_z'],
                       round(int(event['van_and_safe_area_ns'])/1e6,4),event['van_and_safe_area_shaded_px'],'','','','',''])
        continue
    frames=list(csv.DictReader((directory/'frames.csv').open()))
    moving=[r for r in frames if r['phase']=='moving']
    a,b=next((a,b) for a,b in zip(moving,moving[1:]) if a['inside_sanctuary']=='true' and b['inside_sanctuary']=='false')
    end=int(b['time_ns'])
    candidates=[dict(zip(cols,l)) for l in lines if float(l[1])==float(b['x']) and int(l[0])<=end]
    event=max(candidates,key=lambda r:int(r['render_finish_ns']))
    stamp=int(event['render_finish_ns'])
    assert int(a['time_ns'])<stamp<=end and event['van_and_safe_area_shaded_px']=='0'
    advances=[]
    for frame in moving:
        fid=int(frame['composited_gl_frame_id'])
        if fid<0 or (advances and advances[-1][0]==fid):continue
        advances.append((fid,int(frame['time_ns'])))
    bounded=next((n2-n1 for (_,n1),(_,n2) in zip(advances,advances[1:]) if n1<end<=n2),None)
    report.append([run,rc,int(b['width']),int(b['height']),b['x'],b['eye'],b['z'],
                   round(int(event['van_and_safe_area_ns'])/1e6,4),int(event['van_and_safe_area_shaded_px']),
                   round((end-int(a['time_ns']))/1e6,4),round(int(b['effects_ns'])/1e6,4),
                   int(b['composited_gl_frame_id'])-int(a['composited_gl_frame_id']),round((end-stamp)/1e6,4),round(bounded/1e6,4) if bounded else ''])
with (root/'first-crossings.csv').open('w',newline='') as f:
    writer=csv.writer(f);writer.writerow('run exit_code width height x eye z sanctuary_pass_ms sanctuary_shaded_pixels end_gap_adjacent_callbacks_ms all_effects_ms gl_id_advance stage_end_to_panel_stamp_ms enclosing_distinct_gl_gap_ms'.split());writer.writerows(report)
