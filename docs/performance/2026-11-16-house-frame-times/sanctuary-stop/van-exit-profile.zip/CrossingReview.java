package org.beckenburg;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Use the authored House van position and the exact physical crossing pose. */
public class CrossingReview {
    private static final int WIDTH=960, HEIGHT=540;
    private static final int[] base=new int[WIDTH*HEIGHT], a=base.clone(), b=base.clone();
    private static final double[] depth=new double[base.length];
    private static final List<SafeAreaBarrier.Volume> van=List.of(SafeAreaBarrier.van(new HouseMap(HouseMap.Site.HOUSE).van()));
    private static final double FOCAL=(SceneRenderer.W*.5)/Math.tan(Math.toRadians(93.0/2))*HEIGHT/SceneRenderer.H;
    private static void exactCross(int trial,PrintWriter out,boolean guardFirst) {
        var control=new ControlHaze.RayCache();var guard=new GuardHaze.RayCache();
        final double z=36.25,yaw=-Math.PI/2,pitch=-.08;
        for (int step=0;step<3;step++) {
            double x=step==2?18.11:18.42,eye=step==2?1.62:1.636,clock=10+.1*step;
            System.arraycopy(base,0,a,0,base.length);System.arraycopy(base,0,b,0,base.length);
            int ca=0,cb=0;long wa=0,wb=0;
            for(int j=0;j<2;j++){
                long t=System.nanoTime();
                if((j==0)==guardFirst){
                    cb=GuardHaze.draw(b,depth,WIDTH,HEIGHT,FOCAL,x,eye,z,yaw,pitch,clock,van,guard);
                    wb=System.nanoTime()-t;
                }else{
                    ca=ControlHaze.draw(a,depth,WIDTH,HEIGHT,FOCAL,x,eye,z,yaw,pitch,clock,van,control);
                    wa=System.nanoTime()-t;
                }
            }
            if(ca!=cb||!Arrays.equals(a,b))throw new AssertionError("mismatch at x="+x);
            if(step==2) {
                if(ca!=0||!Arrays.equals(base,a))throw new AssertionError("outer crossing actually shaded");
                if(out!=null)out.printf(Locale.ROOT,"%d,%.2f,%d,%d,%d,%08x,%08x%n",trial,x,wa,wb,ca,Arrays.hashCode(a),Arrays.hashCode(depth));
            }
        }
    }
    public static void main(String[] args) throws Exception {
        Random random=new Random(10700);
        for(int i=0;i<base.length;i++){base[i]=random.nextInt(1<<24);depth[i]=i%11==0?Double.POSITIVE_INFINITY:random.nextDouble()*60;}
        int sourceDepth=Arrays.hashCode(depth);
        var borderA=van.get(0);
        System.out.println("volume="+borderA+" focal="+FOCAL);
        for(int n=0;n<15;n++)exactCross(n,null,n%2==0);
        try(var out=new PrintWriter(args[0])){
            out.println("pair,camera_x,control_ns,guard_ns,shaded_pixels,rgb_hash,depth_hash");
            for(int n=0;n<60;n++)exactCross(n,out,n%2==0);
        }
        if(Arrays.hashCode(depth)!=sourceDepth)throw new AssertionError("depth changed");
        // Sweep sides/corners, including inward rays, grazing views and near-surface eyes.
        final int w=71,h=45;int[] orig=new int[w*h],u=new int[w*h],v=new int[w*h];
        double[] d=new double[w*h];
        for(int i=0;i<orig.length;i++){orig[i]=random.nextInt(1<<24);d[i]=i%3==0?Double.POSITIVE_INFINITY:random.nextDouble()*20;}
        int changed=0, same=0;var area=van.get(0);var gc=new GuardHaze.RayCache();var cc=new ControlHaze.RayCache();
        final int depthHash=Arrays.hashCode(d);
        for(int n=0;n<2400;n++){
            boolean side=(n&1)==0;
            double near=(n%5==0?random.nextDouble()*1e-7:random.nextDouble()*1.8-.9);
            double primary=(area.radius()+near)*(n%4<2?1:-1);
            double offset=(random.nextDouble()*2-1)*area.radius()*1.2;
            double x=area.x()+(side?primary:offset), z=area.z()+(side?offset:primary);
            double yaw=random.nextDouble()*2*Math.PI-Math.PI,pitch=(random.nextDouble()*2-1)*1.4;
            double focal=(w*.5)/Math.tan(Math.toRadians((50+random.nextDouble()*70)/2)),eye=area.y()+random.nextDouble()*7-.5;
            System.arraycopy(orig,0,u,0,u.length);System.arraycopy(orig,0,v,0,v.length);
            double clock=n*.04;
            int first=ControlHaze.draw(u,d,w,h,focal,x,eye,z,yaw,pitch,clock,van,cc);
            int second=GuardHaze.draw(v,d,w,h,focal,x,eye,z,yaw,pitch,clock,van,gc);
            if(first!=second||!Arrays.equals(u,v)||Arrays.hashCode(d)!=depthHash)throw new AssertionError("sweep "+n);
            if(first>0)changed++;else same++;
        }
        System.out.printf("PASS: 2400 images compared, %d with visible haze and %d with zero shaded pixels%n",changed,same);
        // Return to the exact inside pose after leaving it. A skipped draw retains
        // a different cache history, while the next frame still sees live depth/clock.
        gc=new GuardHaze.RayCache();cc=new ControlHaze.RayCache();
        for(int n=0;n<300;n++){
            boolean outside=n%6>=3;
            double xx=outside?18.11:18.42,eye=outside?1.62:1.636;
            for(int i=0;i<d.length;i++)d[i]=(i+n)%7==0?0.07:Double.POSITIVE_INFINITY;
            long[] bits=new long[d.length];
            for(int i=0;i<d.length;i++)bits[i]=Double.doubleToRawLongBits(d[i]);
            System.arraycopy(orig,0,u,0,u.length);System.arraycopy(orig,0,v,0,v.length);
            int first=ControlHaze.draw(u,d,w,h,40,xx,eye,36.25,-Math.PI/2,-.08,(n/12)*.1,van,cc);
            int second=GuardHaze.draw(v,d,w,h,40,xx,eye,36.25,-Math.PI/2,-.08,(n/12)*.1,van,gc);
            if(first!=second||!Arrays.equals(u,v))throw new AssertionError("reentry "+n);
            for(int i=0;i<d.length;i++)if(bits[i]!=Double.doubleToRawLongBits(d[i]))throw new AssertionError("depth "+n);
        }
        System.out.println("PASS: 300 repeated exits and re-entry frames with changing occluders and a held scene clock");

    }
}
