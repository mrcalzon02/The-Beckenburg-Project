# First two poses inside the House van

The eight shipped-code observations below come from the four solo and four three-seat candidate trials of GTX run [43993545950](https://github.com/mrcalzon02/Dens-Mortis/actions/runs/43993545950). These trials used the exact four-lane sanctuary and 30 ms render timer later published at eaa32a3. The first two host steps move from x=20.90 to 20.59 and 20.28, with z=36.25 and eye=2.12. The table uses same-phase completion intervals with unique consumed OpenGL IDs. All 16 first-draw observations at those two poses had zero fresh lighting rays.

| Inside walking frames | n | Median completed-frame interval | Median total renderer | Median post-geometry | Median geometry |
|---|---:|---:|---:|---:|---:|
| First moved pose, first render | 8 | 76.10 ms | 52.53 ms | 49.31 ms | 1.88 ms |
| First moved pose, second render | 8 | 31.00 | 19.95 | 16.86 | 1.89 |
| Second moved pose, first render | 8 | 57.50 | 49.03 | 46.09 | 1.91 |
| Second moved pose, second render | 7 | 29.37 | 16.28 | 13.48 | 1.59 |
| Later inside poses, first render | 48 | 40.55 | 18.52 | 15.48 | 1.88 |
| Later inside poses, second render | 48 | 21.24 | 9.06 | 6.06 | 1.86 |

One 960×540 Linux Mesa instrumented House solo walk isolated the CPU effect inside the panel's post-geometry stage. At x=20.59 the first draw spent 76.9 of 78.5 ms in the primary van dome, with 100.8 ms of aggregated thread CPU across four lanes. The next sampled draw had the same pose and clock but used 69.1 of 70.4 ms for the same dome in one lane. Hiding volumes took 0.1 ms on both draws. The new GL depth image exposed 306,649 visible haze pixels compared with 241,453 at the preceding completion. At x=20.28 the first primary-dome draw took 19.7 ms, and the next took 9.0 ms. Haze work depends on the currently returned GL depth even when the CPU observer and animation clock are unchanged.

During the first x=20.59 kernel the JDK 17 C2 log recorded three unstable-branch traps at the finite depth check in the cached path. The next draw recorded a trap in the cached negative-depth predicate. In that local execution these events overlap long measured scans. Windows recorded aggregate stages only, and has no such JIT-event or per-lane capture. The phase duration minus the current render cost includes scheduling and work outside that render.

Four independent JVMs replayed the same 960×540 material inputs, including a one-render delay between the new pose and its new depth image. Each exercised the two initial poses after 300 fixed-camera frames, then twice more within the same JVM. For the unmodified optics, first and second draws at each of the first two poses took 17.20 ms median, 52.62 ms maximum in fresh runs (16 samples), versus 11.24 and 18.62 ms on the repeated walks (32 samples). The capture uses real software-rendered House RGB/depth and a modeled one-frame GL image delay. It holds the initial eye height across the route; that matches the two initial poses under investigation. These are shader-only local measurements. A second full GL route in the same JVM did not complete under shared host RAM, so no warmed full-panel claim is made.

Making the first same-clock repeated pose use four lanes lowered warmed kernel cost but increased the *first* repeat from 19.8–28.8 to 57.9–94.3 ms in all four process pairs. Delaying all population until a repeated view removed the first-new-pose spike in three of four process pairs but regressed whole-walk median shader time in all four. Removing the finite depth check alone preserved the image but slowed the warmed kernel.

A geometric shortcut can skip the cylinder solve for a rising ray starting strictly above the shoulder, or skip the cap solve for a falling ray starting strictly below. Those rays are on the wrong side of that surface's full vertical extent. It preserved the exact doubles in 2,000,000 ray tests, 1,046,828 of which took the shortcut, and matched 6,889,880 complete RGB/raw-depth samples, including arbitrary depth values and changing occluders. Cold shader walking p95 improved in three of four local four-lane pairs. First-two-pose scalar crossover timing was mixed, as were some four-lane runs. These diagnostics provide no measured physical reason to integrate a further change.

Files include the Windows per-frame split, the usable local stage trace and extracted compilation events, raw replay tables, sources and compiler bytecode. No new physical run was dispatched for this attribution.
