package org.beckenburg;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.lang.management.ManagementFactory;
public class LagKernel {
    static final int W=960,H=540,S=W*H;
    record Inputs(double x,double eye,double z,double yaw,double pitch,int[] color,double[] depth){}
    public static void main(String[] args)throws Exception{
        boolean change=args[1].equals("parallel");
        double focal;List<SafeAreaBarrier.Volume> areas;
        var views=new Inputs[9];
        try(var f=new DataInputStream(new BufferedInputStream(Files.newInputStream(Path.of(args[0]))))){
            focal=f.readDouble();
            areas=List.of(new SafeAreaBarrier.Volume(f.readDouble(),f.readDouble(),f.readDouble(),f.readDouble(),f.readDouble(),f.readDouble()));
            for(int i=0;i<9;i++){
                double x=f.readDouble(),eye=f.readDouble(),z=f.readDouble(),yaw=f.readDouble(),pitch=f.readDouble();
                int[] c=new int[S];double[] d=new double[S];
                for(int k=0;k<S;k++)c[k]=f.readInt();
                for(int k=0;k<S;k++)d[k]=f.readDouble();
                views[i]=new Inputs(x,eye,z,yaw,pitch,c,d);
            }
            if(f.read()!=-1)throw new AssertionError("trailing capture");
        }
        var ref=new MainHaze.RayCache();var variant=new LagHaze.RayCache();
        var pixels=new int[S];
        var vm=ManagementFactory.getRuntimeMXBean();
        try(var out=new PrintWriter(args[2])){
            out.println("route,frame,pose,pose_ordinal,clock,begin_uptime_ms,end_uptime_ms,wall_ns,changed,rgb_hash,depth_hash");
            int n=0;
            for(int route=0;route<3;route++){
              for(int frame=-300;frame<32;frame++,n++){
                int pose=frame<0?0:1+frame/4;
                var v=views[pose];
                // The GL image consumed at the first moved render in the live panel is
                // from the preceding position. On the first exact repeat the newly
                // visible rays see the next depth image even under the same host clock.
                var image = views[frame>=0 && frame%4==0 ? pose-1 : pose];
                System.arraycopy(image.color,0,pixels,0,S);
                double clock=(n/3)*.1;
                long start=vm.getUptime(),begin=System.nanoTime();
                int changed=change?LagHaze.draw(pixels,image.depth,W,H,focal,v.x,v.eye,v.z,v.yaw,v.pitch,clock,areas,variant):MainHaze.draw(pixels,image.depth,W,H,focal,v.x,v.eye,v.z,v.yaw,v.pitch,clock,areas,ref);
                long ns=System.nanoTime()-begin,end=vm.getUptime();
                if(frame>=-4)out.printf(Locale.ROOT,"%d,%d,%d,%d,%s,%d,%d,%d,%d,%d,%d%n",route,frame,pose,frame<0?301+frame:frame%4+1,clock,start,end,ns,changed,Arrays.hashCode(pixels),Arrays.hashCode(image.depth));
              }
            }
        }
    }
}
