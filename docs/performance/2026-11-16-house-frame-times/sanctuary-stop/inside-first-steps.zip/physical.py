from pathlib import Path
from zipfile import ZipFile
import csv,io,collections
from statistics import median
from math import ceil
root=Path('../../shading/raw.zip')
C=collections.defaultdict(list)
with ZipFile(root) as z, open('windows-inside.csv','w',newline='') as out:
 w=csv.writer(out)
 w.writerow(['trial','pose_index','held_ordinal','x','eye','z','ending_gl_id','gap_ms','renderer_ms','postgeometry_ms','geometry_ms','ray_count'])
 for path in sorted(x for x in z.namelist() if x.endswith('-candidate/frames.csv')):
  trial=path.split('/')[0]
  rows=list(csv.DictReader(io.TextIOWrapper(z.open(path))))
  poses=[]
  last=None;lastg=None;seen=set();ordinal=0
  for r in rows:
   if r['phase']!='moving':continue
   pose=tuple(r[k] for k in ('x','eye','z','yaw','pitch'))
   if pose!=last:poses.append(pose);ordinal=0;last=pose
   ordinal+=1
   gl=int(r['composited_gl_frame_id']);g=int(r['time_ns'])
   if gl<0 or gl in seen:continue
   gap=None if lastg is None else (g-lastg)/1e6
   seen.add(gl);lastg=g
   if r['inside_sanctuary']!='true' or r['x']=='20.9':continue
   # Windows drives exactly .31 m per accepted step from this spawn.
   group=round((20.9-float(r["x"]))/.31)
   if gap is None:continue
   work=int(r['render_ns'])/1e6;post=int(r['effects_ns'])/1e6;geo=int(r['geometry_ns'])/1e6
   w.writerow([trial,group,ordinal,*pose[:3],gl,round(gap,3),round(work,3),round(post,3),round(geo,3),int(r['shadow_rays'])])
   C[group if group<=2 else 'later',ordinal if ordinal<=2 else '3+'].append((gap,work,post,geo))
for k,v in C.items():
 print(k,len(v),'medians',*[round(median(i),2) for i in zip(*v)],'max post',round(max(x[2] for x in v),2))
