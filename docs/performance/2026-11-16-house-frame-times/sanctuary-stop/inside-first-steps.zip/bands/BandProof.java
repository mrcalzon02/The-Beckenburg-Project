package org.beckenburg;
import java.util.*;
/** The alternate skips only a surface whose full vertical interval is behind an eligible ray. */
public final class BandProof {
 public static void main(String[] args) {
  var rnd=new Random(20261117);int saved=0;
  var area=new SafeAreaBarrier.Volume(23.134,0,36,5,1.8,4.5);
  for(int k=0;k<2_000_000;k++){
   double ox=(rnd.nextDouble()-.5)*16,oz=(rnd.nextDouble()-.5)*16;
   double oy=switch(k%8){case 0->area.shoulder();case 1->Math.nextDown(area.shoulder());case 2->Math.nextUp(area.shoulder());default->(rnd.nextDouble()-.17)*8;};
   double dx=(rnd.nextDouble()-.5)*4,dz=(rnd.nextDouble()-.5)*4,dy=switch(k%11){case 0->0.;case 1->-0.;case 2->Double.MIN_NORMAL;default->(rnd.nextDouble()-.5)*4;};
   double a=MainHaze.surface(area,ox,oy,oz,dx,dy,dz);
   double b=BandHaze.surface(area,ox,oy,oz,dx,dy,dz);
   if(Double.doubleToRawLongBits(a)!=Double.doubleToRawLongBits(b))throw new AssertionError("surface "+k);
   if((oy>area.shoulder()&&dy>=0)||(oy<area.shoulder()&&dy<=0))saved++;
  }
  System.out.println("PASS 2,000,000 raw-double surface comparisons; "+saved+" exercised a vertical cull.");
 }
}
