package org.beckenburg;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.lang.management.ManagementFactory;
public class PairedBandCpu {
    static final int W=960,H=540,S=W*H;
    record Inputs(double x,double eye,double z,double yaw,double pitch,int[] color,double[] depth){}
    public static void main(String[] args)throws Exception{
        boolean change=args[1].equals("band");
        double focal;List<SafeAreaBarrier.Volume> areas;
        var views=new Inputs[9];
        try(var f=new DataInputStream(new BufferedInputStream(Files.newInputStream(Path.of(args[0]))))){
            focal=f.readDouble();
            areas=List.of(new SafeAreaBarrier.Volume(f.readDouble(),f.readDouble(),f.readDouble(),f.readDouble(),f.readDouble(),f.readDouble()));
            for(int i=0;i<9;i++){
                double x=f.readDouble(),eye=f.readDouble(),z=f.readDouble(),yaw=f.readDouble(),pitch=f.readDouble();
                int[] c=new int[S];double[] d=new double[S];
                for(int k=0;k<S;k++)c[k]=f.readInt();
                for(int k=0;k<S;k++)d[k]=f.readDouble();
                views[i]=new Inputs(x,eye,z,yaw,pitch,c,d);
            }
            if(f.read()!=-1)throw new AssertionError("trailing capture");
        }
        var ref=new MainHaze.RayCache();var variant=new BandHaze.RayCache();
        var pixels=new int[S];
        var vm=ManagementFactory.getRuntimeMXBean();
        try(var out=new PrintWriter(args[2])){
            out.println("route,frame,pose,pose_ordinal,control_thread_ns,band_thread_ns,changed,rgb_hash,depth_hash");
            var cpu=ManagementFactory.getThreadMXBean(); cpu.setThreadCpuTimeEnabled(true);
            int[] other=new int[S]; int rotation=Integer.parseInt(args[1]); int n=0;
            for(int route=0;route<3;route++){
              for(int frame=-300;frame<32;frame++,n++){
                int pose=frame<0?0:1+frame/4;
                var v=views[pose];
                // The GL image consumed at the first moved render in the live panel is
                // from the preceding position. On the first exact repeat the newly
                // visible rays see the next depth image even under the same host clock.
                var image = views[frame>=0 && frame%4==0 ? pose-1 : pose];
                System.arraycopy(image.color,0,pixels,0,S);
                double clock=(n/3)*.1;
                System.arraycopy(image.color,0,other,0,S);
                int[] counts=new int[2]; long[] timings=new long[2];
                for(int k=0;k<2;k++){
                    int arm=(k+n+rotation)%2;
                    long t=cpu.getCurrentThreadCpuTime();
                    counts[arm]=arm==0?MainHaze.draw(pixels,image.depth,W,H,focal,v.x,v.eye,v.z,v.yaw,v.pitch,clock,areas,ref):BandHaze.draw(other,image.depth,W,H,focal,v.x,v.eye,v.z,v.yaw,v.pitch,clock,areas,variant);
                    timings[arm]=cpu.getCurrentThreadCpuTime()-t;
                }
                if(counts[0]!=counts[1]||!Arrays.equals(pixels,other))throw new AssertionError("RGB at "+route+"/"+frame);
                if(frame>=-4)out.printf(Locale.ROOT,"%d,%d,%d,%d,%d,%d,%d,%d,%d%n",route,frame,pose,frame<0?301+frame:frame%4+1,timings[0],timings[1],counts[0],Arrays.hashCode(pixels),Arrays.hashCode(image.depth));
              }
            }
        }
    }
}
