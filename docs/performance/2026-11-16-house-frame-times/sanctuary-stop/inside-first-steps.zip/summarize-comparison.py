from pathlib import Path
from statistics import median
from math import ceil
import csv
def near(vals,p): return sorted(vals)[ceil(len(vals)*p)-1]
out=[]
for folder,kind in [('replay','finite'),('lag','parallel'),('stale','stable'),('bands','band')]:
 for trial in range(1,5):
  p=Path(folder)/f'{kind}-{trial}.csv'
  if not p.exists() or not p.stat().st_size:continue
  q=Path(folder)/f'{"main" if folder=="replay" else "control"}-{trial}.csv'
  if not q.exists() or not q.stat().st_size:continue
  b=list(csv.DictReader(q.open()));c=list(csv.DictReader(p.open()))
  if len(c)!=108 or len(b)!=108:continue
  assert all(all(x[k]==y[k] for k in ('route','frame','pose','changed','depth_hash','rgb_hash')) for x,y in zip(b,c))
  for phase in ('cold','warm'):
   for subset in ('first_two_new','first_two_repeated','all_new','all_second','all_steps'):
    metrics=[]
    for cur in (b,c):
     v=[]
     for r in cur:
      if (r['route']=='0')!=(phase=='cold'):continue
      frame=int(r['frame'])
      if frame<0: continue
      if subset=='first_two_new' and frame not in (0,4):continue
      if subset=='first_two_repeated' and frame not in (1,5):continue
      if subset=='all_new' and frame%4!=0:continue
      if subset=='all_second' and frame%4!=1:continue
      v.append(int(r['wall_ns'])/1e6)
     metrics.extend((round(median(v),3),round(near(v,.95),3)))
    out.append([kind,trial,phase,subset,*metrics])
with Path('replay-summary.csv').open('w',newline='') as o:
 q=csv.writer(o)
 q.writerow(['arm','pair','stage','selection','control_p50_shader_ms','control_p95_shader_ms','candidate_p50_shader_ms','candidate_p95_shader_ms'])
 q.writerows(out)
for row in out:
 if row[0] in ('stable','band') and row[2]=='cold' and row[3] in ('first_two_new','all_steps'):
  print(*row)
