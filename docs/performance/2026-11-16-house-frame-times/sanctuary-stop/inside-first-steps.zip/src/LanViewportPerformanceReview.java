package org.beckenburg;

import java.awt.event.KeyEvent;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.JComponent;
import javax.swing.RepaintManager;
import javax.swing.SwingUtilities;

/**
 * Measure the live hunter panel's timer-driven world completions and TCP arrivals.
 * One offscreen viewport, two hunters and a human-role ghost on loopback, or a solo case.
 * This observes completed CPU renders, not desktop presentation or physical-network delay.
 * Optional diagnostic: run in its own JVM with isolated VerificationPreferencesFactory.
 */
public final class LanViewportPerformanceReview extends RepaintManager {
    private record Frame(String phase, long time, long compositedFrame, SceneRenderer.FrameDiagnostics cost,
                         double x, double eye, double z, double yaw, double pitch, boolean inside) {}
    private final List<SafeAreaHaze.Visit> visits=new ArrayList<>();
    private final List<Long> hidingTimes=new ArrayList<>();
    private java.lang.reflect.Field lastReadback;
    private record State(String phase, int tick, long received, long delivered) {}
    private final List<Frame> frames = new ArrayList<>();
    private final List<State> states = new ArrayList<>();
    private final CountDownLatch ready = new CountDownLatch(1);
    private final CountDownLatch started = new CountDownLatch(1);
    private final CountDownLatch entered = new CountDownLatch(1);
    private final CountDownLatch warmed = new CountDownLatch(10);
    private final AtomicInteger acceptedSteps = new AtomicInteger();
    private volatile String phase = "warmup";
    private LanWorldPanel panel;
    private SceneRenderer scene;
    private SceneRenderer.FrameDiagnostics previous;
    private boolean inView, finished;
    private double startX, startZ, maxTravel;
    private int moveKey;
    private boolean leftSanctuary;
    private final CountDownLatch returned = new CountDownLatch(1);
    private double beforeStepX, beforeStepZ;
    private SafeAreaBarrier.Volume sanctuary;

    @Override public void addDirtyRegion(JComponent component, int x, int y, int w, int h) {
        super.addDirtyRegion(component, x, y, w, h);
        if (component != panel || scene == null || !inView || finished || !SwingUtilities.isEventDispatchThread()) return;
        var cost = scene.frameDiagnostics();
        if (cost == null || cost == previous) return;
        previous = cost;
        long now = System.nanoTime();
        long composited = -1;
        if (cost.gpuReadbackAvailable()) {
            try {
                var result = (GpuWorldRenderer.Result) lastReadback.get(scene);
                if (result != null) composited = result.frameId();
            } catch (IllegalAccessException e) { throw new AssertionError(e); }
        }
        if (sanctuary == null) sanctuary = SafeAreaBarrier.van(panel.worldMap().van());
        boolean inside = sanctuary.contains(scene.x, scene.eyeHeight, scene.z);
        frames.add(new Frame(phase, now, composited, cost, scene.x, scene.eyeHeight, scene.z,
            scene.yaw, scene.pitch, inside));
        visits.add(SafeAreaHaze.lastVisit);
        hidingTimes.add(SafeAreaHaze.lastHiding);
        if (phase.equals("moving") && !inside) leftSanctuary = true;
        if (phase.equals("returning") && inside && Math.hypot(scene.x - startX, scene.z - startZ) < 1.1) {
            key(opposite(moveKey), false);
            phase = "settling";
            returned.countDown();
        }
        if (phase.equals("moving"))
            maxTravel = Math.max(maxTravel, Math.hypot(scene.x - startX, scene.z - startZ));
        warmed.countDown();
    }

    private void receive(String frame) {
        long received = System.nanoTime();
        String atArrival = phase;
        if (frame.equals("LOBBY|2|HUMAN|3|WAITING")) ready.countDown();
        if (frame.startsWith("INFO|mission started")) started.countDown();
        if (frame.equals("ACCEPT|STEP")) acceptedSteps.incrementAndGet();
        SwingUtilities.invokeLater(() -> {
            if (panel == null || finished) return;
            if (frame.equals("ACCEPT|VIEW3D")) inView = true;
            if (!inView) return;
            if (frame.startsWith("STATE|")) {
                int tick = Integer.parseInt(frame.substring(6, frame.indexOf('|', 6)));
                states.add(new State(atArrival, tick, received, System.nanoTime()));
            }
            panel.onEvent(frame);
            if (frame.startsWith("SITE|HOUSE|")) {
                key(KeyEvent.VK_SPACE, true);
                key(KeyEvent.VK_SPACE, false);
                entered.countDown();
            }
        });
    }

    private void key(int code, boolean down) {
        int id = down ? KeyEvent.KEY_PRESSED : KeyEvent.KEY_RELEASED;
        var event = new KeyEvent(panel, id, System.currentTimeMillis(), 0, code, KeyEvent.CHAR_UNDEFINED);
        if (down) panel.keyPressed(event); else panel.keyReleased(event);
    }

    private int walkKey() {
        var origin = new LevelDefinition.Vec(scene.x, scene.eyeHeight - HunterPosture.STANDING_EYE, scene.z);
        int[] keys = {KeyEvent.VK_W, KeyEvent.VK_S, KeyEvent.VK_A, KeyEvent.VK_D};
        double[] offsets = {0, Math.PI, Math.PI / 2, -Math.PI / 2};
        for (int i = 0; i < keys.length; i++) {
            double yaw = scene.yaw + offsets[i];
            var target = panel.worldMap().resolveMove(origin, origin.x() + .6 * Math.sin(yaw),
                origin.z() + .6 * Math.cos(yaw), HunterPosture.STANDING_HEIGHT);
            if (target != null && Math.hypot(target.x() - origin.x(), target.z() - origin.z()) > .5)
                return keys[i];
        }
        throw new AssertionError("No walkable cardinal direction from the authored van spawn");
    }

    private static int opposite(int key) {
        return switch (key) {
            case KeyEvent.VK_W -> KeyEvent.VK_S;
            case KeyEvent.VK_S -> KeyEvent.VK_W;
            case KeyEvent.VK_A -> KeyEvent.VK_D;
            case KeyEvent.VK_D -> KeyEvent.VK_A;
            default -> throw new IllegalArgumentException("Expected walking key");
        };
    }

    private void measureStop(LanClient client) throws Exception {
        if (!leftSanctuary) throw new AssertionError("Walking never left the sanctuary");
        SwingUtilities.invokeAndWait(() -> { phase = "returning"; key(opposite(moveKey), true); });
        await(returned, "walk back inside the van sanctuary");
        Thread.sleep(900);
        // The panel sends this same host-authoritative command on a held-key tick.
        // Send exactly one, even if several render callbacks precede its acknowledgement.
        int[] step = new int[2];
        SwingUtilities.invokeAndWait(() -> {
            if (!sanctuary.contains(scene.x, scene.eyeHeight, scene.z))
                throw new AssertionError("One-step test must start inside");
            beforeStepX = scene.x;
            beforeStepZ = scene.z;
            double offset = switch (moveKey) {
                case KeyEvent.VK_W -> 0;
                case KeyEvent.VK_S -> Math.PI;
                case KeyEvent.VK_A -> Math.PI / 2;
                case KeyEvent.VK_D -> -Math.PI / 2;
                default -> throw new IllegalArgumentException("Expected walking key");
            };
            step[0] = (int)Math.round(100 * Math.sin(scene.yaw + offset));
            step[1] = (int)Math.round(100 * Math.cos(scene.yaw + offset));
            phase = "stopping";
        });
        client.step(step[0], step[1], false);
        Thread.sleep(5000);
    }

    private void verifyStop() {
        var stopped = frames.stream().filter(f -> f.phase().equals("stopping")).toList();
        if (stopped.isEmpty() || stopped.stream().anyMatch(f -> !f.inside()))
            throw new AssertionError("Stop left the sanctuary or produced no frames");
        Frame last = stopped.get(stopped.size() - 1);
        double travel = Math.hypot(last.x() - beforeStepX, last.z() - beforeStepZ);
        var atRest = stopped.stream().dropWhile(f -> f.x() != last.x() || f.z() != last.z()).toList();
        boolean stable = atRest.stream().allMatch(f -> f.x() == last.x() && f.z() == last.z()
            && f.eye() == last.eye() && f.yaw() == last.yaw() && f.pitch() == last.pitch());
        if (travel < .1 || travel > .5 || !stable || atRest.size() < 12
                || last.time() - atRest.get(0).time() < TimeUnit.SECONDS.toNanos(3))
            throw new AssertionError("Failed one-step stable hold: distance=" + travel + " frames=" + atRest.size());
    }

    private static void await(CountDownLatch latch, String description) throws Exception {
        if (!latch.await(60, TimeUnit.SECONDS)) throw new AssertionError("Timed out awaiting " + description);
    }

    private void write(Path output, long movingNs, int peers, boolean solo) throws Exception {
        Files.createDirectories(output);
        try (var out = Files.newBufferedWriter(output.resolve("frames.csv"))) {
            out.write("phase,time_ns,render_ns,build_ns,geometry_ns,effects_ns,width,height,faces,shadow_rays,composited_gl_frame_id,x,eye,z,yaw,pitch,inside_sanctuary\n");
            for (var frame : frames) {
                var d = frame.cost();
                out.write(String.format(Locale.ROOT, "%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%s,%s,%s,%s,%b%n",
                    frame.phase(), frame.time(), d.totalNs(), d.sceneBuildNs(), d.geometryNs(), d.effectsNs(),
                    d.width(), d.height(), d.faces(), d.lighting().shadowRays(), frame.compositedFrame(),
                    frame.x(), frame.eye(), frame.z(), frame.yaw(), frame.pitch(), frame.inside()));
            }
        }
        try(var out=Files.newBufferedWriter(output.resolve("haze.csv"))){
            out.write("phase,time_ns,inside,x,eye,z,yaw,pitch,render_ns,effects_ns,first_dome_wall_ns,aggregate_lane_cpu_ns,longest_lane_ns,vm_uptime_ms,drawn_pixels,lanes,extent,same_view,same_clock,hiding_ns\n");
            for(int i=0;i<frames.size();i++){
                var f=frames.get(i);var v=visits.get(i);
                if(v!=null)out.write(String.format(Locale.ROOT,"%s,%d,%b,%s,%s,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%b,%b,%d%n",f.phase(),f.time(),f.inside(),f.x(),f.eye(),f.z(),f.yaw(),f.pitch(),f.cost().totalNs(),f.cost().effectsNs(),v.wall(),v.laneCpu(),v.laneWall(),v.uptime(),v.changed(),v.lanes(),v.area(),v.sameView(),v.sameClock(),hidingTimes.get(i)));
            }
        }
        if (!solo) try (var out = Files.newBufferedWriter(output.resolve("state.csv"))) {
            out.write("phase,host_tick,client_received_ns,edt_dispatch_ns\n");
            for (var s : states)
                out.write(String.format(Locale.ROOT, "%s,%d,%d,%d%n", s.phase(), s.tick(), s.received(), s.delivered()));
        }
        String details = String.format(Locale.ROOT, "mode=%s%nrendered_hunters=1%nother_tcp_peers=%d%nviewport=offscreen%nrenderer=%s%nvisible_peer_hunters=%d%nmoving_seconds=%.6f%naccepted_steps=%d%nmax_travel_metres=%.6f%n",
            solo ? "solo" : "multiplayer", solo ? 0 : 2, GpuWorldRenderer.active() == null ? "software" : GpuWorldRenderer.active().rendererDescription(), peers, movingNs / 1e9, solo ? -1 : acceptedSteps.get(), maxTravel);
        if (GpuWorldRenderer.active() != null && frames.stream()
                .filter(f -> f.phase().equals("idle") && f.compositedFrame() >= 0)
                .mapToLong(Frame::compositedFrame).distinct().count() < 2)
            throw new AssertionError("Live panel never composited advancing OpenGL readbacks");
        Files.writeString(output.resolve("summary.txt"), details);
        System.out.print(details);
        if ((!solo && (peers < 1 || states.isEmpty() || acceptedSteps.get() == 0)) || maxTravel < .1 ||
                frames.stream().filter(f -> f.phase().equals("idle")).count() < 2)
            throw new AssertionError("Missing live peer, timed frame, snapshot or host-approved movement");
    }

    private void mount(java.util.function.Supplier<LanWorldPanel> open) throws Exception {
        var field = LanWorldPanel.class.getDeclaredField("renderer");
        field.setAccessible(true);
        lastReadback = SceneRenderer.class.getDeclaredField("lastUsableGpuFrame");
        lastReadback.setAccessible(true);
        SwingUtilities.invokeAndWait(() -> {
            RepaintManager.setCurrentManager(this);
            panel = open.get();
            panel.setSize(640, 360);
            panel.addNotify();
            try { scene = (SceneRenderer) field.get(panel); }
            catch (IllegalAccessException e) { throw new AssertionError(e); }
        });
    }

    private void unmount() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            finished = true;
            if (panel != null) { panel.close(); panel.removeNotify(); }
            RepaintManager.setCurrentManager(null);
        });
    }

    private void measure(Path output, boolean solo, LanClient client) throws Exception {
        await(warmed, "ten scheduled world renders");
        Thread.sleep(4000);
        SwingUtilities.invokeAndWait(() -> phase = "idle");
        Thread.sleep(TimeUnit.SECONDS.toMillis(Integer.getInteger("beckenburg.profile.idleSeconds", 8)));
        SwingUtilities.invokeAndWait(() -> {
            moveKey = walkKey();
            startX = scene.x; startZ = scene.z;
            phase = "moving";
            key(moveKey, true);
        });
        long begin = System.nanoTime();
        Thread.sleep(3000);
        SwingUtilities.invokeAndWait(() -> { key(moveKey, false); phase = "cooldown"; });
        long duration = System.nanoTime() - begin;
        Thread.sleep(500);
        boolean stop = Boolean.getBoolean("beckenburg.profile.sanctuaryStop");
        if (stop) measureStop(client);
        int[] peers = new int[1];
        SwingUtilities.invokeAndWait(() -> { finished = true; peers[0] = panel.visiblePeers(); });
        write(output, duration, peers[0], solo);
        if (stop) verifyStop();
    }

    private void solo(Path output) throws Exception {
        var profile = new ProfileStore(output.resolve("profile.properties"));
        try (var game = new LocalInvestigation(profile, SiteCatalog.Location.HOUSE,
                CharacterVisuals.Hunter.OBSERVER, MissionWeather.Mode.FIXED,
                EvidenceSignals.Weather.CLEAR, 1, null, 0)) {
            try {
                mount(game::openView);
                SwingUtilities.invokeAndWait(() -> {
                    inView = true;
                    key(KeyEvent.VK_SPACE, true);
                    key(KeyEvent.VK_SPACE, false);
                });
                measure(output, true, game.client());
                if (!game.running()) throw new AssertionError("Solo case exited before measurement finished");
            } finally { unmount(); }
        }
    }

    private void run(Path output) throws Exception {
        try (var host = new LanHost("127.0.0.1", 0, GhostIdentity.Type.SPIRIT,
                CustomContract.standard(2), false, true, HouseMap.Site.HOUSE);
             var owner = new LanClient("127.0.0.1", host.port(), false, "FrameReview", "",
                host.localOwnerCredential(), this::receive);
             var guest = new LanClient("127.0.0.1", host.port(), false, "Peer", s -> {});
             var ghost = new LanClient("127.0.0.1", host.port(), true, "Ghost", s -> {})) {
            try {
                mount(() -> new LanWorldPanel(owner));
                owner.ready(); guest.ready(); ghost.ready();
                await(ready, "three ready clients");
                owner.start();
                await(started, "host round start");
                owner.view3D();
                await(entered, "House 3D site");
                measure(output, false, owner);
            } finally {
                unmount();
            }
        }
    }

    public static void main(String[] args) throws Exception {
        var options = new ArrayList<>(List.of(args));
        boolean gpu = options.remove("--gpu"), solo = options.remove("--solo");
        if (options.size() != 1)
            throw new IllegalArgumentException("Usage: [--gpu] [--solo] <trial output directory>");
        java.lang.reflect.Method stop = null;
        if (gpu) {
            var desktop = Class.forName("org.beckenburg.gpu.GpuDesktop");
            var start = desktop.getDeclaredMethod("startGpu"); start.setAccessible(true);
            stop = desktop.getDeclaredMethod("stopReviewGpu"); stop.setAccessible(true);
            start.invoke(null);
        }
        try {
            var review = new LanViewportPerformanceReview();
            var output = Path.of(options.get(0));
            if (solo) {
                review.solo(output);
                var second=output.resolveSibling("warm");
                Files.createDirectories(second);
                new LanViewportPerformanceReview().solo(second);
            } else review.run(output);
        } finally {
            if (stop != null) stop.invoke(null);
        }
    }
}
