package org.beckenburg;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
/** Independent direct .336 optical raster versus the combined shader on large animated views. */
public final class LargeOpticalDepthReview {
    public static void main(String[] args) {
        var cache=new SafeAreaHaze.RayCache();
        var dome=new SafeAreaBarrier.Volume(3,0,4,5,1.8,4.5);
        var other=new SafeAreaBarrier.Volume(2.8,-.2,3.5,3,1.2,3.2);
        long samples=0;
        System.out.println("frame,clock,pixels,count,rgb_hash,depth_hash");
        for(int n=0;n<64;n++){
            int phase=n/8, w=400+(phase>=2?7:0), h=260+(phase>=3?9:0), size=w*h;
            double x=phase>=4?3.11:3, y=1.9, z=phase>=5?4.28:4, yaw=phase>=6?.32:0, pitch=-.08;
            var zones=phase%3==2?List.of(other,dome):List.of(dome,other);
            double clock=(n/4)*.1;
            int[] expected=new int[size],actual=new int[size];
            double[] d=new double[size];long[] raw=new long[size];var rnd=new Random(87651L+n);
            for(int i=0;i<size;i++){
                expected[i]=actual[i]=rnd.nextInt(1<<24);
                d[i]=switch((i+n)%9){
                    case 0->Double.POSITIVE_INFINITY; case 1->-0.0; case 2->.035; case 3->-1;
                    case 4->Double.longBitsToDouble(0x7ff8000000000038L);
                    default->rnd.nextDouble()*11;
                };
                raw[i]=Double.doubleToRawLongBits(d[i]);
            }
            int c0=ShippingHaze.draw(expected,d,w,h,267,x,y,z,yaw,pitch,clock,zones,null);
            int c1=SafeAreaHaze.draw(actual,d,w,h,267,x,y,z,yaw,pitch,clock,zones,cache);
            if(c0!=c1||!Arrays.equals(actual,expected))throw new AssertionError("Output mismatch frame "+n+" px "+Arrays.mismatch(actual,expected));
            for(int i=0;i<size;i++)if(Double.doubleToRawLongBits(d[i])!=raw[i])throw new AssertionError("Raw depth changed "+n+"/"+i);
            System.out.println(n+","+clock+","+size+","+c1+","+Arrays.hashCode(actual)+","+Arrays.hashCode(raw));samples+=size;
        }
        System.err.println("PASS "+samples+" exact live depth/color samples at large multi-lane resolutions");
    }
}
