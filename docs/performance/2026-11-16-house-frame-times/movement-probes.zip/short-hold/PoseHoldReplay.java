package org.beckenburg;
import java.nio.file.*;
import java.io.*;
import java.lang.management.*;
import java.util.*;
/** Reads eight full RGB/depth captures made from live House van poses. */
public final class PoseHoldReplay {
    static final int W=640,H=360;
    record Eye(double x,double y,double z,double yaw,double pitch){}
    record View(Eye e,int[] rgb,double[] depth,int hash){}
    static View[] views=new View[8];
    static List<SafeAreaBarrier.Volume> areas;
    static double focal;
    static final int[][] rgb=new int[3][W*H];
    static void read(Path path)throws Exception{
        try(var in=new DataInputStream(new BufferedInputStream(Files.newInputStream(path)))){
            focal=in.readDouble();
            areas=List.of(new SafeAreaBarrier.Volume(in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble()));
            for(int n=0;n<views.length;n++){
                var e=new Eye(in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble());
                var pixels=new int[W*H];var depth=new double[W*H];
                for(int i=0;i<pixels.length;i++)pixels[i]=in.readInt();
                for(int i=0;i<pixels.length;i++)depth[i]=in.readDouble();
                views[n]=new View(e,pixels,depth,Arrays.hashCode(depth));
            }
            if(in.read()!=-1)throw new IOException("Dimensions or view count mismatch");
        }
    }
    static final ThreadMXBean mx=ManagementFactory.getThreadMXBean();
    static ShippingHaze.RayCache current;
    static GraceHaze.RayCache grace;
    static void frame(int n,int pose,int offset,String mode,PrintWriter out,int rotation){
        var v=views[pose];var e=v.e;int[] count=new int[3];long[] cpu=new long[3],wall=new long[3];
        int ship=current.fills,guard=grace.fills,shipReuse=current.reuses,guardReuse=grace.reuses;
        for(int j=0;j<3;j++){
            int variant=Math.floorMod(rotation+n+j,3);int[] local=rgb[variant];
            System.arraycopy(v.rgb,0,local,0,local.length);
            long c=mx.getCurrentThreadCpuTime(),w=System.nanoTime();double clock=20+n*.033;
            count[variant]= switch(variant){
                case 0 -> ShippingHaze.draw(local,v.depth,W,H,focal,e.x,e.y,e.z,e.yaw,e.pitch,clock,areas,null);
                case 1 -> ShippingHaze.draw(local,v.depth,W,H,focal,e.x,e.y,e.z,e.yaw,e.pitch,clock,areas,current);
                default -> GraceHaze.draw(local,v.depth,W,H,focal,e.x,e.y,e.z,e.yaw,e.pitch,clock,areas,grace);
            };
            wall[variant]=System.nanoTime()-w;cpu[variant]=mx.getCurrentThreadCpuTime()-c;
        }
        if(count[0]!=count[1]||count[1]!=count[2]||!Arrays.equals(rgb[0],rgb[1])||!Arrays.equals(rgb[1],rgb[2])||Arrays.hashCode(v.depth)!=v.hash)
            throw new AssertionError("Pixel or raw depth mismatch "+mode+" "+n);
        if(out!=null)out.printf(Locale.ROOT,"%s,%d,%d,%d,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d%n",mode,n,pose,offset,
            current.fills>ship?"fill":current.reuses>shipReuse?"reuse":"direct",
            grace.fills>guard?"fill":grace.reuses>guardReuse?"reuse":"direct",
            cpu[0],cpu[1],cpu[2],wall[0],wall[1],wall[2],count[0],Arrays.hashCode(rgb[0]),v.hash);
    }
    static void reset(){current=new ShippingHaze.RayCache();grace=new GraceHaze.RayCache();}
    public static void main(String[] args)throws Exception{
        read(Path.of(args[0]));int rotate=Integer.parseInt(args[2]);
        mx.setThreadCpuTimeEnabled(true);reset();
        for(int i=0;i<128;i++)frame(i,(i/8)%8,i%8,"warmup",null,rotate);
        try(var out=new PrintWriter(Files.newBufferedWriter(Path.of(args[1])))){
            out.println("case,frame,pose,offset,shipping_path,guard_path,direct_cpu_ns,shipping_cpu_ns,guard_cpu_ns,direct_wall_ns,shipping_wall_ns,guard_wall_ns,pixel_count,rgb_hash,depth_hash");
            for(int hold:new int[]{2,3,5,8,80}){
                reset();
                for(int i=0;i<80;i++)frame(i,((i/hold)+rotate)%8,i%hold,"hold"+hold,out,rotate);
                out.flush();
            }
        }
    }
}
