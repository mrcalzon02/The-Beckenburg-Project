from pathlib import Path
import sys, subprocess
from tempfile import TemporaryDirectory
root, out = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
here = Path(__file__).resolve().parent
source = Path('src/main/java/org/beckenburg/SafeAreaHaze.java')
original = (root/source).read_text()
with TemporaryDirectory() as work:
    tmp = Path(work)
    (tmp/source).parent.mkdir(parents=True)
    (tmp/source).write_text(original)
    subprocess.run(['git','apply',str(here/'stable-view.patch')],cwd=tmp,check=True)
    for name, code in [('ShippingHaze', original),('GraceHaze',(tmp/source).read_text())]:
        code=code.replace('SafeAreaHaze',name).replace('        private View last;', '        int fills, reuses;\n        private View last;').replace('                ready=true;', '                fills++;\n                ready=true;').replace('            return ranges;', '            else reuses++;\n            return ranges;')
        out.mkdir(parents=True,exist_ok=True)
        (out/(name+'.java')).write_text(code)
