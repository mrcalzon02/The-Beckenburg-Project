Guard admission experiment against release 13fcd0a4d3002e1084f0ab585865c6d8c1d18691. Its sanctuary shader is unchanged from dc7e497e.
Two fresh Java 17 processes, serial GC, one pinned CPU, 128 warmup frames and 400 measured frames per process. Each frame uses the same 640x360 software House van RGB, depth, volume, camera and clock in each of three shader paths. The first path rotates each frame. No file IO or copying/hashing is timed. Inputs cycle through eight real poses, with 2/3/5/8/80 identical frames before each pose change. The two processes offset pose, path order and the fixed capture. Shader stage CPU time only. No claim about GPU-native motion, system idle or full frame time. Input checksum: 567f2bd301ec5fecfe4725dbf7737173b5b802059271667f287b3a41f1c4e3d7.
All measured frames agreed exactly in changed-pixel count, every color pixel, and depth hashes. The direct path never uses range state. Shipping admits a range buffer on the second frame of a repeated view. The candidate admits one on the sixth. Counters record a fill only when admitted, otherwise an admitted buffer is a reuse.

From the performance revision's repository root with a compiled Java 17 game classpath incl. resources:
    mkdir -p "$TMP/haze-classes" "$TMP/game-poses"
    python "$PROBES/build-probes.py" "$PWD" "$TMP/gen"
    javac --release 17 -cp "$GAME_CLASSES" -d "$TMP/haze-classes" "$TMP/gen/"*.java "$PROBES/"*.java
    java -XX:+UseSerialGC -Xmx690m -cp "$TMP/haze-classes:$GAME_CLASSES" org.beckenburg.CaptureVanViews "$TMP/game-poses"
    for rep in 1 2; do java -XX:ActiveProcessorCount=1 -XX:+UseSerialGC -Xms100m -Xmx180m -cp "$TMP/haze-classes:$GAME_CLASSES" org.beckenburg.PoseHoldReplay "$TMP/capture-true.bin" "$TMP/replay-$rep.csv" "$rep"; done
    # summarize.py reports p50/p95 per case from replay-*.csv alongside itself.

The guard did eliminate all fills at holds of up to five frames. Both runs showed no consistent gain for two-frame stops and a penalty for five-frame stops (loss of genuinely reusable shaded ranges). Stationary median validated cache reuse at the new threshold. This experiment does not establish that stricter admission fixes the two native moving spikes or makes movement faster. Candidate patch is retained as a tested, unshipped alternative.
