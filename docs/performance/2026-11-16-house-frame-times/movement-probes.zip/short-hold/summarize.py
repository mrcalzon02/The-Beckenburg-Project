import csv
from collections import Counter
from pathlib import Path
from statistics import median
from math import ceil

def pct(xs,q):
    ordered=sorted(xs)
    return ordered[max(0,ceil(len(xs)*q)-1)]
def ms(ns):
    return round(ns/1e6,3)
for p in sorted(Path(__file__).parent.glob('replay-*.csv')):
    raw=list(csv.DictReader(p.open()))
    for case in ('hold2','hold3','hold5','hold8','hold80'):
        rows=[r for r in raw if r['case']==case]
        if not rows:continue
        for select in ('all','shipping fill','guard hot'):
            rr=rows
            if select=='shipping fill':rr=[r for r in rows if r['shipping_path']=='fill']
            elif select=='guard hot':rr=[r for r in rows if r['guard_path']=='reuse']
            if rr:
                print(p.stem,case,select,len(rr),*[f"{ms(median([int(r[c+'_cpu_ns']) for r in rr]))}/{ms(pct([int(r[c+'_cpu_ns']) for r in rr],.95))}" for c in ('direct','shipping','guard')],*[Counter(r[c+'_path'] for r in rr)['fill'] for c in ('shipping','guard')])
