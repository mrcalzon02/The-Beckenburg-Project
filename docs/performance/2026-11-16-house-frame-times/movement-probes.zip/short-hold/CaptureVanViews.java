package org.beckenburg;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Per-frame crossover of the production sanctuary shader and a renamed baseline copy.
 * Both variants see the same game-captured RGB/depth, camera and dynamic clock; the first measured variant alternates. */
public final class CaptureVanViews {

    private static void benchmark(Path output,boolean moving) throws Exception {
        Files.createDirectories(output);
        Path dump=output.resolveSibling("capture-"+moving+".bin");
        int width=640,height=360;
        double focalLength;
        SafeAreaBarrier.Volume area;
        int views=moving?8:1;
        if(!Files.exists(dump)){
            var map=new HouseMap(HouseMap.Site.HOUSE);
            var scene=new SceneRenderer();
            scene.setRenderSize(width,height);
            var spawn=map.van().spawn(0);
            scene.roomLights=new RoomLighting();scene.roomLights.setBreaker(true);
            Field focal=SceneRenderer.class.getDeclaredField("focal");focal.setAccessible(true);
            focalLength=focal.getDouble(scene);
            area=SafeAreaBarrier.van(map.van());
            Path temp=dump.resolveSibling(dump.getFileName()+".tmp");
            try(var out=new java.io.DataOutputStream(new java.io.BufferedOutputStream(Files.newOutputStream(temp)))){
                out.writeDouble(focalLength);
                for(double value:new double[]{area.x(),area.y(),area.z(),area.radius(),area.shoulder(),area.height()})out.writeDouble(value);
                for(int i=0;i<views;i++){
                    double angle=i*Math.PI/4;
                    scene.x=spawn.x()+.22*Math.sin(angle);scene.z=spawn.z()+.18*(1-Math.cos(angle));
                    scene.eyeHeight=map.van().floorY()+HunterPosture.STANDING_EYE;
                    scene.pitch=-.08+.04*Math.sin(angle);scene.yaw=-Math.PI/2+.38*Math.sin(angle);
                    scene.drawNetwork(map,List.of(),-1,1);
                    for(double value:new double[]{scene.x,scene.eyeHeight,scene.z,scene.yaw,scene.pitch})out.writeDouble(value);
                    for(int value:scene.image().getRGB(0,0,width,height,null,0,width))out.writeInt(value);
                    for(double value:scene.depths())out.writeDouble(value);
                }
            }
            Files.move(temp,dump);
        }
    }
    public static void main(String[] args)throws Exception{benchmark(Path.of(args[0]),true);}
}
