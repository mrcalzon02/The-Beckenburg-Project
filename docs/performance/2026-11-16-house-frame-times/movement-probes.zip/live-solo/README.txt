House walking regression investigation. Source comparison: shipped renderer 7225b34abd7da5213623e6e7ed4f79ed1657a0f4
vs the same classes with six consecutive matching poses required to begin caching the first sanctuary.
The v0.1.335 launcher change does not alter the sanctuary. Linux, Java 17, real OpenGL llvmpipe / Mesa
25.0.7, offscreen 960x540. Each run used its own JVM. Source observations and raw frame intervals are
local diagnostics; they do not establish physical GTX results. No permanent game change in this probe.

Each run has raw frames.csv, gameplay summary.txt and joined sanctuary.csv. Summary.csv recomputes
distinct panel-composited frame intervals. CPU uses ThreadMXBean on the render EDT, and allocation uses
the thread-allocation counter. gc_before/after are process collection counters read around shading;
these fields were introduced after the initial live-candidate trace. Action 0 = culled/no first shell;
1 = new pose/direct; 2 = populate; 3 = reuse; 4 = direct during the candidate grace interval.
The first live-candidate probe lacks GC counters and writes its original serial GC log.
In all files the clock column is the actual shader animation clock; consecutive draws can have
the same clock and pose but consume more recent GPU depth.

The exploratory run identified 157.302 ms of sanctuary CPU and 178.2 ms shader wall on the first
repeat at x=20.28. White-box trial order was grace1, shipping1, shipping2, grace2 with separate
homes and ten seconds measured idle, then a three-second walk and half-second cooldown. All four
completed normally. During walking no candidate cache fills occurred. The two shipping runs
populated twice and three times. Maximum walking shader CPU fell from 156.278 to 58.507 ms in
pair 1 and from 74.509 to 54.410 ms in pair 2. See summary.csv for frame tails and hitch counts.
All hunters had left the projected sanctuary by ordinary cooldown. No probe here establishes
whether the cost reappears six frames into a deliberate, long stationary stop just inside the dome.
Actual target Windows/GTX repeat, paused-near-dome stop and multiplayer acceptance are outstanding.

Reproduction with JDK 17, a normal repository build and its desktop GPU jar:
create two separate copies of the pinned source or apply each patch against a separate clean copy.
The two patches add the same observational fields and timing print. The grace patch additionally
requires six matching pose frames. It is semantically identical to the independently tested six-frame
guard; its counter names are diagnostic. Readback, geometry, CPU lighting and shading math are original.

    git apply shipping-measure.patch                       # or grace-measure.patch
    mkdir -p /tmp/beck-measure /tmp/beck-case /tmp/beck-home
    javac --release 17 -cp gpu-client/target/BeckenburgGPU.jar -d /tmp/beck-measure src/main/java/org/beckenburg/SafeAreaHaze.java
    java -XX:ActiveProcessorCount=2 -XX:+UseSerialGC -Xms100m -Xmx600m -Duser.home=/tmp/beck-home -Djava.util.prefs.PreferencesFactory=org.beckenburg.VerificationPreferencesFactory -Dbeckenburg.profile.idleSeconds=10 -cp /tmp/beck-measure:build/test:gpu-client/target/BeckenburgGPU.jar org.beckenburg.LanViewportPerformanceReview --gpu --solo /tmp/beck-case > /tmp/beck-case/console.log 2>&1

Use a fresh case/home for each trial, preserving order. These runs also recorded HotSpot compilation
logs on both arms and used LP_NUM_THREADS=2 with an X display under llvmpipe. Parse HST records as
start_ns,x,eye,z,yaw,pitch,clock,cache_action,wall_ns,cpu_ns,allocated_bytes,shaded_pixels,gc_before,gc_after.
Join to each frame end on the last completed preceding HST start (single render EDT).
