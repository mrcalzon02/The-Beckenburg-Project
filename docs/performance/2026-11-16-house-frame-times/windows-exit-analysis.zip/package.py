"""Create a reproducible derived-evidence ZIP alongside a recovered exit raw.zip."""
import argparse
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

def package(out,target):
    scripts=Path(__file__).resolve().parent
    files={p.name:p for p in sorted(out.iterdir()) if p.suffix in ('.csv','.md')}
    files.update({name:scripts/name for name in ('audit.py','events.py','report.py','package.py')})
    assert {'README.md','frame-pooled.csv','camera-events.csv','cpu-pooled.csv','state-pooled.csv','slow-intervals.csv'}<=set(files)
    payload={k:p.read_bytes() for k,p in files.items()}
    payload['members.sha256']=''.join(f'{sha256(d).hexdigest()}  {k}\n' for k,d in sorted(payload.items())).encode()
    with ZipFile(target,'w') as z:
        for name,data in sorted(payload.items()):
            i=ZipInfo(name,(2026,11,17,0,0,0));i.compress_type=ZIP_DEFLATED;i.external_attr=0o100644<<16
            z.writestr(i,data,compresslevel=9)
    with ZipFile(target) as z:
        assert z.testzip() is None and all(z.read(k)==v for k,v in payload.items())
    print(target,len(target.read_bytes()),sha256(target.read_bytes()).hexdigest())
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results',type=Path);parser.add_argument('target',type=Path)
    args=parser.parse_args();package(args.results,args.target)
