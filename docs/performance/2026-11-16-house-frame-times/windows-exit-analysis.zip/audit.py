"""Verify the two-arm physical sanctuary exit trial and recompute phase, CPU and peer-state summaries."""
import argparse
import csv
import io
import json
import math
from collections import defaultdict
from pathlib import Path
from zipfile import ZipFile

PHASES=('idle','moving','stopping')
ARMS=('baseline','candidate')
SHAS={'baseline_shader_lf_sha256':'de95f3d3f4b5b415787094c48c95dbc0b526c5b651ca430b3dd114478c3a4401',
      'candidate_shader_lf_sha256':'f582008ec7929243ab05fd2cd7ef7ede4cf3836bf56d79cb6fa83756ccb59cf3',
      'panel_lf_sha256':'31a889e9f4923ef838200dc25e8f3964c6fa950118b9ba0d788cb1dd2934b653',
      'test_driver_lf_sha256':'264e0bfae9cb77664a57751d88e01300e216cf77c3da93d00445f9c3b224041e'}

def rank(v,q):return sorted(v)[math.ceil(q*len(v))-1]
def rows(z,n):return list(csv.DictReader(io.TextIOWrapper(z.open(n),encoding='utf-8-sig')))
def stats(v):return [len(v),*[round(rank(v,q),3) for q in (.5,.95,.99,1)],sum(x>33.3 for x in v),sum(x>100 for x in v)]
def csvout(p,cols,data):
    with p.open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(cols.split())
        writer.writerows(data)
def collect(z,out,baseline_sha,candidate_sha,controller_sha):
    provenance=json.loads(z.read('provenance.json'))
    assert provenance['route']=='sanctuary-exit'
    assert provenance['controller_sha']==controller_sha
    assert provenance['revisions']=={'baseline':baseline_sha,'candidate':candidate_sha}
    manifest=json.loads(z.read('compiled-overlays.json'))
    for k,v in SHAS.items():assert manifest[k]==v,k
    arms=ARMS
    assert provenance['runner']=='OLD-CORE30-homebrew' and provenance['backend']=='gpu' and provenance['outer_pairs']==4
    paths=set(z.namelist())
    expected={f'pair-{pair}-{mode}-{arm}' for pair in range(1,5) for mode in ('solo','tcp') for arm in arms}
    assert expected=={n.split('/')[0] for n in paths if n.startswith('pair-')}
    for name in ['baseline','candidate']:
        report=z.read(name+'-full-round.txt').decode()
        assert all(s in report for s in ['full multiplayer round: PASS','spectral privacy enforced','evidence tools measured and shared','both hunters received the winning settlement','Post-round commands rejected']),name
        assert 'PASS Beckenburg full LAN' in z.read(name+'-e2e.log').decode()
    strata=defaultdict(list); stop_poses=[]
    groups=defaultdict(list); pressure=defaultdict(lambda:[0,0,0]); report=[]; audits=[]
    trial_frames={};pooled_frames=defaultdict(list);cpu_rows=[];cpu_groups=defaultdict(list);timing_rows=[];route_rows=[]
    for t in sorted(expected):
        _,pair,mode,arm=t.split('-')
        for name in ['run.log','summary.txt','frames.csv','composited-intervals.csv']:
            assert f'{t}/{name}' in paths
        sf=f'{t}/state.csv';assert (sf in paths)==(mode=='tcp')
        summary=dict(x.split('=',1) for x in z.read(t+'/summary.txt').decode().splitlines())
        assert '1660 SUPER' in summary['renderer'] and float(summary['max_travel_metres'])>.1
        assert int(summary['rendered_hunters'])==1
        if mode=='tcp':assert int(summary['other_tcp_peers'])==2 and int(summary['visible_peer_hunters'])>=1 and int(summary['accepted_steps'])>0
        s=rows(z,sf) if mode=='tcp' else []
        times={r['phase']:r for r in rows(z,t+'/phase-cpu.csv')}
        assert set(PHASES)==set(times)
        route_rows.append([pair,mode,arm,summary['accepted_steps'],summary['max_travel_metres'],summary['visible_peer_hunters'],
                           summary['other_tcp_peers'],summary['moving_seconds'],len(s)])
        ref={r['phase']:r for r in rows(z,t+'/composited-intervals.csv')}
        assert set(ref)==set(PHASES)
        frames=rows(z,t+'/frames.csv')
        assert all((int(r['width']),int(r['height']))==(960,540) for r in frames if r['phase'] in PHASES)
        moving=[r for r in frames if r['phase']=='moving']
        assert any(r['inside_sanctuary']=='false' for r in moving)
        for phase in PHASES:
            rs=[r for r in frames if r['phase']==phase]
            if phase=='stopping':assert all(r['inside_sanctuary']=='true' for r in rs)
            aligned=[];selected=[];last_id=None
            for r in rs:
                fid=int(r['composited_gl_frame_id'])
                if fid<0 or fid==last_id:continue
                aligned.append(int(r['time_ns']));selected.append(r)
                last_id=fid
            gaps=[(b-a)/1e6 for a,b in zip(aligned,aligned[1:])]
            assert min(gaps)>0
            if phase=='moving':
                for a,b,gap in zip(selected,selected[1:],gaps):
                    sa=a['inside_sanctuary'];sb=b['inside_sanctuary']
                    band='crossing' if sa!=sb else ('inside' if sb=='true' else 'outside')
                    strata[mode,arm,band].append(gap)
            if phase=='stopping':
                last=rs[-1];fields=('x','eye','z','yaw','pitch');pose=lambda r:tuple(r[k] for k in fields)
                i=len(rs)-1
                while i>0 and pose(rs[i-1])==pose(last):i-=1
                assert len(rs)-i>=12 and (int(last['time_ns'])-int(rs[i]['time_ns']))>=3_000_000_000
                before=[r for r in frames if r['phase']=='settling'][-1]
                step=math.hypot(*(float(last[k])-float(before[k]) for k in ('x','z')))
                assert .1<step<.5
                stop_poses.append([pair,mode,arm,*pose(last),round(step,4),len(rs)-i])
            p=ref[phase]
            trial_frames[pair,mode,arm,phase]=gaps
            pooled_frames[mode,arm,phase].extend(gaps)
            timing_rows.append([pair,mode,arm,phase,*stats(gaps),sum(x>50 for x in gaps),int(rank(gaps,.95)<=33.3)])
            c=times[phase]
            wall=int(c['end_wall_ns'])-int(c['start_wall_ns']);assert wall==int(c['wall_ns']) and wall>0
            assert int(c['start_wall_ns'])<=int(rs[0]['time_ns'])<=int(rs[-1]['time_ns'])<=int(c['end_wall_ns'])
            if c['process_cpu_ns']:
                used=int(c['end_process_cpu_ns'])-int(c['start_process_cpu_ns'])
                assert used==int(c['process_cpu_ns']) and used>=0 and int(c['start_process_cpu_ns'])>=0
                assert abs(used/wall-float(c['core_equivalents']))<=.00000051
                cpu_groups[mode,arm,phase].append((used,wall,len(aligned)))
                cpu_rows.append([pair,mode,arm,phase,round(wall/1e9,6),round(used/1e9,6),round(used/wall,6),
                                 len(aligned),round(used/1e6/len(aligned),3)])
            assert len(gaps)==int(p['intervals'])
            for prob,k in [(0.5,'p50_ms'),(.95,'p95_ms'),(.99,'p99_ms')]: assert abs(rank(gaps,prob)-float(p[k]))<.00051,(t,phase,k)
            for threshold,k in [(33.3,'over_33_3_ms'),(50,'over_50_ms'),(100,'over_100_ms')]:
                assert int(p[k])==sum(x>threshold for x in gaps),(t,phase,k)
            t0=int(rs[0]['time_ns']);t1=int(rs[-1]['time_ns'])
            pr=pressure[(arm,mode,phase)]
            pr[0]+=sum(int(r['render_ns']) for r in rs[1:]);pr[1]+=t1-t0;pr[2]+=len(gaps)
            audits.append((pair,arm,mode,phase,len(rs),len(gaps),p['p95_ms'],summary['max_travel_metres']))
            if mode!='tcp':continue
            arrival=[r for r in s if r['phase']==phase]
            assert arrival
            assert all(int(r['edt_dispatch_ns'])>=int(r['client_received_ns']) for r in arrival)
            assert all(int(b['host_tick'])>=int(a['host_tick']) for a,b in zip(arrival,arrival[1:]))
            inside=[r for r in arrival if t0<=int(r['client_received_ns'])<=int(r['edt_dispatch_ns'])<=t1]
            for name,sub in [('arrival',arrival),('interior',inside)]:
                wait=[(int(r['edt_dispatch_ns'])-int(r['client_received_ns']))/1e6 for r in sub]
                assert wait
                groups[arm,phase,name]+=wait
                report.append([pair,arm,phase,name,*stats(wait)])
    repcols='pair arm phase sample_set n queue_p50_ms queue_p95_ms queue_p99_ms queue_max_ms over33_3 over100'
    csvout(out/'state-trials.csv',repcols,report)
    csvout(out/'state-pooled.csv',repcols.replace('pair ', 'trial_count ', 1),([4,*k,*stats(v)] for k,v in sorted(groups.items())))
    by_trial={(str(pair),arm,phase):v for pair,arm,phase,filter_name,*v in report if filter_name=='arrival'}
    contrasts=[('baseline','candidate')]
    paired=[]
    for first,second in contrasts:
        for phase in PHASES:
            for pair in map(str,range(1,5)):
                a=by_trial[pair,first,phase];b=by_trial[pair,second,phase]
                paired.append([pair,phase,first,second,a[0],b[0],a[2],b[2],round(b[2]-a[2],3),a[4],b[4]])
    csvout(out/'state-paired.csv','pair phase before_arm after_arm before_n after_n before_p95_ms after_p95_ms difference_ms before_max_ms after_max_ms',paired)
    csvout(out/'renderer-pressure.csv','arm mode phase rendered_pct_edt_wall delivered_fps',([*k,round(a/b*100,3),round(n*1e9/b,3)] for k,(a,b,n) in sorted(pressure.items())))
    csvout(out/'trial-audit.csv','pair arm mode phase rendered_count distinct_intervals p95_ms travel_m',audits)
    csvout(out/'moving-domain.csv','mode arm interval_endpoints n frame_p50_ms frame_p95_ms frame_p99_ms max_ms over33_3 over100',([*k,*stats(v)] for k,v in sorted(strata.items())))
    csvout(out/'stop-camera.csv','pair mode arm x eye z yaw pitch step_metres stable_frames',stop_poses)
    csvout(out/'routes.csv','pair mode arm accepted_steps travel_m visible_peer_hunters tcp_peers moving_s state_records',route_rows)
    csvout(out/'frame-trials.csv','pair mode arm phase n p50_ms p95_ms p99_ms max_ms over33_3 over100 over50 p95_target',timing_rows)
    csvout(out/'frame-pooled.csv','mode arm phase n p50_ms p95_ms p99_ms max_ms over33_3 over100 over50 trial_p95_on_target',
           ([*k,*stats(gs),sum(i>50 for i in gs),sum(rank(trial_frames[str(i),*k],.95)<=33.3 for i in range(1,5))]
            for k,gs in sorted(pooled_frames.items())))
    compare=[]
    for mode in ('solo','tcp'):
        for ph in PHASES:
            for first,second in contrasts:
                triplets=[(trial_frames[str(i),mode,first,ph],trial_frames[str(i),mode,second,ph]) for i in range(1,5)]
                wins=sum(rank(b,.95)<rank(a,.95) for a,b in triplets)
                deltas=sorted(rank(b,.95)-rank(a,.95) for a,b in triplets)
                compare.append([mode,ph,first,second,wins,round((deltas[1]+deltas[2])*.5,3),round(min(deltas),3),round(max(deltas),3)])
    csvout(out/'frame-paired.csv','mode phase before_arm after_arm pairs_lower_p95 median_paired_p95_change_ms min_change_ms max_change_ms',compare)
    csvout(out/'cpu-trials.csv','pair mode arm phase elapsed_s process_cpu_s cores distinct_frames cpu_ms_per_delivered_frame',cpu_rows)
    aggregate=[]
    for k,obs in sorted(cpu_groups.items()):
        used=sum(c for c,e,f in obs);elapsed=sum(e for c,e,f in obs);frames=sum(f for c,e,f in obs)
        cs=sorted(c/e for c,e,f in obs);n=len(cs)
        aggregate.append([*k,n,round(elapsed/1e9,6),round(used/1e9,6),round(used/elapsed,4),
                          round((cs[(n-1)//2]+cs[n//2])/2,4),round(min(cs),4),round(max(cs),4),frames,round(used/1e6/frames,3)])
    csvout(out/'cpu-pooled.csv','mode arm phase measured_trials elapsed_s process_cpu_s pooled_cores median_trial_cores min_trial_cores max_trial_cores distinct_frames process_cpu_ms_per_delivered_frame',aggregate)
    print(f'{len(expected)} trial directories; {len(audits)} trial phases matched stored count, quantiles and thresholds; {len(expected)//2} TCP state streams; two complete gameplay reports.')
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip',type=Path);parser.add_argument('output',type=Path)
    for name in ('baseline-sha','candidate-sha','controller-sha'):
        parser.add_argument('--'+name,required=True)
    opts=parser.parse_args();opts.output.mkdir(exist_ok=True,parents=True)
    with ZipFile(opts.zip) as z:collect(z,opts.output,opts.baseline_sha,opts.candidate_sha,opts.controller_sha)
if __name__=='__main__':main()
