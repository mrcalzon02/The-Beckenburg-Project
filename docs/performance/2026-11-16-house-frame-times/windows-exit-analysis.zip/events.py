"""Locate actual camera events in the two-arm exit benchmark and attach bounded GL intervals."""
import argparse
import csv
import math
from bisect import bisect_left
from collections import defaultdict
from pathlib import Path
from statistics import median
from zipfile import ZipFile

from audit import ARMS, PHASES, csvout, rank, rows, stats

POSE = ('x','eye','z','yaw','pitch')
STAGES = ('render','build','geometry','effects')
MODES = ('solo','tcp')

def pose(row):
    return tuple(float(row[k]) for k in POSE)

def stage(row):
    return [int(row[name+'_ns'])/1e6 for name in STAGES]

def gap_ms(a,b):
    return (int(b['time_ns'])-int(a['time_ns']))/1e6

def distinct(rs):
    indices=[]
    for i,r in enumerate(rs):
        gl=int(r['composited_gl_frame_id'])
        if gl<0:continue
        if indices:
            previous=int(rs[indices[-1]]['composited_gl_frame_id'])
            if gl==previous:continue
            assert gl>previous
        indices.append(i)
    return indices

def f(value):
    return '' if value is None else round(value,6)

def brackets(rs,indices,event):
    """Two observed composite sample endpoints spanning this CPU event (open,closed]."""
    right=bisect_left(indices,event)
    if right==0 or right==len(indices):return None
    return indices[right-1],indices[right],right

def run(z,out,arm_members):
    events=[]; windows=[]; slow=[]; paired=[]; pooled=defaultdict(list)
    trajectories={}; matches=[]; moving_band_trials=[]; stable=[]; records={}
    for pair in range(1,5):
        for mode in MODES:
            for arm,member in arm_members.items():
                trial=f'pair-{pair}-{mode}-{member}'
                frames=rows(z,trial+'/frames.csv')
                rs=[r for r in frames if r['phase']=='moving']
                advances=distinct(rs)
                changed=[i for i,r in enumerate(rs) if i==0 or pose(r)!=pose(rs[i-1])]
                outside=next(i for i,r in enumerate(rs) if r['inside_sanctuary']=='false')
                assert rs[outside-1]['inside_sanctuary']=='true' and all(r['inside_sanctuary']=='false' for r in rs[outside:])
                start=next(i for i,r in enumerate(frames) if r['phase']=='moving')
                end=start+len(rs)
                assert frames[start:end]==rs
                all_ids=distinct(frames)
                origin=pose(frames[start-1])
                assert frames[start-1]['phase']=='idle'
                add_origin=[origin] if pose(rs[0])!=origin else []
                prefix=add_origin+[pose(rs[i]) for i in changed if i<=outside]
                trajectories[pair,mode,arm]=(prefix,add_origin+[pose(rs[i]) for i in changed])
                assert math.dist((origin[0],origin[2]),(20.9,36.25))<1e-8 and (origin[1],origin[4])==(2.12,-.08)
                early=[i for i in changed if pose(rs[i])!=origin and rs[i]['inside_sanctuary']=='true']
                event_indices={'first_inside_step':early[0],'second_inside_step':early[1],'first_outside_step':outside}
                observed_bands=defaultdict(list)
                for a,b in zip(advances,advances[1:]):
                    sa=rs[a]['inside_sanctuary'];sb=rs[b]['inside_sanctuary']
                    observed_bands['crossing' if sa!=sb else 'inside' if sb=='true' else 'outside'].append(gap_ms(rs[a],rs[b]))
                for band,gaps in observed_bands.items():
                    moving_band_trials.append([pair,mode,arm,band,*stats(gaps)])
                for event,i in event_indices.items():
                    r=rs[i]
                    idx=start+i
                    bracket=brackets(frames,all_ids,idx)
                    assert bracket is not None,(trial,event)
                    a,b,right=bracket
                    gap=gap_ms(frames[a],frames[b])
                    rec=(*pose(r),*stage(r),gap)
                    records[pair,mode,event,arm]=rec
                    pooled[mode,event,arm].append(rec)
                    near=[]
                    for end in range(max(1,right-2),min(len(all_ids),right+3)):
                        first,last=all_ids[end-1:end+1]
                        n=gap_ms(frames[first],frames[last]);near.append(n)
                        windows.append([pair,mode,arm,event,end-right,first,last,frames[first]['phase'],frames[last]['phase'],frames[first]['x'],frames[last]['x'],
                                        frames[first]['composited_gl_frame_id'],frames[last]['composited_gl_frame_id'],f(n)])
                    prev=frames[idx-1]
                    events.append([pair,mode,arm,event,idx,*pose(r),*[f(x) for x in stage(r)],
                                   int(r['faces']),int(r['shadow_rays']),a,b,frames[a]['phase'],frames[b]['phase'],frames[a]['composited_gl_frame_id'],frames[b]['composited_gl_frame_id'],
                                   frames[a]['x'],frames[b]['x'],f(gap),f(max(near)),f(gap_ms(prev,r)) if prev else ''])
                for phase in PHASES:
                    phase_rows=[r for r in frames if r['phase']==phase]
                    ids=distinct(phase_rows)
                    for a,b in zip(ids,ids[1:]):
                        d=gap_ms(phase_rows[a],phase_rows[b])
                        if d<=100:continue
                        r=phase_rows[b]
                        slow.append([pair,mode,arm,phase,a,b,*pose(phase_rows[a]),*pose(r),
                                     phase_rows[a]['inside_sanctuary'],r['inside_sanctuary'],
                                     phase_rows[a]['composited_gl_frame_id'],r['composited_gl_frame_id'],
                                     f(d),*[f(n) for n in stage(r)],b-a,
                                     *[f(sum(int(row[s+'_ns']) for row in phase_rows[a+1:b+1])/1e6) for s in STAGES],
                                     ' '.join(row['composited_gl_frame_id'] for row in phase_rows[a:b+1])])
                stop=[r for r in frames if r['phase']=='stopping'];idx=len(stop)-1
                while idx and pose(stop[idx-1])==pose(stop[-1]):idx-=1
                assert len(stop)-idx>=12
                ids=distinct(stop)
                box=brackets(stop,ids,idx+5);assert box
                a,b,right=box
                near=[gap_ms(stop[ids[k-1]],stop[ids[k]]) for k in range(max(1,right-2),min(len(ids),right+3))]
                stable.append([pair,mode,arm,idx,len(stop)-idx,*pose(stop[-1]),f(gap_ms(stop[idx],stop[-1])/1000),
                               f(stage(stop[idx+5])[-1]),f(gap_ms(stop[a],stop[b])),f(max(near))])
            a,all_a=trajectories[pair,mode,'baseline'];b,all_b=trajectories[pair,mode,'candidate']
            n=min(len(all_a),len(all_b));mid=all_a[:n]==all_b[:n]
            matches.append([pair,mode,len(a),len(b),int(a==b),int(mid),len(all_a),len(all_b),all_a[-1][0],all_b[-1][0],
                            ' '.join(str(p[0]) for p in a),' '.join(str(p[0]) for p in b)])
            for name in event_indices:
                a=records[pair,mode,name,'baseline'];b=records[pair,mode,name,'candidate']
                paired.append([pair,mode,name,int(a[:5]==b[:5]),a[0],b[0],
                               *[f(y) for x in zip(a[5:],b[5:]) for y in (*x,x[1]-x[0])]])
    csvout(out/'camera-events.csv','pair mode arm event panel_index '+' '.join(POSE)+' '+' '.join(s+'_ms' for s in STAGES)+
           ' faces shadow_rays gl_begin_index gl_end_index gl_begin_phase gl_end_phase gl_begin_id gl_end_id gl_begin_x gl_end_x bounded_gl_gap_ms max_5_gl_gaps_ms panel_completion_gap_ms',events)
    csvout(out/'camera-events-paired.csv','pair mode event exact_pose_match baseline_x candidate_x '+' '.join(
        k+'_'+s+'_ms' for s in (*STAGES,'bounded_gl_gap') for k in ('baseline','candidate','change')),paired)
    csvout(out/'camera-events-pooled.csv','mode event arm n '+' '.join(x+'_'+s+'_ms' for s in (*STAGES,'bounded_gl_gap') for x in ('median','min','max')),
           ([*k,len(v),*[f(y) for col in zip(*(r[5:] for r in v)) for y in (median(col),min(col),max(col))]]
            for k,v in sorted(pooled.items())))
    csvout(out/'gl-neighborhoods.csv','pair mode arm event gl_interval_offset gl_begin_index gl_end_index gl_begin_phase gl_end_phase gl_begin_x gl_end_x gl_begin_id gl_end_id gap_ms',windows)
    csvout(out/'slow-intervals.csv','pair mode arm phase gl_begin_index gl_end_index '+' '.join(k+'_'+s for k in ('begin','end') for s in POSE)+
           ' begin_inside end_inside gl_begin_id gl_end_id bounded_gl_gap_ms '+' '.join('ending_'+s+'_ms' for s in STAGES)+
           ' panel_completions '+' '.join('sum_'+s+'_ms' for s in STAGES)+' raw_gl_ids',slow)
    csvout(out/'trajectory-pairs.csv','pair mode baseline_exit_pose_count candidate_exit_pose_count exact_all_poses_through_exit exact_common_trajectory baseline_distinct_poses candidate_distinct_poses baseline_final_x candidate_final_x baseline_x_through_exit candidate_x_through_exit',matches)
    csvout(out/'moving-domain-trials.csv','pair mode arm interval_endpoints n p50_ms p95_ms p99_ms max_ms over33_3 over100',moving_band_trials)
    csvout(out/'stop-sixth.csv','pair mode arm first_final_pose_index stable_frames '+' '.join(POSE)+' stable_seconds sixth_effects_ms sixth_bounded_gl_gap_ms max_5_gl_gaps_ms',stable)
    print(f'{len(events)} camera events with bounded GL intervals; {len(matches)} paired trajectories; {len(slow)} frame gaps over 100 ms.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--rehearse-prior-pacing',action='store_true',help='Use fixed30 and deadline20 from the earlier four-arm pacing archive only.')
    args=parser.parse_args();args.output.mkdir(exist_ok=True,parents=True)
    with ZipFile(args.zip) as z:
        import json
        p=json.loads(z.read('provenance.json'))
        assert p['route']==('sanctuary-pacing' if args.rehearse_prior_pacing else 'sanctuary-exit')
        run(z,args.output,{'baseline':'fixed','candidate':'candidate'} if args.rehearse_prior_pacing else {a:a for a in ARMS})
