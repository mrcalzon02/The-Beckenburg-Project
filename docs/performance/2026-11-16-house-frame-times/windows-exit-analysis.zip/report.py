"""Write the physical sanctuary exit comparison from audited CSVs."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

from audit import ARMS, PHASES, csvout
from events import MODES

LABEL={'baseline':'Deadline20','candidate':'Deadline20 + cull','solo':'Solo','tcp':'Three-seat','idle':'Idle','moving':'Walking','stopping':'Stopping',
       'first_inside_step':'First inside step','second_inside_step':'Second inside step','first_outside_step':'First outside step'}
def table(head,rows):
    def row(items):return '| '+' | '.join(str(x) for x in items)+' |'
    return [row(head),row(['---']+['---:']*(len(head)-1)),*[row(r) for r in rows]]
def fmt(v):
    return f'{float(v):.2f}'
def span(vals):
    return f'{min(vals):.2f}–{max(vals):.2f}'

def render(out,raw,run):
    def load(name):
        with (out/name).open(newline='') as f:return list(csv.DictReader(f))
    def index(name,keys):
        return {tuple(r[k] for k in keys.split()):r for r in load(name)}
    with ZipFile(raw) as z:
        p=json.loads(z.read('provenance.json'))
        hashes=json.loads(z.read('compiled-overlays.json'))
        hardware=z.read('environment.log').decode('utf-8',errors='replace')
        assert '1660 SUPER' in hardware and '10700' in hardware
    fs=index('frame-pooled.csv','mode arm phase')
    trials=index('frame-trials.csv','pair mode arm phase')
    cpus=index('cpu-pooled.csv','mode arm phase')
    states=index('state-pooled.csv','arm phase sample_set')
    sources=index('camera-events-pooled.csv','mode event arm')
    domain=index('moving-domain.csv','mode arm interval_endpoints')
    comparison=load('camera-events-paired.csv')
    trajectories=load('trajectory-pairs.csv');stops=load('stop-sixth.csv');routes=load('routes.csv');slow=load('slow-intervals.csv')
    summary=[]
    paired=[]
    for m in MODES:
        for phase in PHASES:
            for pair in range(1,5):
                a=trials[str(pair),m,'baseline',phase];b=trials[str(pair),m,'candidate',phase]
                paired.append([pair,m,phase,a['n'],b['n'],*[v for k in ('p50_ms','p95_ms','p99_ms','max_ms','over100') for v in (a[k],b[k])],
                               round(float(b['p95_ms'])-float(a['p95_ms']),3)])
    csvout(out/'frame-paired-trials.csv','pair mode phase baseline_n candidate_n '+' '.join(k+'_'+q for q in ('p50_ms','p95_ms','p99_ms','max_ms','over100') for k in ('baseline','candidate'))+' change_p95_ms',paired)
    earliest=('first_inside_step','second_inside_step','first_outside_step')
    match=sum(int(r['exact_all_poses_through_exit']) for r in trajectories)
    same=sum(int(r['exact_common_trajectory']) for r in trajectories)
    refposes={r['baseline_x_through_exit'] for r in trajectories}|{r['candidate_x_through_exit'] for r in trajectories}
    step_rows=load('camera-events.csv')
    boundary_events=[r for r in step_rows if r['gl_begin_phase']!=r['gl_end_phase']]

    final_dist=[float(r['travel_m']) for r in routes]
    summary.extend(['# Core30 GTX 1660 SUPER sanctuary exit', '',
        f'Run [{run}](https://github.com/mrcalzon02/Dens-Mortis/actions/runs/{run}) compared the same four-lane sanctuary shading and 20 ms deadline scheduler with and without the outward dome cull. The retail-target viewport was 960×540. Core30 ran four alternating pairs per mode on its i7-10700 and GTX 1660 SUPER. Each three-seat trial used one rendered hunter and two real loopback peers. The driver recorded distinct consumed GL readbacks in an offscreen viewport.','','## Frame pacing','',
        *table(['Mode','Phase','Arm','Intervals','p50 ms','p95 ms','p99 ms','Max ms','>100 ms','Trials p95 ≤33.3 ms'],[
            [LABEL[m],LABEL[phase],LABEL[arm],r['n'],fmt(r['p50_ms']),fmt(r['p95_ms']),fmt(r['p99_ms']),fmt(r['max_ms']),r['over100'],r['trial_p95_on_target']+'/4']
            for m in MODES for phase in PHASES for arm in ARMS for r in [fs[m,arm,phase]]]),'',
        'Each percentile pools distinct-GL intervals within the stated phase over the four trials. frame-paired-trials.csv compares every matched pair and phase. The table below shows each matched walk.','',
        *table(['Mode','Pair','Deadline20 p95 ms','With cull p95 ms','Deadline20 >100 ms','With cull >100 ms'],[
            [LABEL[m],pair,a['p95_ms'],b['p95_ms'],a['over100'],b['over100']]
            for m in MODES for pair in range(1,5) for a,b in [(trials[str(pair),m,'baseline','moving'],trials[str(pair),m,'candidate','moving'])]]),'',
        *table(['Mode','Arm','Interior intervals','Interior p95 ms','Exterior intervals','Exterior p95 ms','Crossings','Worst crossing ms'],[
            [LABEL[m],LABEL[arm],inside['n'],fmt(inside['frame_p95_ms']),outside['n'],fmt(outside['frame_p95_ms']),cross['n'],fmt(cross['max_ms'])]
            for m in MODES for arm in ARMS for inside,outside,cross in [(domain[m,arm,'inside'],domain[m,arm,'outside'],domain[m,arm,'crossing'])]]),'',
        'The interior and exterior distributions include moving intervals whose first and last observed CPU poses lie on the same side of the dome. Boundary intervals are kept separately. moving-domain-trials.csv preserves the three distributions per individual trial.','',
        '## Camera-matched crossing and first two inside steps','',
        f'The five camera values (x, eye height, z, yaw and pitch) matched at every distinct pose through the boundary in {match}/8 pairs. They matched along the common part of the entire three-second walk in {same}/8 pairs. Maximum travel ranged from {span(final_dist)} m. The paths and final positions for every pair are in trajectory-pairs.csv.',''])
    if len(refposes)==1:
        summary.extend([f"The ten measured x coordinates through the first exterior view were {', '.join(next(iter(refposes)).split())} m.",''])
    summary+=table(['Mode','Pose','Arm','Renderer ms','Build ms','Geometry ms','Post-geometry ms','GL gap ms','GL gap range ms'],[
        [LABEL[m],LABEL[e],LABEL[arm],*[fmt(r['median_'+s+'_ms']) for s in ('render','build','geometry','effects','bounded_gl_gap')],
         f'{fmt(r["min_bounded_gl_gap_ms"])}–{fmt(r["max_bounded_gl_gap_ms"])}']
        for m in MODES for e in earliest for arm in ARMS for r in [sources[m,e,arm]]])
    summary.extend(['',
        'Stage values are median elapsed CPU-side renderer timings across four independent first arrivals at that exact pose. Post-geometry includes sanctuary shading, character sprites and other effects. The physical driver did not time the dome separately. The camera passed to sanctuary shading is the camera recorded in frames.csv. Consumed OpenGL RGB/depth can come from an earlier submission. Each GL gap spans the two consecutive distinct readback timestamps bracketing the CPU event, with the ending timestamp included. gl-neighborhoods.csv retains the previous and following two intervals where available. GPU execution and input-to-display latency require different timestamps.', '', f'{len(boundary_events)} of the 48 camera-event brackets span the transition from idle to moving. Their phase endpoints and frame IDs are preserved in camera-events.csv. These transition intervals are excluded from every per-phase percentile and over-100 count.', '',
        *table(['Mode','Pair','Post-geometry before ms','Post-geometry after ms','GL gap before ms','GL gap after ms'],[
            [LABEL[r['mode']],r['pair'],*[fmt(r[k]) for k in ('baseline_effects_ms','candidate_effects_ms','baseline_bounded_gl_gap_ms','candidate_bounded_gl_gap_ms')]]
            for r in comparison if r['event']=='first_outside_step']),''])
    n1=sum(float(r['change_effects_ms'])<0 for r in comparison if r['event']=='first_outside_step')
    n2=sum(float(r['change_bounded_gl_gap_ms'])<0 for r in comparison if r['event']=='first_outside_step')
    summary.extend([f'The guarded build reduced first-exterior post-geometry time in {n1}/8 matched trials and reduced the enclosing frame interval in {n2}/8. Each row in camera-events-paired.csv keeps the matched build, geometry, post-geometry, total and GL-interval differences for both earlier inside steps and the first exterior view.','',
        '## Intervals above 100 ms and the inside stop',''])
    if slow:
        summary+=table(['Mode','Pair','Arm','Phase','x start → end m','Gap ms','Rendered panel completions','Total renderer ms','Total post-geometry ms','Readback ID sequence'],[
            [LABEL[r['mode']],r['pair'],LABEL[r['arm']],LABEL[r['phase']],r['begin_x']+' → '+r['end_x'],
             fmt(r['bounded_gl_gap_ms']),r['panel_completions'],fmt(r['sum_render_ms']),fmt(r['sum_effects_ms']),r['raw_gl_ids']] for r in slow])
    else:summary+=['All measured idle, walk and stop intervals in both arms stayed at or below 100 ms.']
    if any(int(r['panel_completions'])>1 for r in slow):
        summary+=['','Renderer and post-geometry totals cover every completed panel draw after the starting readback through the ending readback. Repeating a readback ID keeps the preceding interval open. The first inside camera pose can therefore span two expensive draws before the next distinct GL frame appears.']
    distances=[float(r['step_metres']) for r in load('stop-camera.csv')]
    summary.extend(['',f'All 16 stopping traces recorded a {min(distances):.2f} m step followed by a stable five-component camera pose, held for {span([float(r["stable_seconds"]) for r in stops])} s. The sixth identical panel completion is bracketed by distinct GL timestamps.','',
        *table(['Arm','Holds','Sixth-frame effects range ms','Sixth GL gap range ms','Worst GL gap within ±2 intervals ms'],[
            [LABEL[arm],len(r),span([float(s['sixth_effects_ms']) for s in r]),span([float(s['sixth_bounded_gl_gap_ms']) for s in r]),
             fmt(max(float(s['max_5_gl_gaps_ms']) for s in r))] for arm in ARMS for r in [[s for s in stops if s['arm']==arm]]]),'',
        '## Process CPU, peer state and round receipts','',
        *table(['Mode','Arm','Idle cores','Walking cores','Stopping cores','Idle CPU ms/frame','Walking CPU ms/frame','Stopping CPU ms/frame'],[
            [LABEL[m],LABEL[arm],*[cpus[m,arm,phase]['pooled_cores'] for phase in PHASES],
             *[cpus[m,arm,phase]['process_cpu_ms_per_delivered_frame'] for phase in PHASES]]
            for m in MODES for arm in ARMS]),'',
        'Process CPU covers the entire Java process, including the local host, clients, renderer and other threads. Core-equivalents divide summed CPU time by summed elapsed phase time. Counter reads occur at phase boundaries.','',
        *table(['Arm','Phase','STATE arrivals','EDT queue p50 ms','p95 ms','p99 ms','Max ms','>100 ms'],[
            [LABEL[arm],LABEL[phase],r['n'],*[fmt(r['queue_'+q+'_ms']) for q in ('p50','p95','p99','max')],r['over100']]
            for arm in ARMS for phase in PHASES for r in [states[arm,phase,'arrival']]]),'',
        'Queue latency runs from socket receipt of a decoded STATE entry to its dispatch on the Swing event thread. state-pooled.csv also reports the stricter subset whose arrival and dispatch both occurred between the first and last rendered phase samples.',''])
    tcp=[r for r in routes if r['mode']=='tcp']
    summary.extend([f'All {len(tcp)} TCP trials maintained both peers, recorded at least one visible peer hunter and confirmed {min(int(r["accepted_steps"]) for r in tcp)}–{max(int(r["accepted_steps"]) for r in tcp)} authoritative accepted movement records. Both arms passed the full separate network-round tests. Their receipts cover spectral privacy, evidence tools and sharing, hunter settlement and rejected post-round input.','',
                    '## Reproduction','',
                    f'Raw archive SHA-256 is `{hashlib.sha256(raw.read_bytes()).hexdigest()}`. Baseline source is `{p["revisions"]["baseline"]}` and candidate package source is `{p["revisions"]["candidate"]}`. The worker compared both production trees and compiled only the guarded sanctuary class for the candidate. Deadline20 panel SHA-256 is `{hashes["panel_lf_sha256"]}` and the guarded shader SHA-256 is `{hashes["candidate_shader_lf_sha256"]}`.','',
                    '```sh', f'python audit.py raw.zip results --baseline-sha {p["revisions"]["baseline"]} --candidate-sha {p["revisions"]["candidate"]} --controller-sha {p["controller_sha"]}',
                    'python events.py raw.zip results',f'python report.py raw.zip results --run {run}','```',''])
    (out/'README.md').write_text('\n'.join(summary))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('raw',type=Path);p.add_argument('output',type=Path);p.add_argument('--run',required=True)
    args=p.parse_args();render(args.output,args.raw,args.run)
