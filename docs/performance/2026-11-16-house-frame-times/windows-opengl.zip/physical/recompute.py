"""Validate Core30 timing rows, recompute frame tails and collect shareable data."""
import csv, io, math, statistics, sys, zipfile, json
from collections import defaultdict
from pathlib import Path

archive, backend=sys.argv[1:3]
label=sys.argv[3] if len(sys.argv)>3 else backend
if label not in {'software', 'gpu', 'software-peer'}:raise ValueError(label)
if backend not in {'software','gpu'}:raise ValueError(backend)
output=Path(__file__).resolve().parent/'physical-evidence'/label
output.mkdir(parents=True,exist_ok=True)
entries=defaultdict(dict)
pooled=defaultdict(list)
def csvout(path,header,rows):
    with path.open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(header);writer.writerows(rows)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name in sorted(z.namelist()):
        parts=Path(name).parts
        if len(parts)==1 and (name in ('provenance.json','baseline-full-round.txt','candidate-full-round.txt') or name.endswith('jar.sha256') or name in ('bootstrap.json','bootstrap.diff')):
            (output/name).write_bytes(z.read(name))
        if len(parts)!=2 or not parts[0].startswith('pair-'):continue
        if parts[1] in ('frames.csv','state.csv','summary.txt','composited-intervals.csv','render-completion-intervals.csv'):
            dest=output/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(z.read(name))
    for f in sorted(output.glob('pair-*/'+('composited-intervals.csv' if backend=='gpu' else 'render-completion-intervals.csv'))):
        _,pair,mode,side=f.parent.name.split('-')
        summary=(f.parent/'summary.txt').read_text().splitlines()
        renderer=next(x for x in summary if x.startswith('renderer='))
        assert ('nvidia' in renderer.lower() and '1660' in renderer and 'software' not in renderer.lower()) if backend=='gpu' else renderer=='renderer=software',renderer
        frame_rows=list(csv.DictReader((f.parent/'frames.csv').open(encoding='utf-8-sig')))
        for row in csv.DictReader(f.open(encoding='utf-8-sig')):
            phase=row['phase']; times=[];prev=None
            for x in frame_rows:
                if x['phase']!=phase:continue
                k=int(x['composited_gl_frame_id'])
                if backend=='gpu' and (k<0 or k==prev):continue
                prev=k;times.append(int(x['time_ns']))
            values=[(b-a)/1e6 for a,b in zip(times,times[1:])]
            if len(values)!=int(row['intervals']):raise ValueError((f,len(values),row))
            vs=sorted(values)
            q=[vs[math.ceil(len(vs)*v)-1] for v in (.5,.95,.99)]
            assert all(abs(a-float(row[b]))<.001 for a,b in zip(q,('p50_ms','p95_ms','p99_ms')))
            assert sum(x>100 for x in values)==int(row['over_100_ms'])
            assert all(v > 0 for v in values)
            entries[(mode,phase,int(pair))][side]=q
            pooled[(mode,phase,side)].extend(values)
overall=[];paired=[]
for (mode,phase,side),samples in sorted(pooled.items()):
    samples.sort()
    overall.append([mode,phase,side,len(samples),*[round(samples[math.ceil(len(samples)*q)-1],3) for q in (.5,.95,.99)],*[sum(x>n for x in samples) for n in (33.3,50,100)]])
for mode in ('solo','tcp'):
    for phase in ('idle','moving'):
        rows=[v for (m,p,n),v in entries.items() if m==mode and p==phase and set(v)=={'baseline','candidate'}]
        if not rows:continue
        paired.append([mode,phase,len(rows),*[round(statistics.median(r[s][i] for r in rows),3) for s in ('baseline','candidate') for i in range(3)],sum(r['candidate'][1]<r['baseline'][1] for r in rows),round(statistics.median(100*(r['candidate'][1]/r['baseline'][1]-1) for r in rows),2)])
csvout(output/'pooled.csv',['mode','phase','revision','samples','p50_ms','p95_ms','p99_ms','over_33_3','over_50','over_100'],overall)
csvout(output/'paired.csv',['mode','phase','full_pairs','before_p50','before_p95','before_p99','after_p50','after_p95','after_p99','pairs_with_lower_p95','median_paired_p95_percent'],paired)
print(json.dumps({'backend':backend,'paired':paired,'pooled':overall}))
