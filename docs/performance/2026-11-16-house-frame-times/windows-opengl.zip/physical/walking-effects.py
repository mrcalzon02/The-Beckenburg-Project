"""Summarize the entire movement interval on the Windows software review."""
import csv
import sys
from pathlib import Path
root=Path(__file__).parent/'physical-evidence'/sys.argv[1]
out=root/'walking-effects.csv'
with out.open('w',newline='') as dest:
    writer=csv.writer(dest)
    writer.writerow(['trial','mode','side','moving_frames','max_post_geometry_ms','max_post_geometry_frame','max_render_ms','max_completion_gap_ms','effects_over_200_ms','longest_gap_ending_frame','width','height'])
    for src in sorted(root.glob('pair-*/frames.csv')):
        _, n, mode, side=src.parent.name.split('-')
        rows=[f for f in csv.DictReader(src.open()) if f['phase']=='moving']
        if len(rows)<2: continue
        post=[int(f['effects_ns'])/1e6 for f in rows]
        total=[int(f['render_ns'])/1e6 for f in rows]
        stamps=[int(f['time_ns']) for f in rows]
        gaps=[(b-a)/1e6 for a,b in zip(stamps,stamps[1:])]
        writer.writerow([n,mode,side,len(rows),round(max(post),3),post.index(max(post))+1,round(max(total),3),round(max(gaps),3),sum(v>200 for v in post),gaps.index(max(gaps))+2,rows[0]['width'],rows[0]['height']])
print(out)
