"""Describe the application work on the callback that closed each measured interval."""
import csv
import math
from collections import Counter, defaultdict
from pathlib import Path
import sys

directory = Path(__file__).parent / 'physical-evidence' / (sys.argv[2] if len(sys.argv)>2 else sys.argv[1])
groups = defaultdict(list)
phases = {'idle', 'moving'}
for file in sorted(directory.glob('pair-*/frames.csv')):
    if not (file.parent / ('composited-intervals.csv' if sys.argv[1]=='gpu' else 'render-completion-intervals.csv')).exists():
        continue
    _, pair, mode, side = file.parent.name.split('-')
    if side != 'candidate':
        continue
    previous = {}
    for frame in csv.DictReader(file.open(encoding='utf-8-sig')):
        phase = frame['phase']
        if phase not in phases:
            continue
        frame_id = int(frame['composited_gl_frame_id'])
        stamp = int(frame['time_ns'])
        prior = previous.get(phase)
        if sys.argv[1]=='gpu' and (frame_id < 0 or prior and frame_id == prior[0]):
            continue
        previous[phase] = (frame_id, stamp)
        if prior is None:
            continue
        groups[mode, phase].append(((stamp - prior[1]) / 1e6, frame))
def q(values,p):
    return sorted(values)[math.ceil(len(values)*p)-1]
def describe(rows):
    return [len(rows), round(q([pair[0] for pair in rows], .5),1), *[
        round(q([int(row[1][field])/1e6 for row in rows],.5),1)
        for field in ['render_ns','build_ns','geometry_ns','effects_ns']
    ], min(int(row[1]['shadow_rays']) for row in rows), max(int(row[1]['shadow_rays']) for row in rows)]
with (directory/'stage-timing.csv').open('w',newline='') as out:
    table = csv.writer(out)
    table.writerow(['mode','phase','group','interval_count','p50_interval_ms','p50_render_ms','p50_build_ms','p50_geometry_ms','p50_effects_ms','min_rays','max_rays'])
    for (mode, phase), rows in sorted(groups.items()):
        threshold = q([p[0] for p in rows], .95)
        for name, subset in [('all',rows),('slowest_five_percent',[x for x in rows if x[0] >= threshold])]:
            result=[mode,phase,name,*describe(subset)]
            table.writerow(result)
            print(*result)
