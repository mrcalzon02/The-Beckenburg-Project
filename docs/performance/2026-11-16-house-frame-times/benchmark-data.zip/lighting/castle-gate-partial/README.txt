Partial completed-frame workload evidence only, no successful end-to-end run or frame-time claim.
Reference source 7225b34abd7da5213623e6e7ed4f79ed1657a0f4, Java 17, OpenGL llvmpipe
(LLVM 19.1.7, 256 bits), 4.5 Core Profile, Mesa 25.0.7-2+deb13u1.

The original hosted WorldResidencyGpuReview "castle-door" sample both restores all room
power and opens the gate. This diagnostic changes the gate with room power already on.
The camera matches its Castle door review with the 0.04 radian turn already applied.
Clock = 4.3. Flashlight off. Frame = 640x400. The first and second open/close pairs were
written synchronously only after matching the OpenGL readback frame ID and upload counters.
The local process subsequently exited 137; all power-only and final combined steps were
unreached. Other constrained retries did not finish and provide no additional measurements.
The hosted mixed sample remains the evidence for the combined power/gate transition.

Each gate opening counted 15,831 rays, and closing counted 15,727. The first
opening submitted 454,560 mesh bytes; the other three changed frames submitted
375,072 bytes each. Every unchanged readback after a toggle counted zero bytes and zero
shadow rays. Color and depth checksums are identical at this fixed camera. These rows
measure work caused by an offscreen gate and do not assess near-gate visual quality.
"upload_bytes" excludes textures. "shadow_rays" is scene CPU work. Color CRC32 is
of little-endian ARGB ints. Depth CRC32 is of the raw little-endian float bits of
GPU readback linearized in metres. No timing from this local probe is being reported.

From a checkout with the reference GPU jar and a display available, run:
    mkdir -p /tmp/beck-door-probe
    javac --release 17 -cp gpu-client/target/BeckenburgGPU.jar -d /tmp/beck-door-probe CastleDoorFactorReview.java
    java -Xmx2g -cp /tmp/beck-door-probe:gpu-client/target/BeckenburgGPU.jar org.beckenburg.CastleDoorFactorReview /tmp/beck-castle-door
