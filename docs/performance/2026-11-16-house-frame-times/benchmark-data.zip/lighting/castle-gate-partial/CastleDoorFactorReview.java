package org.beckenburg;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.CRC32;
import org.beckenburg.gpu.GpuDesktop;

/** One-at-a-time gate and power changes at fixed camera and simulation clock. */
public final class CastleDoorFactorReview {
    private final SceneRenderer renderer = new SceneRenderer();
    private final CastleHubMap castle = new CastleHubMap();
    private final String gate = CastleDoorSlots.all().stream().filter(s -> s.gate()).findFirst().orElseThrow().id();
    private final Method frame;
    private final StringBuilder data = new StringBuilder("step,power,gate_open,frame,color_crc32,unsigned_gl_depth_crc32\n");

    private CastleDoorFactorReview() throws ReflectiveOperationException {
        frame = WorldResidencyGpuReview.class.getDeclaredMethod("frame", String.class, SceneRenderer.class,
                HouseMap.class, CastleHubMap.class, double.class, boolean.class);
        frame.setAccessible(true);
        renderer.setRenderSize(640, 400);
        renderer.roomLights = new RoomLighting();
        renderer.lamp = false;
        renderer.x = 32.3;
        renderer.z = 27.5;
        renderer.eyeHeight = 1.55;
        renderer.yaw = -Math.PI / 2 + .04;
        renderer.pitch = -.08;
    }

    private static void putInt(CRC32 digest, int value) {
        for (int i = 0; i < 4; i++) digest.update(value >>> (8*i));
    }

    private void measure(Path out, String label, boolean power) throws Exception {
        var result = (GpuWorldRenderer.Result) frame.invoke(null, label, renderer, null, castle, 4.3, power);
        var rgb = new CRC32();
        for (int color : result.argb()) putInt(rgb, color);
        var depth = new CRC32();
        for (float value : result.depth()) putInt(depth, Float.floatToRawIntBits(value));
        data.append(label).append(',').append(power).append(',').append(castle.doorOpen(gate))
                .append(',').append(result.frameId()).append(',').append(rgb.getValue()).append(',')
                .append(depth.getValue()).append('\n');
        Files.writeString(out.resolve("states.csv"), data);
    }

    private void run(Path out) throws Exception {
        measure(out, "cold", true);
        measure(out, "warm-repeat", true);
        for (int pair = 1; pair <= 3; pair++) {
            castle.toggleDoor(gate);
            measure(out, "gate-open-only-" + pair, true);
            measure(out, "gate-open-only-" + pair + "-repeat", true);
            castle.toggleDoor(gate);
            measure(out, "gate-close-only-" + pair, true);
            measure(out, "gate-close-only-" + pair + "-repeat", true);
        }
        measure(out, "power-off-only", false);
        measure(out, "power-off-only-repeat", false);
        measure(out, "power-on-only", true);
        measure(out, "power-on-only-repeat", true);
        measure(out, "power-off-pre-combined", false);
        castle.toggleDoor(gate);
        measure(out, "gate-open-power-on", true);
        measure(out, "gate-open-power-on-repeat", true);
        Files.writeString(out.resolve("renderer.txt"), GpuWorldRenderer.active().rendererDescription()+"\n");
    }

    public static void main(String[] args) throws Exception {
        var out = Path.of(args[0]);
        Files.createDirectories(out);
        System.setProperty("beckenburg.residency.review.output", out.toString());
        Method start = GpuDesktop.class.getDeclaredMethod("startGpu");
        Method stop = GpuDesktop.class.getDeclaredMethod("stopReviewGpu");
        start.setAccessible(true);
        stop.setAccessible(true);
        start.invoke(null);
        try {
            new CastleDoorFactorReview().run(out);
        } finally {
            stop.invoke(null);
        }
    }
}
