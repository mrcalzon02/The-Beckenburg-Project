package org.beckenburg;
import java.util.Random;
import dev.mrcalzon.lighting.LightModel;
public class AliasProbe {
  public static void main(String[] args) {
    var open=new HouseMap(HouseMap.Site.HOUSE);
    var closed=new HouseMap(HouseMap.Site.HOUSE);
    var door=open.level().portals().stream().filter(p->p.door()&&(p.a()==0||p.b()==0)).findFirst().orElseThrow();
    open.toggleDoor(door.id()); System.out.println(door);
    var lighting=new FixtureLighting(open);
    var sources=lighting.sources().stream().filter(s->LightModel.portalInfluences(s.x(),s.y(),s.z(),s.radius(),door.x(),door.y(),door.z(),door.width(),door.alongX())).toList();
    var random=new Random(1881223151L);
    int aliases=0;
    for(int i=0;i<200000;i++){
      double x=Math.rint((door.x()+(random.nextDouble()-.5)*10)*16)/16,y=Math.rint((door.y()+.05+random.nextDouble()*2.7)*16)/16,z=Math.rint((door.z()+(random.nextDouble()-.5)*10)*16)/16;
      double dx=(random.nextDouble()-.5)*.060,dy=(random.nextDouble()-.5)*.060,dz=(random.nextDouble()-.5)*.060;
      int room=open.roomAt(x,y,z);
      if(room<0||room>=12||room!=open.roomAt(x+dx,y+dy,z+dz))continue;
      for(var s:sources){
        if(Math.pow(s.x()-x,2)+Math.pow(s.y()-y,2)+Math.pow(s.z()-z,2)>s.radius()*s.radius())continue;
        boolean a=ArchitecturalLightOcclusion.visible(open,room,s.x(),s.y(),s.z(),x,y,z),
                b=ArchitecturalLightOcclusion.visible(open,room,s.x(),s.y(),s.z(),x+dx,y+dy,z+dz);
        if(a==b)continue;
        boolean c=ArchitecturalLightOcclusion.visible(closed,room,s.x(),s.y(),s.z(),x,y,z),
                d=ArchitecturalLightOcclusion.visible(closed,room,s.x(),s.y(),s.z(),x+dx,y+dy,z+dz);
        if(c!=d||c==a&&d==b)continue;
        if(++aliases>50)break;
        var cacheField = new FixtureLighting(open); var liveField=new FixtureLighting(open);
        var cache = cacheField.newStationaryShadows();
        FixtureLighting.RGB first=null,after=null,fresh=null;
        for(int step=0;step<3;step++){
          if(step>0)open.toggleDoor(door.id());
          liveField.frame(null,0);cacheField.frame(null,0);
          var old=cacheField.useStationaryShadows(cache,cacheField.frameRevision());
          double xx=step==0?x:x+dx, yy=step==0?y:y+dy, zz=step==0?z:z+dz;
          var direct=liveField.sample(room,xx,yy,zz); var was=cacheField.sample(room,xx,yy,zz);
          if(step==0)first=was;if(step==2){after=was;fresh=direct;}
          cacheField.restoreStationaryShadows(old);
        }
        if(!after.equals(fresh)){
         System.out.printf("trial=%d room=%d source=%d A=(%.8f,%.8f,%.8f) B=(%.8f,%.8f,%.8f) open=%b,%b closed=%b,%b quantized_key=(%d,%d,%d)%n",i,room,s.id(),x,y,z,x+dx,y+dy,z+dz,a,b,c,d,Math.round(x*16),Math.round(y*16),Math.round(z*16));
         System.out.println("A-first="+first+" archive-on-reopen-B="+after+" direct-on-reopen-B="+fresh+" restored_rays="+cacheField.reusedStationaryDoorShadowRays());return;
        }
      }
    }
    System.out.println("No archived colour mismatch; alias witnesses="+aliases);
  }
}
