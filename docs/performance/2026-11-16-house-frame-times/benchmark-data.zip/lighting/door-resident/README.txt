Reference game revision 7225b34abd7da5213623e6e7ed4f79ed1657a0f4. Java 17.
DoorPayloadReview records the SceneRenderer vertex arrays submitted at the House door-2 view
used by DoorOpeningFrameProfile. It checks 24 open/close transitions at internal 320x200.
This is a CPU observer. It changes neither the production renderer nor the game assets.
No driver, upload-bandwidth, or frame-time improvement is measured by this probe.

From a checkout of the reference revision with JDK 17, run ./build.sh and set JAVA_HOME to
the JDK. From the repository root compile the enclosed file and run it against the built
application classes and packaged resources (replace paths as appropriate).

    mkdir -p /tmp/beck-door-probe
    "$JAVA_HOME/bin/javac" --release 17 -cp build/classes -d /tmp/beck-door-probe DoorPayloadReview.java
    "$JAVA_HOME/bin/java" -Djava.awt.headless=true -Xmx700m -XX:+UseSerialGC -XX:ActiveProcessorCount=2 -Duser.home=/tmp/beck-door-profile -cp /tmp/beck-door-probe:build/classes org.beckenburg.DoorPayloadReview door-resident-fields.csv

Each row compares a positive-ID resident batch's new revision to its preceding resident
array. Fields x/y/z/u/v/r/g/b count changed float bit patterns. changed_runs counts
contiguous sequences of changed vertices inside that single batch. The hosted Windows
door-submission-resources.csv independently confirms these 18 IDs, sizes and 24 changes.

All 24 transitions filled 18 revised eight-float buffers of 12,558 vertices,
401,856 bytes per transition. Position and UV bits were identical across all revisions.
Only the three RGB fields changed, on 3,938--3,944 vertices in 1,007--1,009 runs
per transition. Six worn hiding-cupboard (oak, pine and brass) batches represented
218,112 bytes. Three shell wood batches represented 117,504 bytes. A full RGB-only
stream for the same 12,558 vertices would be 150,696 bytes. That last figure is an
arithmetic payload bound; it does not include driver costs or constitute a speedup.
