package org.beckenburg;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Trace which members of each retained GPU vertex changed around the test House door. */
public final class DoorPayloadReview implements GpuWorldRenderer {
    private record Revision(long revision, float[] vertices) {}
    private record Diff(int frame, int toggle, String phase, boolean open, long id, int material,
                        int vertices, int changed, int runs, int[] fields) {}

    private final Map<Long, Revision> previous = new HashMap<>();
    private final List<Diff> changes = new ArrayList<>();
    private int step;
    private boolean open;
    private long scene = -1;

    @Override public boolean ready() { return true; }
    @Override public Result latest() { return null; }
    @Override public String rendererDescription() { return "CPU submission recorder"; }

    @Override public void submit(Frame frame) {
        if (scene != -1 && scene != frame.sceneId()) throw new AssertionError("Scene changed");
        scene = frame.sceneId();
        for (var surface : frame.surfaces()) {
            if (surface.resourceId() == 0) continue;
            var current = surface.vertices();
            var old = previous.get(surface.resourceId());
            if (old != null && old.revision() == surface.revision()) continue;
            previous.put(surface.resourceId(), new Revision(surface.revision(), current));
            if (old == null) continue;
            var prior = old.vertices();
            if (current.length != prior.length) throw new AssertionError("Changed vertex count");
            int changed = 0, runs = 0, lastChanged = -2;
            int[] fields = new int[8];
            for (int v = 0; v < current.length / 8; v++) {
                boolean touched = false;
                for (int field = 0; field < 8; field++) {
                    int i = v * 8 + field;
                    if (Float.floatToRawIntBits(current[i]) != Float.floatToRawIntBits(prior[i])) {
                        fields[field]++;
                        touched = true;
                    }
                }
                if (touched) {
                    changed++;
                    if (v != lastChanged + 1) runs++;
                    lastChanged = v;
                }
            }
            int phase = (step - 14) % 4;
            String label = step < 14 ? "pre-toggle" : phase == 0 ? "toggle" : phase == 3 ? "recovery" : "swing";
            changes.add(new Diff(step, (step - 14) / 4, label, open, surface.resourceId(),
                    surface.material(), current.length / 8, changed, runs, fields));
        }
    }

    private void run(Path output) throws Exception {
        GpuWorldRenderer.install(this);
        var map = new HouseMap(HouseMap.Site.HOUSE);
        var door = map.level().portals().stream().filter(p -> p.door() && (p.a() == 0 || p.b() == 0))
                .findFirst().orElseThrow();
        var renderer = new SceneRenderer();
        renderer.setRenderSize(320, 200);
        renderer.x = door.x() + (door.alongX() ? 0 : 1.4);
        renderer.z = door.z() + (door.alongX() ? 1.4 : 0);
        renderer.eyeHeight = door.y() + 1.62;
        renderer.yaw = Math.atan2(door.x() - renderer.x, door.z() - renderer.z);
        renderer.pitch = -.03;
        renderer.lamp = false;
        for (step = 0; step < 14 + 24 * 4; step++) {
            if (step >= 14 && (step - 14) % 4 == 0) map.toggleDoor(door.id());
            open = map.doorOpen(door.id());
            renderer.drawPractice(map, List.of(), step / 30.0);
            if (step >= 14 && (step - 14) % 4 != 3) Thread.sleep(35);
        }

        // Resolve owners after capture so loading a model cannot shift material IDs.
        Map<Integer, String> owners = new HashMap<>();
        for (String asset : List.of("level_hiding_cupboard_worn", "tv_remote_mp_1", "tv_table_1_4",
                "carpet_mp_1", "photo_frame_mp_1")) {
            for (var face : GlbProps.model(asset).triangles()) owners.put(face.material(), asset);
        }
        var csv = new StringBuilder("frame,toggle,phase,door_open,resource_id,material,model,material_name,vertices,changed_vertices,changed_runs,x,y,z,u,v,r,g,b\n");
        for (var d : changes) {
            String materialName = switch (d.material()) {
                case LevelMaterials.PLASTER -> "plaster";
                case LevelMaterials.WOOD -> "wood";
                case LevelMaterials.FLOOR -> "floor";
                default -> GlbProps.materialName(d.material());
            };
            csv.append(d.frame()).append(',').append(d.toggle()).append(',').append(d.phase()).append(',')
                    .append(d.open()).append(',').append(d.id()).append(',').append(d.material()).append(',')
                    .append(owners.getOrDefault(d.material(), "level material")).append(',')
                    .append('"').append(materialName.replace("\"", "\"\"")).append('"').append(',')
                    .append(d.vertices()).append(',').append(d.changed()).append(',').append(d.runs());
            for (int count : d.fields()) csv.append(',').append(count);
            csv.append('\n');
        }
        Files.writeString(output, csv);
    }

    public static void main(String[] args) throws Exception {
        new DoorPayloadReview().run(Path.of(args[0]));
    }
}
