package org.beckenburg;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Per-frame crossover of the production sanctuary shader and a renamed baseline copy.
 * Both variants see the same game-captured RGB/depth, camera and dynamic clock; the first measured variant alternates. */
public final class PairedHaze {
    private record Eye(double x,double y,double z,double yaw,double pitch) {}

    private record View(Eye eye,int[] rgb,double[] depth,int depthHash) {}
    private static void benchmark(Path output,boolean moving) throws Exception {
        Files.createDirectories(output);
        Path dump=output.resolveSibling("capture-"+moving+".bin");
        int width=960,height=540;
        double focalLength;
        SafeAreaBarrier.Volume area;
        View[] views=new View[moving?8:1];
        if(!Files.exists(dump)){
            var map=new HouseMap(HouseMap.Site.HOUSE);
            var scene=new SceneRenderer();
            scene.setRenderSize(width,height);
            var spawn=map.van().spawn(0);
            scene.roomLights=new RoomLighting();scene.roomLights.setBreaker(true);
            Field focal=SceneRenderer.class.getDeclaredField("focal");focal.setAccessible(true);
            focalLength=focal.getDouble(scene);
            area=SafeAreaBarrier.van(map.van());
            Path temp=dump.resolveSibling(dump.getFileName()+".tmp");
            try(var out=new java.io.DataOutputStream(new java.io.BufferedOutputStream(Files.newOutputStream(temp)))){
                out.writeDouble(focalLength);
                for(double value:new double[]{area.x(),area.y(),area.z(),area.radius(),area.shoulder(),area.height()})out.writeDouble(value);
                for(int i=0;i<views.length;i++){
                    double angle=i*Math.PI/4;
                    scene.x=spawn.x()+.22*Math.sin(angle);scene.z=spawn.z()+.18*(1-Math.cos(angle));
                    scene.eyeHeight=map.van().floorY()+HunterPosture.STANDING_EYE;
                    scene.pitch=-.08+.04*Math.sin(angle);scene.yaw=-Math.PI/2+.38*Math.sin(angle);
                    scene.drawNetwork(map,List.of(),-1,1);
                    for(double value:new double[]{scene.x,scene.eyeHeight,scene.z,scene.yaw,scene.pitch})out.writeDouble(value);
                    for(int value:scene.image().getRGB(0,0,width,height,null,0,width))out.writeInt(value);
                    for(double value:scene.depths())out.writeDouble(value);
                }
            }
            Files.move(temp,dump);
        }
        if(System.getProperty("captureOnly")!=null)return;
        try(var in=new java.io.DataInputStream(new java.io.BufferedInputStream(Files.newInputStream(dump)))){
            focalLength=in.readDouble();
            area=new SafeAreaBarrier.Volume(in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble());
            for(int i=0;i<views.length;i++){
                var eye=new Eye(in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble());
                int[] rgb=new int[width*height];double[] depth=new double[rgb.length];
                for(int j=0;j<rgb.length;j++)rgb[j]=in.readInt();
                for(int j=0;j<rgb.length;j++)depth[j]=in.readDouble();
                views[i]=new View(eye,rgb,depth,Arrays.hashCode(depth));
            }
        }
        int hold=Integer.getInteger("holdFrames",1);
        if(hold<1)throw new IllegalArgumentException("holdFrames must be positive");
        int[][] scratch={new int[width*height],new int[width*height]};
        var areas=List.of(area);
        var cache=new SafeAreaHaze.RayCache();
        var thread=java.lang.management.ManagementFactory.getThreadMXBean();
        if(!thread.isCurrentThreadCpuTimeSupported())throw new IllegalStateException("Thread CPU clock unavailable");
        if(!thread.isThreadCpuTimeEnabled())thread.setThreadCpuTimeEnabled(true);
        try(var csv=Files.newBufferedWriter(output.resolve("paired.csv"))){
            csv.write("frame,first,base_ns,candidate_ns,base_cpu_ns,candidate_cpu_ns,changed,rgb_hash,depth_hash\n");
            int[] counts=new int[2];
            long[] elapsed=new long[2],cpu=new long[2];
            for(int i=-40;i<160;i++){
                View view=views[Math.floorMod(Math.floorDiv(i,hold),views.length)];
                Eye eye=view.eye();
                double clock=1+i*.033;
                for(int trial=0;trial<2;trial++){
                    int variant=(i+trial)&1;
                    int[] rgb=scratch[variant];
                    System.arraycopy(view.rgb(),0,rgb,0,rgb.length);
                    long cpuStart=thread.getCurrentThreadCpuTime(),start=System.nanoTime();
                    if(variant==0)
                        counts[0]=BaselineSafeAreaHaze.draw(rgb,view.depth(),width,height,focalLength,eye.x(),eye.y(),eye.z(),eye.yaw(),eye.pitch(),clock,areas);
                    else
                        counts[1]=SafeAreaHaze.draw(rgb,view.depth(),width,height,focalLength,eye.x(),eye.y(),eye.z(),eye.yaw(),eye.pitch(),clock,areas,cache);
                    elapsed[variant]=System.nanoTime()-start;
                    cpu[variant]=thread.getCurrentThreadCpuTime()-cpuStart;
                }
                if(counts[0]!=counts[1]||!Arrays.equals(scratch[0],scratch[1])||Arrays.hashCode(view.depth())!=view.depthHash())
                    throw new AssertionError("per-pixel parity failed at frame "+i);
                if(i>=0)csv.write(String.format(Locale.ROOT,"%d,%d,%d,%d,%d,%d,%d,%d,%d%n",
                    i,i&1,elapsed[0],elapsed[1],cpu[0],cpu[1],counts[0],Arrays.hashCode(scratch[0]),view.depthHash()));
                if(i>=0&&i%10==0)csv.flush();
            }
        }
    }

    public static void main(String[] args)throws Exception{
        benchmark(Path.of(args[0]),args[1].equals("moving"));
    }
}
