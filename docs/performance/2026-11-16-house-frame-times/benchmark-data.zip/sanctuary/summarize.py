import csv
import json
import math
import statistics
import sys
from pathlib import Path

def quantiles(values):
    ordered = sorted(values)
    return [round(ordered[math.ceil(len(ordered) * p) - 1], 3) for p in (0.5, 0.95, 0.99)]

for filename in sys.argv[1:]:
    rows = list(csv.DictReader(Path(filename).open()))
    if not rows:
        continue
    result = {"samples": len(rows)}
    for key in ("base_ns", "candidate_ns", "base_cpu_ns", "candidate_cpu_ns"):
        result[key.replace("_ns", "_ms")] = quantiles([int(row[key]) / 1_000_000 for row in rows])
    ratios = [int(row["candidate_cpu_ns"]) / int(row["base_cpu_ns"]) for row in rows]
    result["median_paired_cpu_change_pct"] = round((statistics.median(ratios) - 1) * 100, 2)
    print(filename, json.dumps(result))
