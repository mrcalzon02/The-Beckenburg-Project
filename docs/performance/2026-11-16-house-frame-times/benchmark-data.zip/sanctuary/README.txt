House van sanctuary shader, Java 17, 960x540, baseline d5222b831cf7f7946623aecca21983cbb3469a1c.
160 measured paired calls per route after 40 warmup pairs; baseline/candidate alternate first position each frame.
Every pair starts from identical RGB and raw game depth from one stationary view or eight distinct moving views.
The camera, render size, region and animation clock match per pair. The CPU clock measures current-thread CPU.
Pixel arrays and changed-pixel counts are compared directly after each pair; the depth hash is rechecked every frame.
Times in CSVs are nanoseconds. These CSVs are shader-only, not full frametimes. The rendered input already includes
world composition; it is used as a deterministic color backing for an additional timed shader pass. Ambient host
load varied; use matched per-pair CPU for kernel costs and separate actual game runs for player experience.

Reproduce from the existing repository's Java 17 runtime/test classpath, in the repo root, using these two files:
  git show d5222b831cf7f7946623aecca21983cbb3469a1c:src/main/java/org/beckenburg/SafeAreaHaze.java | sed 's/\bSafeAreaHaze\b/BaselineSafeAreaHaze/g' > BaselineSafeAreaHaze.java
  javac --release 17 -cp "$GAME_CLASSES" -d "$OUT" BaselineSafeAreaHaze.java PairedHaze.java
  java -XX:+UseSerialGC -Xmx500m -DcaptureOnly=true -cp "$OUT:$GAME_CLASSES" org.beckenburg.PairedHaze results/still still
  java -XX:+UseSerialGC -Xmx500m -DcaptureOnly=true -cp "$OUT:$GAME_CLASSES" org.beckenburg.PairedHaze results/moving moving
  java -XX:+UseSerialGC -Xms64m -Xmx144m -cp "$OUT:$GAME_CLASSES" org.beckenburg.PairedHaze results/still still
  java -XX:+UseSerialGC -Xms64m -Xmx144m -cp "$OUT:$GAME_CLASSES" org.beckenburg.PairedHaze results/moving moving

The turn-stop route holds each of eight viewpoints for four frames (run moving with -DholdFrames=4).
Phase 0 is a changed camera, phase 1 populates the cache, phases 2 and 3 reuse it.

Folders lean-still and lean-moving are the first matched process for each mode; replicate-still and
replicate-moving are fresh-process repeats pinned on another CPU. No timer wraps image hashing or input copies.

The checked-in SafeAreaHazeDepthReview also exercises immutable camera, lens and shell changes, inside/outside,
changing depth, boundary nextUp/nextDown samples, and independent unculled analytic intersections. Tests additionally
checked HidingAreaHazeTest and SafeAreaHazeTest. The shipping cache initializes on a repeated camera pose, keeping
a single array at most one full render target per renderer (3.96 MiB at 960x540 and 15.82 MiB maximum at 1080p).
