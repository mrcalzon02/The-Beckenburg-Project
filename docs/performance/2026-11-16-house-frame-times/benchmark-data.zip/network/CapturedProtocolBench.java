package org.beckenburg;

import com.sun.management.ThreadMXBean;
import java.io.*;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class CapturedProtocolBench {
    // Only the in-process capture/replay timing is persisted. Gameplay messages, ephemeral
    // credentials and socket endpoints are excluded from the output.
    static byte[] capture() throws Exception {
        var records = new CopyOnWriteArrayList<String>();
        var lobby = new CountDownLatch(1);
        var started = new CountDownLatch(1);
        var view = new CountDownLatch(1);
        try (var host = new LanHost("127.0.0.1", 0, GhostIdentity.Type.SPIRIT, CustomContract.standard(2), false, true, HouseMap.Site.HOUSE);
             var owner = new LanClient("127.0.0.1",host.port(),false,"Owner","",host.localOwnerCredential(),line -> {
                 records.add(line);
                 if (line.equals("LOBBY|2|HUMAN|3|WAITING")) lobby.countDown();
                 if (line.startsWith("INFO|mission started")) started.countDown();
                 if (line.equals("ACCEPT|VIEW3D")) view.countDown();
             });
             var hunter = new LanClient("127.0.0.1",host.port(),false,"Other",line -> {});
             var ghost = new LanClient("127.0.0.1",host.port(),true,"Ghost",line -> {})) {
            owner.ready(); hunter.ready(); ghost.ready();
            if (!lobby.await(8,TimeUnit.SECONDS)) throw new AssertionError("missing lobby");
            owner.start();
            if (!started.await(8,TimeUnit.SECONDS)) throw new AssertionError("missing start");
            owner.view3D();
            if (!view.await(8,TimeUnit.SECONDS)) throw new AssertionError("missing view");
            Thread.sleep(2000);
        }
        return (String.join("\n",records)+"\n").getBytes(StandardCharsets.US_ASCII);
    }

    static List<String> decode(byte[] data, boolean candidate) throws IOException {
        try (var reader = source(data,candidate)) {
            var all = new ArrayList<String>();
            for (String s; (s=LanProtocol.read(reader))!=null;) all.add(s);
            return all;
        }
    }
    static Reader source(byte[] data, boolean candidate) {
        var bytes = new ByteArrayInputStream(data);
        return candidate ? LanProtocol.reader(bytes) : new InputStreamReader(bytes, StandardCharsets.US_ASCII);
    }
    static long read(byte[] data, boolean candidate, int repeats) throws IOException {
        long sum = 0;
        for (int i=0; i<repeats; i++) try (var reader=source(data,candidate)) {
            for (String s; (s=LanProtocol.read(reader))!=null;) sum+=s.length();
        }
        return sum;
    }
    public static void main(String[] args) throws Exception {
        byte[] data=capture();
        var baseline=decode(data,false);
        if (baseline.size()<100 || !baseline.equals(decode(data,true))) throw new AssertionError("Frame parity");
        var mx=(ThreadMXBean)ManagementFactory.getThreadMXBean();
        mx.setThreadAllocatedMemoryEnabled(true);
        int loops=300;
        long id=Thread.currentThread().getId();
        System.out.printf("# captured_frames=%d,captured_bytes=%d,replays_per_trial=%d%n", baseline.size(),data.length,loops);
        for(int i=0;i<4;i++)read(data,(i&1)==1,50);
        System.out.println("trial,reader,bytes_decoded,cpu_ns,allocated_bytes,characters");
        for(int trial=0;trial<12;trial++) {
            boolean candidate=trial%4==1||trial%4==2;
            long cpu=mx.getCurrentThreadCpuTime(),mem=mx.getThreadAllocatedBytes(id);
            long count=read(data,candidate,loops);
            long ns=mx.getCurrentThreadCpuTime()-cpu,alloc=mx.getThreadAllocatedBytes(id)-mem;
            if(count!=(data.length-baseline.size())*(long)loops)throw new AssertionError("Incorrect replay");
            System.out.printf("%d,%s,%d,%d,%d,%d%n",trial+1,candidate?"buffered":"legacy",data.length*(long)loops,ns,alloc,count);
        }
    }
}
