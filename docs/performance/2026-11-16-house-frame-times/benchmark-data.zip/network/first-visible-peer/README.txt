The reference game is commit 7225b34abd7da5213623e6e7ed4f79ed1657a0f4.
The runtime Java source under test does not differ from dc7e497e in these classes.
Core30 software frame captures record one effects-stage stall over 300 ms in all
eight TCP hunter trials (four baseline, four optimized), and zero in the eight
solo walking trials. They did not instrument sprite decode.

The local split probe ran the real three-seat TCP House world in fresh Java 17
processes. It records timestamps around the first peer draw and inside both
immutable sprite atlases' existing class initializers. No sampler, draw, or
physics logic is modified. Each panel warmed for ten renders plus four seconds,
then idled four seconds before holding a host-accepted walk key for three.
Software rendered 640 x 360, with two pinned CPUs, 600 MiB max heap and serial GC.
Both variants reported a visible remote hunter and nonzero host-accepted steps.
Order was baseline, candidate, candidate, baseline. A fifth solo process ran the
candidate and its zero-remote-body route initialized neither atlas.

For each matched pair, the first remote hunter draw dropped from 261.791 to
4.277 ms and from 160.893 to 2.204 ms. That frame's completion gap was 413.856
to 213.574 ms and 267.788 to 101.084 ms. The scene's effects stage on those
frames fell from 297.752 to 32.533 ms and 184.009 to 25.478 ms. Whole-walk
timing on this shared host was variable. See results.csv for full-walk p50,
p95, maximum and counts. This observation concerns a cold first remote hunter
appearance; a preceding Castle visit can already have initialized the common
directional art. No physical-device improvement is established by local timings.

The source patch begins resolving the existing idle hunter frame on one daemon
thread when LanWorldPanel handles its first valid remote BODY packet. Java class
initialization keeps publication atomic. Normal sprite draw still looks up the
same required frame and will wait if it arrives unusually early. No fallback
art or suppressed sprite is introduced. No request runs for a solo hunter with
no other hunter bodies. HunterSpriteAnimationTest, DirectionalSpritesIntegrationTest
and the three-class TCP LanHunterAnimationGameplayTest passed with the patch.

To reproduce from the pinned checkout, run the normal Java 17 build. Compile
LanViewportPerformanceReview and VerificationPreferencesFactory from src/test.
Run instrument.py with src/main/java/org/beckenburg and an empty scratch output
directory as arguments. Compile its three .java files to an overlay directory
using build/classes on the classpath. For the candidate compile LanWorldPanel
with preload.patch applied to another overlay directory. Start a new Java VM
each time with the instrumentation first on the classpath, after the patched
panel if testing the candidate. Run org.beckenburg.LanViewportPerformanceReview
with a clean per-trial output directory, assertions, java.awt.headless=true,
beckenburg.profile.idleSeconds=4, and the verification preferences factory.
The optional --solo flag checks the one-hunter path. Tools and assets are the
same on both arms. Summarize with summarize.py, pointing it at the data folder.
