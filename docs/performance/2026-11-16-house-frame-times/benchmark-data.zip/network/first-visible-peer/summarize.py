"""Compare first-time remote hunter drawing and consecutive software frame completion."""
import csv, math, re, sys
from pathlib import Path
root = Path(sys.argv[1])
with (root/'results.csv').open('w', newline='') as output:
    table=csv.writer(output)
    table.writerow(['trial','directional_load_ms','pose_load_ms','loader_thread','first_peer_draw_ms','first_peer_distance_m','moving_frame_containing_peer_draw','completion_gap_at_peer_ms','effects_at_peer_ms','all_moving_gaps','moving_p50_ms','moving_p95_ms','moving_max_ms','movement_m'])
    for trial in ('off1','on1','on2','off2','solo'):
        path=root/trial
        if not (path/'summary.txt').is_file(): continue
        with (path/'frames.csv').open() as frame_file:
            frames=[x for x in csv.DictReader(frame_file) if x['phase']=='moving']
        details=dict(x.split('=',1) for x in (path/'summary.txt').read_text().splitlines() if '=' in x)
        assert float(details['max_travel_metres'])>.1
        raw=(path/'console.log').read_text().splitlines()
        probes={x[1]:x[2:] for x in (x.split(',') for x in raw if x.startswith('HITCH,'))}
        peers=probes.get('peer_draw')
        gaps=[(int(b['time_ns'])-int(a['time_ns']))/1e6 for a,b in zip(frames,frames[1:])]
        if trial=='solo':
            assert not probes,probes
            info=['','','','','','','','']
        else:
            assert 'peer_draw' in probes and probes['sprite_load'][-1]==probes['hunter_poses'][-1] and int(details['accepted_steps'])>0
            begin=int(peers[0]); end=begin+int(peers[1])
            i=next(n for n,f in enumerate(frames) if int(f['time_ns'])>=end)
            assert i>0 and int(frames[i-1]['time_ns'])<begin
            expect='AWT-EventQueue-0' if trial.startswith('off') else 'beckenburg-peer-sprites'
            assert probes['sprite_load'][-1]==expect
            info=[round(int(probes['sprite_load'][1])/1e6,3),round(int(probes['hunter_poses'][1])/1e6,3),expect,round(int(peers[1])/1e6,3),float(peers[3]),i+1,round(gaps[i-1],3),round(int(frames[i]['effects_ns'])/1e6,3)]
        row=[trial,*info,len(gaps),*[round(sorted(gaps)[math.ceil(len(gaps)*q)-1],3) for q in (.5,.95,1)],details['max_travel_metres']]
        table.writerow(row)
        print(*row)
