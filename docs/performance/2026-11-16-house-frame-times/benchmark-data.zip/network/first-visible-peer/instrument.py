"""Insert timing-only probes into a scratch copy of two Java 17 source files."""
from pathlib import Path
import sys
src, dest = (Path(x) for x in sys.argv[1:])
def patch(name, before, after):
    path = dest / (name + '.java')
    s = path.read_text() if path.exists() else (src / (name + '.java')).read_text()
    if s.count(before) != 1: raise ValueError((name,before,s.count(before)))
    path.write_text(s.replace(before,after))
patch('SceneRenderer','        renderCharacterSprites(map,ghostRoom,visibleGhost,hunterRoom,clock,others,apparition);','''        long hitchBegin=System.nanoTime();
        renderCharacterSprites(map,ghostRoom,visibleGhost,hunterRoom,clock,others,apparition);
        long peopleDone=System.nanoTime();''')
patch('SceneRenderer','        int localRoom=map.roomAt(x,eyeHeight-.85,z);\n        GhostHauntingFolio.paint', '''        int localRoom=map.roomAt(x,eyeHeight-.85,z);
        if(peopleDone-hitchBegin>100_000_000L)System.err.printf(java.util.Locale.ROOT,"HITCH,characters,%d,%d,%d,%.3f,%.3f%n",hitchBegin,peopleDone-hitchBegin,others.size(),x,z);
        GhostHauntingFolio.paint''')
patch('SceneRenderer','            DirectionalSprites.drawHunter(pixels,depths,x,z,yaw,pitch,person,pose,\n                person.y()-(eyeHeight-1.62),lamp,renderWidth,renderHeight,focal,hunterPainVisible(person.slot(),clock));','''            long peerBegin=System.nanoTime();
            DirectionalSprites.drawHunter(pixels,depths,x,z,yaw,pitch,person,pose,
                person.y()-(eyeHeight-1.62),lamp,renderWidth,renderHeight,focal,hunterPainVisible(person.slot(),clock));
            long peerEnd=System.nanoTime();
            if(firstReportedPeer){firstReportedPeer=false;System.err.printf(java.util.Locale.ROOT,"HITCH,peer_draw,%d,%d,%d,%.3f,%s%n",peerBegin,peerEnd-peerBegin,person.slot(),distance,person.appearance());}''')
patch('DirectionalSprites','    private static final Map<String,BufferedImage> IMAGES=load();', '''    private static final long HITCH_START=System.nanoTime();
    private static final Map<String,BufferedImage> IMAGES=load();
    static {System.err.printf(java.util.Locale.ROOT,"HITCH,sprite_load,%d,%d,%d,%s%n",HITCH_START,System.nanoTime()-HITCH_START,IMAGES.size(),Thread.currentThread().getName());}''')
patch('HunterSpriteAnimation','    private static final Map<String,BufferedImage> FRAMES=load();', '''    private static final long HITCH_START=System.nanoTime();
    private static final Map<String,BufferedImage> FRAMES=load();
    static {System.err.printf(java.util.Locale.ROOT,"HITCH,hunter_poses,%d,%d,%d,%s%n",HITCH_START,System.nanoTime()-HITCH_START,FRAMES.size(),Thread.currentThread().getName());}''')

patch('SceneRenderer','    private int safeAreaPixels;','    private boolean firstReportedPeer=true;\n    private int safeAreaPixels;')
