package org.beckenburg;

import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.nio.charset.StandardCharsets;
import java.lang.management.ManagementFactory;
import com.sun.management.ThreadMXBean;

public class SocketReadProfile {
    public static void main(String[] args) throws Exception {
        byte[] bytes=CapturedProtocolBench.capture();
        int repeats=150;
        var oracle=CapturedProtocolBench.decode(bytes,false);
        var mx=(ThreadMXBean)ManagementFactory.getThreadMXBean();
        System.out.printf("# frames_per_capture=%d,bytes_per_capture=%d,replays=%d%n",oracle.size(),bytes.length,repeats);
        System.out.println("trial,reader,frames,cpu_ns,allocated_bytes,wall_ns");
        for(int trial=-4;trial<12;trial++) {
            boolean candidate=(trial&3)==1||(trial&3)==2;
            try(var server=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
                var consumer=new Socket(InetAddress.getLoopbackAddress(),server.getLocalPort());
                var producer=server.accept()) {
                var go=new CountDownLatch(1);
                var writer=new FutureTask<Void>(() -> {
                    go.await();
                    var output=producer.getOutputStream();
                    for(int i=0;i<repeats;i++)output.write(bytes);
                    producer.shutdownOutput();
                    return null;
                });
                var worker=new Thread(writer);worker.start();
                var r = candidate ? LanProtocol.reader(consumer.getInputStream()) :
                    new InputStreamReader(consumer.getInputStream(),StandardCharsets.US_ASCII);
                long cpu=mx.getCurrentThreadCpuTime(),mem=mx.getThreadAllocatedBytes(Thread.currentThread().getId()),wall=System.nanoTime();
                go.countDown();
                int frames=0;
                for (String line; (line=LanProtocol.read(r))!=null; frames++)
                    if(!oracle.get(frames%oracle.size()).equals(line))throw new AssertionError("socket ordered frame mismatch");
                long ns=mx.getCurrentThreadCpuTime()-cpu,allocation=mx.getThreadAllocatedBytes(Thread.currentThread().getId())-mem,elapsed=System.nanoTime()-wall;
                if(frames!=oracle.size()*repeats)throw new AssertionError("missing frames");
                if(trial>=0)System.out.printf("%d,%s,%d,%d,%d,%d%n",trial+1,candidate?"buffered":"legacy",frames,ns,allocation,elapsed);
                writer.get();
            }
        }
    }
}
