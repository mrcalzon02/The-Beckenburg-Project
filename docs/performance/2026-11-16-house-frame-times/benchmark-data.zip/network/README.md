# House multiplayer profiling

The source baseline was d5222b831cf7f7946623aecca21983cbb3469a1c. The combined production sources match commit 2f0727d06dac5307c2c6a4f0d384bdfa7c0df206. Production, GPU and test classes were compiled from source with Temurin 17.0.21+9. The local trials used the existing packaged art and geometry, Mesa llvmpipe 25.0.7, and a 960×540 internal target.

## TCP decoding

CapturedProtocolBench.java opens an actual local House host, connects two hunters and a human ghost, starts the case and enters the hunter world view. It replays the received game frames in process and verifies all decoded strings against the original reader. SocketReadProfile.java captures a new session and sends its data over loopback TCP. The timing window covers reads and comparisons on the receiver thread. Each trial verifies the frame count and exact order, with six interleaved trials per reader after warmup. The files store aggregate timings without message payloads.

Compile both sources into a test-classes directory with the candidate game classes on the Java 17 classpath. Run org.beckenburg.CapturedProtocolBench and org.beckenburg.SocketReadProfile in separate JVMs with those test classes and the game's runtime resources. The measured JVM used a 384 MiB maximum heap, one reported processor and CPU affinity to a single local processor.

| Six-trial medians | Previous reader | Buffered reader |
|---|---:|---:|
| In-memory thread CPU, 114,300 frames | 40.59 ms | 20.51 ms |
| In-memory thread allocation | 58,972,800 B | 22,269,600 B |
| Loopback receiver CPU, 53,850 frames | 25.34 ms | 13.48 ms |
| Loopback receiver allocation | 27,886,256 B | 9,153,632 B |

Packet cadence and command dispatch are unchanged. These results measure decoding during a burst. A normal three-seat round, a four-seat human-ghost hearing case, reconnection, disconnect, bounded backpressure, heartbeat delay/loss and van departure all passed. The TCP round transcript records evidence acquisition, host validation, rite and both hunter settlements.

## H2 entering 3D

The source's 256-frame FIFO can fill during a normal lobby-to-world transition. Windows workflow 43973076746 observed H2 receive only the connection-ended notification before its 3D acknowledgement. Ten ordinary local repetitions passed on the original code. A diagnostic deferred only that seat's writer startup for 2.6 seconds in the otherwise unchanged three-hunter room-mode extraction test. The original queue overflowed on VOICEKEY and the exact same assertion failed. The 512-frame bounded queue absorbed peak backlogs of 360, 358 and 357 in three trials and each completed the retreat. The existing van integration test now replays its real three-seat burst against an unscheduled writer. With that assertion the original code failed at frame 257 and the fix passed. The existing blocked-writer overflow test also passed.

## Viewport timing

Each hunter process runs LanViewportPerformanceReview with --gpu in its own Java 17 process. --solo selects a real solo investigation. Multiplayer opens one hunter viewport and connects two other real TCP peers, including a human-role ghost. The optional four-seat GhostViewportProfile renders the ghost and exercises moving, stillness, hearing, and spectator privacy. The hunter trials warm up for ten renders plus four seconds, then record an eight-second still view and three seconds of held movement. The renderer and application both stay live between phases.

The trial names distinguish the source baseline, the sanctuary renderer change alone (candidate), and the combined game changes (integrated). The fresh-image intervals in viewport/trials.csv count consecutive distinct framebuffer IDs and exclude phase boundaries. Render callbacks may reuse an earlier image. The original trials ran with a 1,850 MiB JVM heap ceiling. The second series used 896 MiB. All pinned the JVM and software OpenGL to CPU cores 4–6 with one Mesa worker. The host had other jobs and showed substantial frame-time variability and memory pressure. Exit 137 trials are excluded from timing comparisons, including those which wrote a summary before termination. These observations do not establish Windows GPU performance.

The first integrated House check used the six production files listed in combined-production.sha256 on the original baseline. The final-* trials use all production sources from remote commit 7225b34abd7da5213623e6e7ed4f79ed1657a0f4, including concurrent editor changes and the direct ray loop for camera motion. Its full Git tree is bb5f0abe5ab3fd116e3b534295516da57c0e5e56. No packaged asset changed between f3374fe and this tree. The ghost viewport uses the game's own 320×200 internal target and captures the visible game image. The two hunter modes use 960×540.

The final ghost trial with an 896 MiB heap exited 137 after writing its screenshot and is excluded. The successful final ghost retry used a 600 MiB maximum heap and serial garbage collection. Use its timings only as a measurement of that configuration.
