package org.beckenburg;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.lang.management.ManagementFactory;
import java.util.*;

public final class TextureStorage {
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        GlbProps.textureWidth(0);
        String[] names={"light_switch_1","ceiling_lamp_1_off","door_1_loose","shelf_mp_6","chair_mp_5","ceiling_lamp_1_on","cross_mp_2","flashlight_mp_1","monitoring_screen_mp_1"};
        var t=(com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();
        long cpu=t.getCurrentThreadCpuTime();
        int faces=0;
        for(String name:names)faces+=GlbProps.model(name).triangles().size();
        cpu=t.getCurrentThreadCpuTime()-cpu;
        var field=GlbProps.class.getDeclaredField("textures");
        field.setAccessible(true);
        Set<BufferedImage> unique=Collections.newSetFromMap(new IdentityHashMap<>());
        unique.addAll((List<BufferedImage>)field.get(null));
        long bytes=0,pixels=0;
        for(var image:unique){
            var buffer=image.getRaster().getDataBuffer();
            bytes+=(long)buffer.getSize()*buffer.getNumBanks()*DataBuffer.getDataTypeSize(buffer.getDataType())/8;
            pixels+=(long)image.getWidth()*image.getHeight();
        }
        System.out.printf(Locale.ROOT,"faces,rasters,pixels,retained_raster_bytes,model_load_cpu_ms%n%d,%d,%d,%d,%.3f%n",faces,unique.size(),pixels,bytes,cpu/1e6);
    }
}
