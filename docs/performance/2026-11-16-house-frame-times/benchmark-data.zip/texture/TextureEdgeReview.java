package org.beckenburg.gpu;
import com.badlogic.gdx.utils.GdxNativesLoader;
import org.beckenburg.GlbProps;
import java.util.LinkedHashSet;
import java.util.SplittableRandom;
public final class TextureEdgeReview {
    public static void main(String[] args) throws Exception {
        GdxNativesLoader.load();
        var updates=GpuTextureUploadProfile.class.getDeclaredMethod("checkUpdates");
        updates.setAccessible(true);
        updates.invoke(null);
        String[] assets={"light_switch_1","ceiling_lamp_1_off","door_1_loose","shelf_mp_6","chair_mp_5","ceiling_lamp_1_on","cross_mp_2","flashlight_mp_1","monitoring_screen_mp_1"};
        var ids=new LinkedHashSet<Integer>();
        for(var name:assets)for(var face:GlbProps.model(name).triangles())ids.add(face.material());
        var random=new SplittableRandom(6093);
        double[] edge={-2,-1,-Math.ulp(1d),0,Math.nextDown(1d),1,Math.nextUp(1d),2};
        int samples=0;
        for(int material:ids){
            var sampler=GlbProps.staticSampler(material);
            if(sampler==null)continue;
            for(int i=0;i<8192;i++){
                double u=i<64?edge[i/8]:random.nextDouble(-3,3);
                double v=i<64?edge[i%8]:random.nextDouble(-3,3);
                int argb=sampler.argb(u,v);
                if(argb!=GlbProps.sampleRgba(material,u,v)||(argb&0xffffff)!=GlbProps.sample(material,u,v)||(argb>>>24)!=GlbProps.sampleAlpha(material,u,v))
                    throw new AssertionError("material="+material+" uv="+u+","+v);
                samples++;
            }
        }
        System.out.println("PASS "+samples+" bound UV/color/alpha samples and static alpha ramp, live surface, CRT, van map and TV updates");
    }
}
