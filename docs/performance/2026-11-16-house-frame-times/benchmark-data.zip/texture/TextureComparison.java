package org.beckenburg.gpu;
import com.badlogic.gdx.utils.GdxNativesLoader;
import java.util.*;
import java.security.MessageDigest;
import java.lang.management.ManagementFactory;
import org.beckenburg.GlbProps;
public final class TextureComparison {
  @SuppressWarnings("unchecked")
  public static void main(String[] args) throws Exception {
    GdxNativesLoader.load();
    var firstView=GpuTextureUploadProfile.class.getDeclaredMethod("firstHouseView");
    firstView.setAccessible(true);
    Set<Integer> ids=new LinkedHashSet<>();
    if(args.length==0){ids.addAll((Set<Integer>)firstView.invoke(null));}
    else{
      String[] names={"light_switch_1","ceiling_lamp_1_off","door_1_loose","shelf_mp_6","chair_mp_5","ceiling_lamp_1_on","cross_mp_2","flashlight_mp_1","monitoring_screen_mp_1"};
      for(String name:names){for(var face:GlbProps.model(name).triangles())ids.add(face.material());}
    }
    var backend=new OpenGlWorldRenderer();
    var mx=(com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();
    var digest=MessageDigest.getInstance("SHA-256");
    long bytes=0;
    for(int id:ids){
      var p=backend.pixelsFor(id);
      try {bytes+=p.getPixels().remaining();digest.update(p.getPixels().duplicate());}
      finally {p.dispose();}
    }
    System.out.println("materials="+ids.size()+" bytes="+bytes+" sha256="+HexFormat.of().formatHex(digest.digest()));
    System.out.println("trial,cpu_ms,wall_ms,allocated_bytes");
    for(int i=0;i<5;i++){
      long cpu=mx.getCurrentThreadCpuTime(),alloc=mx.getCurrentThreadAllocatedBytes(),wall=System.nanoTime();
      for(int id:ids){var p=backend.pixelsFor(id);p.dispose();}
      System.out.printf(Locale.ROOT,"%d,%.3f,%.3f,%d%n",i,(mx.getCurrentThreadCpuTime()-cpu)/1e6,
          (System.nanoTime()-wall)/1e6,mx.getCurrentThreadAllocatedBytes()-alloc);
    }
  }
}
