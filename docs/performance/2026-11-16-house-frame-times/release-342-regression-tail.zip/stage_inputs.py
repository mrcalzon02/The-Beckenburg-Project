"""Resolve non-Hollow Creek checked-in fixture bytes from local clone object stores or verified runtime aliases."""
import subprocess,hashlib,json,os
from pathlib import Path
p=Path(__file__).resolve().parent
w=Path('/dev/shm/beck-release-707-tail/work')
repo=Path('/tmp/beck-house-707f3558/main'); rev='7b33b944df847e1eeb9ced77c43aba8dca5aab33'
repos=[repo,*Path('/workspace/scratch').glob('*/beckenburg'),p.parent.parent/'main',p.parent.parent/'followup/revision',p.parent.parent/'runner/candidate-tree',p.parent.parent/'door/worker-check/repo']
names=['development/levels/model-production/house-fridge/atlas-v1.png','development/assets/castle-museum/references/reused-models/painting_1.glb','development/assets/castle-museum/references/reused-models/carpet_mp_1.glb','development/assets/castle-training/level_castle_preparation_bench.glb','development/assets/castle-training/level_castle_preparation_bench_worn.glb','development/levels/rebuild/castle/terrain-world','installer/beckenburg.iss','.github/workflows/ship-installer.yml','build.sh','build.cmd']
rows=subprocess.check_output(['git','--no-lazy-fetch','-C',repo,'ls-tree','-r',rev,'--',*names]).decode().splitlines()
for name in ('installer','.github'):
 path=w/name
 if path.is_symlink():
  parent=path.resolve();path.unlink();path.mkdir()
  for old in parent.rglob('*'):
   dest=path/old.relative_to(parent)
   if old.is_dir():dest.mkdir(exist_ok=True);continue
   dest.symlink_to(old)
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
verified=[];missing=[]
for line in rows:
 meta,name=line.split('\t');oid=meta.split()[-1]
 dst=w/name; runtime_name=dst.name.replace('level_castle_preparation_bench','level_workbench');alt=w/'assets/runtime/models'/runtime_name
 data=None
 for src in [dst,alt]:
  if src.is_file():
   raw=src.read_bytes()
   if blob(raw)==oid:data=raw;where=str(src);break
 if data is None:
  for r in repos:
   proc=subprocess.run(['git','--no-lazy-fetch','-C',r,'cat-file','blob',oid],capture_output=True)
   if proc.returncode==0:
    data=proc.stdout;assert blob(data)==oid;where=str(r);break
 if data is None:missing.append((name,oid));continue
 if not dst.is_file() or blob(dst.read_bytes())!=oid:
  if dst.is_symlink():dst.unlink()
  dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 verified.append((name,oid,where));print(name,'staged',flush=True)
(p/'input-blobs.json').write_text(json.dumps(dict(verified=verified,missing=missing),indent=2)+'\n');print('missing',missing)
