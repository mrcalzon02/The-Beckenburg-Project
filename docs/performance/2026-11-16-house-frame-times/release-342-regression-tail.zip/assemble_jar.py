from pathlib import Path
from zipfile import ZipFile
import shutil,hashlib
p=Path(__file__).resolve().parent
w=Path('/dev/shm/beck-release-707-tail/work')
old=p.parent/'campaign-gui/concurrent/beckenburg-game.jar'
scratch=p.parent/'release-tail-build'
scratch.mkdir(exist_ok=True)
new=scratch/'beckenburg-game.jar'
classes=w/'build/classes'
selected={str(file.relative_to(classes)):file for typ in ('SafeAreaHaze','BeckenburgRegressionSuite') for file in (classes/'org/beckenburg').glob(typ+'*.class')}
assert len(selected)>=2
with ZipFile(old) as src, ZipFile(new,'w') as dst:
 for info in src.infolist():
  name=info.filename
  if name not in selected:
   with src.open(info) as f,dst.open(info,'w') as g:shutil.copyfileobj(f,g,512*1024)
  else:dst.writestr(info,selected.pop(name).read_bytes())
 for name,file in selected.items():dst.write(file,name)
with ZipFile(new) as z:
 assert z.testzip() is None
 for typ in ('SafeAreaHaze','BeckenburgRegressionSuite'):
  for file in (classes/'org/beckenburg').glob(typ+'*.class'):
   assert z.read(str(file.relative_to(classes)))==file.read_bytes()
print(new.stat().st_size,hashlib.file_digest(new.open('rb'),'sha256').hexdigest())
dest=w/'build/beckenburg-game.jar'
if not dest.exists():dest.symlink_to(new)
