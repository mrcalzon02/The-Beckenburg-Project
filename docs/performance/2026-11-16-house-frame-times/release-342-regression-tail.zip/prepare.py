"""Prepare a scratch checkout readback for the immutable release using previously verified source, classes, and resources."""
import hashlib,subprocess,shutil,os,json,pathlib,binascii,zipfile
from pathlib import Path
p=Path(__file__).resolve().parent
r=Path('/dev/shm/beck-release-707-tail')
full=Path('/workspace/scratch/bfb68f9d1548/beckenburg')
local=Path('/tmp/beck-house-707f3558')
pre=local/'rite-check'
rev='7b33b944df847e1eeb9ced77c43aba8dca5aab33'
previous='82b234b4f4b6300367b8de37373dc3dbae428674'
repo=local/'main'
def git(*args):
 return subprocess.check_output(['git','--no-lazy-fetch','-C',repo,*args])
def blob(data):
 return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def source_tree(*dirs):
 return {row.split('\t')[1]:row.split()[2] for row in git('ls-tree','-r',rev,'--',*dirs).decode().splitlines()}
def strict(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def link(src,dest):
 dest.parent.mkdir(parents=True,exist_ok=True)
 dest.symlink_to(src)
r.mkdir(parents=True,exist_ok=True)
root=r/'work'
root.mkdir(exist_ok=True)
prod_and_tests=source_tree('src','water-module/src/main/java','lighting-module/src/main/java')
sources={}
selected=[]
for n,oid in prod_and_tests.items():
 if not n.endswith('.java'):continue
 dest=root/n;dest.parent.mkdir(parents=True,exist_ok=True)
 prior=pre/n
 if prior.exists() and blob(prior.read_bytes())==oid:
  if not dest.exists():dest.symlink_to(prior)
 else:
  data=git('show',rev+':'+n);assert blob(data)==oid
  dest.write_bytes(data);selected.append(dest)
 sources[n]=oid
jar=p.parent/'campaign-gui/concurrent/beckenburg-game.jar'
assert strict(jar)=='ac5590dbe5d54979f410c1e7a107e4dfaf0c6843f695d767ab198ee3ccf0e8ac'
base=root/'build/classes';base.mkdir(parents=True,exist_ok=True)
test=root/'build/test';shutil.copytree(pre/'tests',test,dirs_exist_ok=True)
# JRE loads these through the official build/classes layout. Verify every resource against the known package.
with zipfile.ZipFile(jar) as z:
 nresources=0
 for info in z.infolist():
  name=info.filename;dest=base/name
  if name.startswith('META-INF/') or name.endswith('/'):continue
  if name.endswith('.class'):
   dest.parent.mkdir(parents=True,exist_ok=True)
   dest.write_bytes(z.read(name))
  else:
   source=full/'build/classes'/name
   assert source.stat().st_size==info.file_size and (binascii.crc32(source.read_bytes()) & 0xffffffff)==info.CRC,name
   if not dest.exists():link(source,dest)
   nresources+=1
for source in selected:
 target=test if str(source.relative_to(root)).startswith('src/test/') else base
 subprocess.run(['/tmp/beck-jdk17/bin/javac','-J-XX:+UseSerialGC','-J-Xmx120m','-J-XX:ActiveProcessorCount=2','--release','17','-encoding','UTF-8','-cp',str(base)+os.pathsep+str(test),'-d',target,source],check=True)
# Preserve full checkout paths for tests which read their checked-in fixtures. No shared build or user-home.
for name in ['.github','assets','development','tools','scripts','installer','docs','test','README.md','build.sh','build.cmd','.gitattributes']:
 if (full/name).exists() and not (root/name).exists():link(full/name,root/name)
for name in ['water-module','lighting-module']:
 src=full/name;dst=root/name
 for f in src.iterdir():
  if f.name!='src' and not (dst/f.name).exists():link(f,dst/f.name)
for f in [root/'src/main',root/'src/test']:
 f.mkdir(exist_ok=True,parents=True)
manifest=git('show',rev+':regression-tests.txt')
(root/'regression-tests.txt').write_bytes(manifest)
entries=[x.strip() for x in manifest.decode().splitlines() if x.strip() and not x.lstrip().startswith('#')]
done=(local/'exact-passed.txt').read_text().splitlines()
todo=(local/'exact-remaining.txt').read_text().splitlines()
assert entries==done+todo and len(done)==248 and len(todo)==136 and len(set(entries))==384
(p/'remaining.txt').write_text('\n'.join(todo)+'\n')
(p/'source-blobs.txt').write_text(''.join(f'{v} {k}\n' for k,v in sources.items()))
(p/'provenance.json').write_text(json.dumps(dict(commit=rev,previous_package=previous,previous_package_sha256=strict(jar),runtime_resources_read_back=nresources,verified_source_blobs=len(sources),recompiled=[str(x.relative_to(root)) for x in selected],manifest_sha256=hashlib.sha256(manifest).hexdigest(),original_passed=248,remaining=136),indent=2)+'\n')
print((p/'provenance.json').read_text())
