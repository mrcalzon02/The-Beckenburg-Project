"""Invoke only the unexecuted manifest items with the release child's Java entry point and deadline."""
from pathlib import Path
import os,subprocess,csv,sys,time,signal,re,shutil,threading
p=Path(__file__).resolve().parent
w=Path('/dev/shm/beck-release-707-tail/work')
java='/tmp/beck-jdk17/bin/java'
suite=(p/'remaining.txt').read_text().splitlines()
cl='build/classes:build/test'
opts=['-XX:ActiveProcessorCount=3','-XX:+UseSerialGC','-XX:ReservedCodeCacheSize=48m','-XX:MaxHeapFreeRatio=28','-XX:MinHeapFreeRatio=8','-XX:-ShrinkHeapInSteps','-Xms24m','-XX:-UsePerfData']
def invoke(n, directory, cap, home=None):
    timeout=180 if n=='PreparedLightBatchParityTest' else 90
    env=dict(os.environ,MALLOC_ARENA_MAX='2')
    home=home or (w/'homes'/n)
    home.mkdir(parents=True,exist_ok=True)
    temp=w/'process-tmp'/n
    temp.mkdir(parents=True,exist_ok=True)
    extra=['-XX:NewRatio=6','-XX:SoftRefLRUPolicyMSPerMB=0'] if cap>=500 else []
    if directory.name=='retry-small-native':extra=['-XX:TieredStopAtLevel=1','-XX:ReservedCodeCacheSize=24m','-Xmn20m','-XX:SoftRefLRUPolicyMSPerMB=0','-Xss384k']
    cmd=[java,*opts,*extra,'-Xmx'+str(cap)+'m','-Duser.home='+str(home),'-Djava.io.tmpdir='+str(temp),'-Djava.awt.headless=true','-ea','-cp',cl,'org.beckenburg.'+n]
    start=time.monotonic();name=directory/(n+'.log')
    if cap>=500:cmd.insert(1,'-Xlog:gc:file='+str(directory/(n+'.gc.log'))+':time,tags')
    def memory(pid,stop):
        records=[];began=time.monotonic()
        while not stop.wait(.4):
            try:
                txt=Path('/proc',str(pid),'status').read_text()
                records.append([round(time.monotonic()-began,2),*[re.search('^'+key+r':\s+(\d+)',txt,re.M).group(1) for key in ('VmRSS','VmHWM')]])
            except (FileNotFoundError,AttributeError,ProcessLookupError):break
        with (directory/(n+'.rss.csv')).open('w',newline='') as out:
            wr=csv.writer(out);wr.writerow(['seconds','rss_kib','hwm_kib']);wr.writerows(records)
    with name.open('w') as log:
        proc=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        stop=threading.Event();mem=None
        if cap>=500:
            mem=threading.Thread(target=memory,args=(proc.pid,stop));mem.start()
        try:rc=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait();rc=124
        if mem:stop.set();mem.join()
    txt=name.read_text(errors='replace')
    if rc==0:status='PASS'
    elif rc==124:status='TIMEOUT'
    elif rc in (-9,137):status='KILLED'
    elif 'OutOfMemoryError' in txt:status='HEAP'
    elif re.search(r'NoSuchFileException|FileNotFoundException|missing (asset|model|source|file)|source .*absent|not a regular file',txt,re.I):status='MISSING'
    else:status='FAILED'
    return [n,status,rc,round(time.monotonic()-start,3),cap]
def main():
    directory=p/'reports';directory.mkdir(exist_ok=True)
    args=sys.argv[1:]
    if args:
        directory=p/args.pop(0);directory.mkdir(exist_ok=True)
        cap=int(args.pop(0));tests=args
    else:cap=330;tests=suite
    path=directory/'results.csv'
    seen={r['test'] for r in csv.DictReader(path.open())} if path.exists() else set()
    with path.open('a',newline='') as out:
        wr=csv.writer(out)
        if not seen:wr.writerow(['test','result','exit','seconds','heap_mib']);out.flush()
        for n in tests:
            assert n in suite,n
            if n in seen:continue
            c=cap if args or n!='PreparedLightBatchParityTest' else 1250
            row=invoke(n,directory,c)
            print(*row[:4],flush=True);wr.writerow(row);out.flush()
if __name__=='__main__':main()
