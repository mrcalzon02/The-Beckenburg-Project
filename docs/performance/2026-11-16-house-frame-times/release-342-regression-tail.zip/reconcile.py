"""Collate all attempts without discarding failures or counting duplicate passes."""
import json,csv,hashlib,sys
from pathlib import Path
p=Path(__file__).resolve().parent
expected=(p/'remaining.txt').read_text().splitlines()
receipts={t:[] for t in expected}
for d in [p/'reports',*sorted(p.glob('retry-*'))]:
 q=d/'results.csv'
 if not q.exists():continue
 for row in csv.DictReader(q.open()):
  t=row['test']; assert t in receipts
  log=d/(t+'.log');assert log.exists()
  receipts[t].append(dict(attempt=d.name,log=f'{d.name}/{log.name}',sha256=hashlib.sha256(log.read_bytes()).hexdigest(),**row))
rows=[]
for name,attempts in receipts.items():
 passed=[a for a in attempts if a['result']=='PASS']
 a=(passed or attempts or [{}])[-1]
 rows.append(dict(test=name,final=a.get('result','PENDING'),attempt_count=len(attempts),receipt=a.get('log',''),sha256=a.get('sha256',''),seconds=a.get('seconds','')))
with (p/'final-results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
(p/'attempts.json').write_text(json.dumps(receipts,indent=2)+'\n')
from collections import Counter
print(Counter(row['final'] for row in rows));print([(r['test'],r['final']) for r in rows if r['final'] not in ('PASS','PENDING')])
