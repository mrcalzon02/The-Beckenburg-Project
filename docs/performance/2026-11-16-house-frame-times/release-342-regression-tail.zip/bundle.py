from pathlib import Path
import csv,hashlib,json,zipfile,sys,subprocess
from collections import Counter
p=Path(__file__).resolve().parent
subprocess.run([sys.executable,p/'reconcile.py'],check=True)
with (p/'final-results.csv').open() as f:rows=list(csv.DictReader(f))
t=Counter(r['final'] for r in rows)
with (p/'reports/results.csv').open() as f:initial=Counter(x['result'] for x in csv.DictReader(f))
fails=[r['test']+' ('+r['final']+')' for r in rows if r['final']!='PASS']
note=f'''# Exact v0.1.342 regression tail

Release commit `7b33b944df847e1eeb9ced77c43aba8dca5aab33`. The release manifest preflight validated 384 distinct unqualified test names and all class entry points. The exact Windows job stopped after 248 successful tests when a newer commit advanced the workflow. The 248 names in `windows-passed.txt` followed by the 136 in `remaining.txt` equal the checked-in ordered manifest after removing comments and empty lines. Its unmodified bytes have SHA-256 `{json.loads((p/'provenance.json').read_text())['manifest_sha256']}`.

On Linux, {t['PASS']} of the 136 remaining distinct tests have successful process-exit receipts. The first local pass had {dict(initial)}. `final-results.csv` selects the successful exit-0 receipt for every test that passed, and otherwise records the latest attempt. `attempts.json` lists every attempt and raw log digest. Counts refer to distinct test entry points. {'Remaining local outcomes are '+', '.join(fails)+'.' if fails else 'All 136 tail entries passed on Linux.'}

## Build and execution

Temurin Java 17.0.21+9, headless AWT, `-ea`, regular production `build/classes:build/test`, and the release suite’s 90-second limit on these tests except `PreparedLightBatchParityTest`, which has 180 seconds. Each process used an isolated writable Java home and temp folder. The committed tests and game code ran without edits. Java source verification covered 1,141 release blobs. From the previously built 82b234b4 package only four Java sources changed. All four were recompiled with `javac --release 17`. All 1,463 packaged resource files were checked by size and CRC against the source package. The release editor acceptance used a rebuilt 370,260,882-byte package, SHA-256 `1a69282ca59681f24519e2bcc945640be0b679fcc1656aaf639bd61ffb1fd147`. The exercised test and scene/source/asset inputs are listed in `provenance.json`, `source-blobs.txt`, `input-blobs.json` and `retry-hollow/fixture-inputs.json`.

`reports/` contains initial attempts, `retry-hollow/` and `retry-launch/` contain exact fixture/package reruns, and `retry-memory/` contains the retained heap-size reruns with GC logs and process RSS samples. The 330 MiB initial default was raised for the two Castle screens and renderer cases. The first `PreparedLightBatchParityTest` used 1,250 MiB. A SIGKILL is reported as a killed process, independently of a Java assertion, a Java heap error or a timeout. All process stdout/stderr, including debug messages that mention open or out-of-scope checks, is retained verbatim.
'''
(p/'README.md').write_text(note)
files=[f for f in p.iterdir() if f.is_file() and f.suffix in ('.py','.md','.csv','.txt','.json','.log') and f.name not in ('local-git.txt','local-inputs.json','archive-sha256.txt')]
for d in [p/'reports',*sorted(p.glob('retry-*'))]:
 if d.is_dir():files.extend(f for f in d.rglob('*') if f.is_file())
zipname=p.parent/'v0.1.342-exact-regression-tail.zip'
with zipfile.ZipFile(zipname,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(set(files)):z.write(f,f.relative_to(p))
with zipfile.ZipFile(zipname) as z:assert z.testzip() is None
sha=hashlib.sha256(zipname.read_bytes()).hexdigest()
(p/'archive-sha256.txt').write_text(sha+'  '+zipname.name+'\n');print(zipname.name,zipname.stat().st_size,sha)
