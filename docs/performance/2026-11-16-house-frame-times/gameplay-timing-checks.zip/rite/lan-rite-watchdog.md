# Real-time banishment regression watchdog

The advisory timeout on Windows at game revision `82b234b4f4b6300367b8de37373dc3dbae428674` reproduces with the unmodified Java 17 regression runner. The first Wraith banishment needs 900 guarded simulation ticks. Its normal four-socket host ticks every 100 ms. The default 90-second timer starts before the JVM creates the lobby, readies the seats, traverses the house, disturbs the anchor, records instrument readings, identifies the ghost, places the ward and reaches the correct installation. The test itself allows up to 130 seconds after starting to wait for the result.

| Run | Result |
|---|---|
| Exact test, direct Linux Java 17 invocation | Passed in 92.135 s |
| Original isolated subprocess through the Java regression suite | Timed out after 90 s |
| Same suite and child with the case-specific 150 s process limit | Passed in 91.180 s |

The two suite checks compiled the exact game and regression manifest classes. They used the same 384 manifest entries with the rite moved first and stopped after that test's terminal result. Both exercised the authored House, three real hunter sockets and a human ghost. The child test proves the banishment result, privacy and authority checks. Both local headless logs report optional missing illustrated lobby portraits for the three test names. The Windows installer and full-round checks provide the separate packaged-game coverage. The patch changes only this test's process watchdog. The developer regression launcher still applies 180 seconds to lighting parity and 90 seconds to the remaining tests.

[Direct test receipt](lan-rite-direct.txt) · [Original suite receipt](lan-rite-original-suite.txt) · [Updated suite receipt](lan-rite-fixed-suite.txt) · [Source SHA-256 values](lan-rite-source.sha256) · [Regression-runner patch](lan-rite-watchdog.patch)
