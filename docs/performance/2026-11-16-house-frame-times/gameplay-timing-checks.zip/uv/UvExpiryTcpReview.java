package org.beckenburg;
import java.util.*;
import org.beckenburg.LevelDefinition.Vec;
/** Pause the 10 Hz test-host clock after observing a genuine host-generated UV footprint over TCP.
 * Set only the host tick and equipment tier, keeping the powered lamp, geometry, and socket commands live. */
public final class UvExpiryTcpReview {
    static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    @SuppressWarnings("unchecked")
    public static void main(String[] args)throws Exception{
        try(var host=new LanHost("127.0.0.1",0,GhostIdentity.Type.SPIRIT);
            var a=new AuthoredLevelNetworkTest.Peer(host.port(),false,"UVTech");
            var b=new AuthoredLevelNetworkTest.Peer(host.port(),false,"Observer");
            var c=new AuthoredLevelNetworkTest.Peer(host.port(),false,"Photographer");
            var ghost=new AuthoredLevelNetworkTest.Peer(host.port(),true,"Spirit")){
            a.client.ready();b.client.ready();c.client.ready();ghost.client.ready();a.await("LOBBY|3|HUMAN|4|WAITING");a.client.start();a.await("INFO|mission started");
            a.client.view3D();a.await("ACCEPT|VIEW3D");
            var map=(HouseMap)LooseClutterNetworkTest.field(host,"map");var world=(LanWorld)LooseClutterNetworkTest.field(host,"world");var mutex=LooseClutterNetworkTest.field(host,"mutex");
            var pose=((LanGhostSpatial)LooseClutterNetworkTest.field(host,"ghostPose")).pose();
            Vec view=null;
            for(double[] delta:new double[][]{{0,-1.4},{0,1.4},{-1.4,0},{1.4,0}}){
                double x=pose.x()+delta[0],z=pose.z()+delta[1];
                if(map.traversable(x,pose.y(),z)&&map.clearLineOfSight(x,pose.y()+1.62,z,pose.x(),pose.y()+.08,pose.z())){view=new Vec(x,pose.y(),z);break;}
            }
            check(view!=null,"actual ghost position has a clear inspection approach");
            synchronized(mutex){AuthoredTestSupport.place(map,world,0,view);}
            a.client.turn(Math.floorMod((int)Math.round(Math.toDegrees(Math.atan2(pose.x()-view.x(),pose.z()-view.z()))),360));
            a.client.selectGearSlot(3);a.await("GEARSTATE|");a.client.useHeldEquipment();a.await("GEARFX|0|UV_LIGHT|1");
            String trace;
            do{trace=a.await("UVTRACE|");}while(trace.equals("UVTRACE|RESET"));
            var mark=UvEvidenceMarks.Mark.decode(LanProtocol.parts(trace));check(mark.room()==pose.room(),"host sends a genuine local surface mark");
            var clock=(java.util.concurrent.ScheduledExecutorService)LooseClutterNetworkTest.field(host,"clock");
            clock.shutdown();
            if(!clock.awaitTermination(5,java.util.concurrent.TimeUnit.SECONDS))throw new AssertionError("Host clock failed to quiesce");
            var ticks=LanHost.class.getDeclaredField("tick");ticks.setAccessible(true);
            var kits=(FieldEquipment[])LooseClutterNetworkTest.field(host,"equipment");
            System.out.println("tier,mark_born,age_ticks,host_tick,reply");
            int[] ages={1800,2400,3000};
            for(var tier:EquipmentTiers.Tier.values()){
                synchronized(mutex){if(tier!=EquipmentTiers.Tier.I)kits[0].upgrade("UV_LIGHT",tier);}
                for(int offset=0;offset<=1;offset++){
                    int age=ages[tier.ordinal()]+offset;
                    synchronized(mutex){ticks.setInt(host,mark.born()+age);}
                    a.client.scanUv();
                    String answer=a.await("ACCEPT|UVSCAN|");
                    String expected=offset==0?"ACCEPT|UVSCAN|FRESH SURFACE TRACE":"ACCEPT|UVSCAN|NO RECENT TRACE";
                    check(expected.equals(answer),"Wrong UV scan for "+tier+" age "+age+": "+answer);
                    System.out.println(tier+","+mark.born()+","+age+","+(mark.born()+age)+","+answer);
                }
            }
            check(ghost.inbox.stream().noneMatch(s->s.startsWith("UVTRACE|")||s.startsWith("GEARFX|")),"UV privacy");
        }
    }
}
