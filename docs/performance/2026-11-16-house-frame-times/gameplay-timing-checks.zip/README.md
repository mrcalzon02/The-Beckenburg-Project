# Gameplay timing checks on concurrent main

Windows run 44010028592 at 82b234b4f4b6300367b8de37373dc3dbae428674 passed packaged multiplayer, installed startup and 382 of 384 advisory regression checks. The unmodified four-socket Wraith banishment test timed out at the 90-second general process limit. The case requires 900 real 100 ms host ticks after the rite starts. The same test ran to settlement in 92.135 seconds on Java 17 without a process timeout. The patch bounds that one test to 150 seconds. Its test source SHA-256 is 8d6be1fe6330b6672afb603095a1665c10db47571380c500e01c8de53ec5c487.

The UV check used an expectation from the previous default tier lifetime. The corrected local unit fixture checks the actual final visible tick and expiry one tick later. Two TCP hosts exercised each detector tier by placing an authentic footprint and moving the controlled host clock to the exact sample ticks. All 12 network readings and four related packaged tests passed. Both changes are confined to regression checks and their runner.

With all 384 manifest entries preflighted and this test first, the stock runner timed out as expected while the corrected runner recorded a 91.180-second PASS. The diagnostic processes were stopped after this first comparison. The full Windows suite is separate.
