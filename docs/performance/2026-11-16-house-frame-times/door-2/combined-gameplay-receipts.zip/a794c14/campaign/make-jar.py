from pathlib import Path
import hashlib,subprocess,zipfile
root=Path('/tmp/beck-combined-707')
out=Path('/workspace/scratch/707f355876c5/recovery/campaign-gui')
resources=Path('/workspace/scratch/bfb68f9d1548/beckenburg/build/classes')
files={}
for p in resources.rglob('*'):
 if p.is_file() and p.suffix!='.class':
  rel=p.relative_to(resources).as_posix()
  if rel.startswith(('hbnet/','org/beckenburg/','dev/mrcalzon/weather/','dev/mrcalzon/water/','dev/mrcalzon/lighting/')):
   files[rel]=p
for p in (root/'latest/original').rglob('*.class'):
 rel=p.relative_to(root/'latest/original').as_posix()
 if '/gpu/' not in rel:files[rel]=p
jar=out/'beckenburg-game.jar'
with zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\r\nMain-Class: org.beckenburg.InvestigationGame\r\n\r\n')
 for rel,p in sorted(files.items()):z.write(p,rel)
print(len(files),'packaged .class/resources',jar.stat().st_size,'bytes',hashlib.file_digest(jar.open('rb'),'sha256').hexdigest())
