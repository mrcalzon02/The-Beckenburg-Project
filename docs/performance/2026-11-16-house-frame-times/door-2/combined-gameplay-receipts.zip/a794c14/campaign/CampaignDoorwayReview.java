package org.beckenburg;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
public final class CampaignDoorwayReview {
    static Object get(Object obj,String n)throws Exception{
        var f=obj.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(obj);
    }
    static String wait(BlockingQueue<String> q,String... prefixes)throws Exception{
        long until=System.nanoTime()+5_000_000_000L;
        while(System.nanoTime()<until){
            var s=q.poll(60,TimeUnit.MILLISECONDS);
            if(s!=null)for(String pf:prefixes)if(s.startsWith(pf))return s;
        }
        throw new AssertionError("Missing "+List.of(prefixes));
    }
    public static void main(String[] args)throws Exception{
        var dir=Files.createTempDirectory("campaign-doorway");
        var p=new ProfileStore(dir.resolve("profile.properties"));
        p.addNetworkPayout(UUID.randomUUID(),3000,0);p.reserveMissionHunters(2);
        p.purchaseCatalogGear("DOTS_PROJECTOR",EquipmentTiers.Tier.I);p.equipCatalog(3,"DOTS_PROJECTOR");
        var ch=p.dispatchStory(0);long seed=CampaignStory.missionSeed(p.storySeed(),ch.ordinal());
        try(var h=LanHost.investigation("127.0.0.1",0,ch.ghost(),CustomContract.standard(3),false,SiteCatalog.mapFor(ch.map()),null,seed)){
            h.configureCampaign(p,ch);var q=new LinkedBlockingQueue<String>();
            try(var c=new LanClient("127.0.0.1",h.port(),false,"DoorReview","",h.localOwnerCredential(),q::add)){
                c.ready();wait(q,"ACCEPT|READY","LOBBY|1|AI|1|WAITING");
                h.prepareCampaignBots(2);c.start();wait(q,"INFO|mission started");c.view3D();wait(q,"ACCEPT|VIEW3D");
                c.extract();System.out.println("LEGACY "+wait(q,"REJECT|"));
                var map=(HouseMap)get(h,"map");var w=(LanWorld)get(h,"world");var mutex=get(h,"mutex");
                System.out.println("site="+map.site()+" seed="+seed+" front="+VanStaging.FRONT+" radius=.22");
                boolean rejected=false;
                int prev=-1;
                for(int i=0;i<3000;i++){
                    boolean blocked=false;int tick;
                    StringBuilder line=new StringBuilder();
                    synchronized(mutex){
                        tick=(int)get(h,"tick");
                        if(tick!=prev){
                            for(int s=0;s<3;s++){
                                var b=w.body(s);var loc=map.van().local(b.x(),b.z());
                                boolean before=map.traversable(b.x(),b.y(),b.z());
                                boolean vanBefore=map.van().collides(b.x(),b.z(),.22);
                                map.van().setCargoDoorClosed(true);
                                boolean after=map.traversable(b.x(),b.y(),b.z());
                                boolean vanAfter=map.van().collides(b.x(),b.z(),.22);
                                map.van().setCargoDoorClosed(false);
                                blocked|=!after;
                                line.append(String.format(Locale.ROOT,"  H%d.local=(%.3f,%.3f) floor=%.3f room=%d trav=%b/%b vanSolid=%b/%b",s+1,loc.x(),loc.z(),b.y(),b.room(),before,after,vanBefore,vanAfter));
                            }
                        }
                    }
                    if(tick!=prev){
                        System.out.println("TICK "+tick+line);
                        prev=tick;
                        if((blocked&&!rejected)||(!blocked&&rejected)){
                            c.vanDoor();String answer=wait(q,"ACCEPT|VANDOOR","REJECT|");
                            System.out.println("DOOR tick="+tick+" predictedBlocked="+blocked+" reply="+answer);
                            if(answer.equals("ACCEPT|VANDOOR|CLOSED")){
                                if(!rejected)throw new AssertionError("Did not catch transit");
                                wait(q,"RESULT|","PROGRESS|");break;
                            }
                            if(!answer.equals("REJECT|van doorway occupied"))throw new AssertionError(answer);
                            rejected=true;
                        }
                    }
                    if(!h.running())break;
                    if(tick>180)throw new AssertionError("No reject-then-accept");
                    Thread.sleep(6);
                }
                if(h.running()||p.archives().size()!=1||!rejected)throw new AssertionError("Missing real reject, shutdown and single archive");
                System.out.println("VERIFIED retry closed and saved "+p.archives().get(0).outcome());
            }
        }
    }
}
