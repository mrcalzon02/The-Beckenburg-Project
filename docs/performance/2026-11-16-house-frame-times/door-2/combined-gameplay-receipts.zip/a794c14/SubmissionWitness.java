package org.beckenburg;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Same deterministic door sequence as the OpenGL lattice. Hash the actual incoming VBO payload first. */
public final class SubmissionWitness implements GpuWorldRenderer {
    Frame frame;
    Result result;
    public boolean ready(){return true;}
    public String rendererDescription(){return "production submission recorder";}
    public void submit(Frame value){
        frame=value;
        if(result==null) result=new Result(value.sceneId(),value.frameId(),value.width(),value.height(),
                new int[value.width()*value.height()],new float[value.width()*value.height()]);
        else result=new Result(value.sceneId(),value.frameId(),value.width(),value.height(),result.argb(),result.depth());
    }
    public Result latest(){return result;}
    public static void main(String[] args)throws Exception{
        boolean software=args[0].equals("photograph");
        var backend=new SubmissionWitness();
        if(!software)GpuWorldRenderer.install(backend);
        var map=new HouseMap(HouseMap.Site.HOUSE);
        var door=map.level().portals().stream().filter(p->p.id()==2&&p.door()).findFirst().orElseThrow();
        var view=new SceneRenderer();view.setRenderSize(320,200);
        view.roomLights=new RoomLighting();view.eyeHeight=door.y()+1.62;view.pitch=-.03;
        var mf=HouseMap.class.getDeclaredField("doorMotions");mf.setAccessible(true);
        @SuppressWarnings("unchecked") var active=(Map<Integer,Object>)mf.get(map);
        var motion=Class.forName("org.beckenburg.HouseMap$DoorMotion").getDeclaredConstructor(double.class,double.class,long.class);motion.setAccessible(true);
        var df=SceneRenderer.class.getDeclaredField("depths");df.setAccessible(true);
        java.lang.reflect.Field hf=null;
        try{hf=SceneRenderer.class.getDeclaredField("restoredPoseVertices");hf.setAccessible(true);}catch(NoSuchFieldException original){}
        var sha=MessageDigest.getInstance("SHA-256");
        var lookup=new HashMap<Long,Long>();
        var dynamic=new HashMap<Integer,float[]>();
        var words=ByteBuffer.allocate(8192);
        try(var out=Files.newBufferedWriter(Path.of("frames.csv"))){
            out.write("frame,group,sub,x,z,scope,count,bytes,upload_batches,digest,depth_hash,restored_vertices\n");
            for(int i=0;i<144;i++){
                int g=i<8?-1:(i-8)/17,s=i<8?-1:(i-8)%17;
                if(s==0)map.toggleDoor(2,System.nanoTime()-HouseMap.DOOR_SWING_NANOS);
                if(s>=0&&s<16){
                    double f=(map.doorOpen(2)?s:16-s)/16.;
                    active.put(2,motion.newInstance(f,map.doorOpen(2)?1.:0.,System.nanoTime()+60_000_000_000L));
                }else if(s==16)active.remove(2);
                view.x=door.x()+(door.alongX()?0:1.4);view.z=door.z()+(door.alongX()?1.4:0);
                view.yaw=Math.atan2(door.x()-view.x,door.z()-view.z);
                if(g>=4){view.x+=door.alongX()?.31:0;view.z+=door.alongX()?0:.31;}
                double time=i<8?i*.1:.8+.6*g+.45*s/16;
                view.roomLightTick=(int)Math.floor(time*10);map.fixtures().power(view.roomLights.supplied());map.fixtures().advance(view.roomLightTick);
                if(software && !Set.of(0,8,16,24,84,143).contains(i))continue;
                view.drawPractice(map,List.of(),time);
                int n=0,uploaded=0,bytes=0;
                String digest,depth="";
                if(software){
                    var image=view.image();
                    for(int pixel:image.getRGB(0,0,320,200,null,0,320))putInt(sha,words,pixel);
                    digest=sum(sha,words);
                    for(double d:(double[])df.get(view)){
                        long bits=Double.doubleToRawLongBits(d);
                        putInt(sha,words,(int)(bits>>>32));putInt(sha,words,(int)bits);
                    }
                    depth=sum(sha,words);
                    ImageIO.write(image,"png",Path.of("frame-"+i+".png").toFile());
                }else{
                    Frame f=backend.frame;
                    n=f.surfaces().size();putInt(sha,words,n);
                    for(float camera:new float[]{f.focal(),f.vertexSnap(),f.affineWarp(),f.cameraX(),f.cameraY(),f.cameraZ(),f.yaw(),f.pitch(),f.lampIntensity(),f.lampReach(),f.lampWidth()})putInt(sha,words,Float.floatToRawIntBits(camera));
                    for(boolean on:new boolean[]{f.worldSpace(),f.lampOn(),f.flameLamp()})putInt(sha,words,on?1:0);
                    for(var batch:f.surfaces()){
                        putInt(sha,words,batch.material());putInt(sha,words,batch.vertexCount());
                        putInt(sha,words,(int)batch.resourceId());putInt(sha,words,(int)batch.revision());
                        float[] vertices=batch.vertices();putInt(sha,words,vertices.length);
                        for(float v:vertices)putInt(sha,words,Float.floatToRawIntBits(v));
                        boolean changed;
                        if(batch.resourceId()==0){
                            float[] prior=dynamic.get(batch.material());
                            changed=!Arrays.equals(prior,vertices);
                            if(changed)dynamic.put(batch.material(),vertices.clone());
                        }else{
                            changed=!Objects.equals(lookup.put(batch.resourceId(),batch.revision()),batch.revision());
                        }
                        if(changed){
                            if(vertices.length==0)throw new AssertionError("Changed VBO without payload");
                            bytes+=4*vertices.length;uploaded++;
                        }
                    }
                    digest=sum(sha,words);
                }
                out.write(i+","+g+","+s+","+view.x+","+view.z+","+args[0]+","+n+","+bytes+","+uploaded+","+digest+","+depth+","+(hf==null?0:hf.getLong(view))+"\n");out.flush();
            }
        }
    }
    static void putInt(MessageDigest sha,ByteBuffer b,int v){if(b.remaining()<4){sha.update(b.array(),0,b.position());b.clear();}b.putInt(v);}
    static String sum(MessageDigest sha,ByteBuffer b){sha.update(b.array(),0,b.position());b.clear();return HexFormat.of().formatHex(sha.digest());}
}
