#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
r="$PWD"
j=/tmp/beck-jdk17/bin
res=/workspace/scratch/bfb68f9d1548/beckenburg/build/classes
libs=/tmp/beck-perf-gl/lib
"$j/javac" --release 17 -cp "$r/original" -d "$r/drivers" "$r/SubmissionWitness.java"
export MALLOC_ARENA_MAX=1 MALLOC_TRIM_THRESHOLD_=65536
for arm in original combined; do
    cp="$r/drivers:$r/tests:$r/original:$res:$libs/*"
    if [[ $arm == combined ]]; then cp="$r/overlay:$cp"; fi
    for mode in submission photograph; do
        d="$r/raw/$arm/$mode"
        mkdir -p "$d"
        cd "$d"
        rc=0
        timeout 230 taskset -c 4,5 "$j/java" -ea -XX:+UseSerialGC -XX:ActiveProcessorCount=2 -Xms32m -Xmx155m -XX:ReservedCodeCacheSize=30m -XX:MaxMetaspaceSize=50m -XX:MaxHeapFreeRatio=20 -XX:MinHeapFreeRatio=6 -XX:-ShrinkHeapInSteps -Xss384k -Djava.awt.headless=true -Djava.util.prefs.PreferencesFactory=org.beckenburg.VerificationPreferencesFactory -Duser.home="$d/home" -cp "$cp" org.beckenburg.SubmissionWitness "$mode" > run.log 2>&1 || rc=$?
        echo "$rc" > exit-code.txt
    done
done
