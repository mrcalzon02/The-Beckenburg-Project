"""Build two isolated Java 17 classpaths. Every production source must match pinned Git bytes."""
import hashlib, io, json, os, shutil, subprocess, zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
base=Path('/workspace/scratch/707f355876c5')
repo=base/'main'
src0=base/'optics/source'
rev='a794c144cb4974ca4be00e588e9f6e2e7c717a41'
art='docs/performance/2026-11-16-house-frame-times/door-2/'
pkg='src/main/java/org/beckenburg/'
def git(*args):
    return subprocess.check_output(['git','-C',repo,*args])
def sha(data):
    return hashlib.sha256(data).hexdigest()
def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def tree(*paths):
    lines=git('ls-tree','-r',rev,'--',*paths).decode().splitlines()
    return {line.split('\t')[1]:line.split()[2] for line in lines}
def require(path,data,expected):
    assert sha(data)==expected,(path,sha(data),expected)
    return data
java=Path('/tmp/beck-jdk17/bin')
libs='/tmp/beck-perf-gl/lib/*'
report={'commit':rev}
prod=tree('src/main/java','gpu-client/src/main/java','water-module/src/main/java','lighting-module/src/main/java')
prod={k:v for k,v in prod.items() if k.endswith('.java')}
compiled=[]
for name,oid in prod.items():
    path=(src0/name).resolve()
    data=path.read_bytes() if path.exists() else b''
    if blob(data)!=oid or name in [pkg+'SceneRenderer.java',pkg+'FixtureLighting.java']:
        data=git('show',rev+':'+name)
        path=root/'source'/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
    assert blob(data)==oid,name
    compiled.append(path)
report['production_source_count']=len(compiled)
report['original_sources']={name:sha(path.read_bytes()) for name,path in zip(prod,compiled) if Path(name).stem in ('LanWorldPanel','SafeAreaHaze','SceneRenderer','FixtureLighting')}
(root/'source-blobs.txt').write_text(''.join(f'{oid} {name}\n' for name,oid in sorted(prod.items())))
archive=git('show',rev+':'+art+'door-cpu-experiments.zip')
expected='38a6fbc17f88b4dc601430a2e1f610b576befbc837e823a5c0edca0a420bd81c'
require('archive',archive,expected)
report['archive_sha256']=sha(archive)
z=zipfile.ZipFile(io.BytesIO(archive))
patch='patches/scoped-lamp-world.patch'
drivers='probes/DoorPoseLatticeReview.java'
pins={patch:'8ca2d734706cbaa5b47aa0f1c843753cb408bee877501a069487535e002925ae',drivers:'6e80d872fc22587ef9d52f3009adc38a26d84c00983eb2b1c071f8e639466eca'}
for name,digest in pins.items():
    (root/Path(name).name).write_bytes(require(name,z.read(name),digest))
report['patch_and_driver']=pins
for name in ('DoorReceiverReview.java','DoorwayShadowWitness.java'):
    (root/name).write_bytes(git('show',rev+':'+art+name))
tops=[pkg+'FixtureLighting.java',pkg+'SceneRenderer.java']
for name in tops:
    path=root/'patched'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/'source'/name,path)
for options in [['--check'],[]]:
    subprocess.run(['git','apply','--no-index',*options,str(root/Path(patch).name)],cwd=root/'patched',check=True)
report['patched_sources']={name:sha((root/'patched'/name).read_bytes()) for name in tops}
def compile_to(name,cp,files):
    output=root/name
    output.mkdir(exist_ok=True)
    subprocess.run([java/'javac','-J-XX:ActiveProcessorCount=2','-J-XX:+UseSerialGC','-J-XX:TieredStopAtLevel=1','-J-XX:ReservedCodeCacheSize=24m','-J-Xmx145m','--release','17','-encoding','UTF-8','-cp',cp,'-d',output,*files],check=True)
previous=Path('/tmp/beck-combined-707')
def refresh(destination,old,files,cp):
    shutil.copytree(previous/old,root/destination,dirs_exist_ok=True)
    for source in files:
        package=source.read_text().split('package ',1)[1].split(';',1)[0]
        directory=root/destination/package.replace('.','/')
        for f in directory.glob(source.stem+'$*.class'):f.unlink()
        f=directory/(source.stem+'.class')
        f.unlink(missing_ok=True)
    compile_to(destination,cp,files)
changedprod=[p for p in compiled if root/'source' in p.parents]
refresh('original','original',changedprod,str(root/'original')+':'+libs)
compile_to('overlay',str(root/'original'),[root/'patched'/s for s in tops])
compile_to('drivers',str(root/'original')+':'+libs,[root/'DoorPoseLatticeReview.java',root/'DoorwayShadowWitness.java',root/'DoorReceiverReview.java'])
test_paths=tree('src/test/java')
nonmatching=[n for n,oid in test_paths.items() if n.endswith('.java') and (not (src0/n).exists() or blob((src0/n).read_bytes())!=oid)]
for name in nonmatching:
    path=root/'source'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    data=git('show',rev+':'+name)
    assert blob(data)==test_paths[name],name
    path.write_bytes(data)
testsrc=[(root/'source' if n in nonmatching else src0)/n for n in test_paths if n.endswith('.java')]
refresh('tests','tests',[p for p in testsrc if root/'source' in p.parents],str(root/'original')+':'+str(root/'tests')+':'+libs)
report['test_source_count']=len(testsrc)
def family(directory,stems):
    return {file.name:sha(file.read_bytes()) for file in sorted((directory/'org/beckenburg').glob('*.class')) if file.name.split('$')[0].split('.')[0] in stems}
a=['SafeAreaHaze'];b=['LanWorldPanel'];c=['SceneRenderer','FixtureLighting']
assert family(root/'original',a)==family(base/'optics/lanes/classes',a)
report['pacing_timer_lines']=[s.strip() for s in (root/'source'/ (pkg+'LanWorldPanel.java')).read_text().splitlines() if any(token in s for token in ('renderStart','System.nanoTime()-started','new Timer(20','setRepeats(false)','frameTimerDelay'))]
assert family(root/'original',['FixtureLighting'])==family(base/'optics/base-classes',['FixtureLighting'])
assert family(root/'original',['SceneRenderer'])!=family(base/'optics/base-classes',['SceneRenderer'])
assert family(root/'overlay',['FixtureLighting'])==family(base/'door/worker-check/overlay',['FixtureLighting'])
report['original_classes']=family(root/'original',a+b+c)
report['patched_classes']=family(root/'overlay',c)
(root/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
print('Matched',len(prod),'pinned production sources,',len(testsrc),'test sources,',len(report['original_classes']),'original family classes,',len(report['patched_classes']),'compiled latest candidate overlay class binaries')
