from pathlib import Path
import zipfile,subprocess,hashlib,shutil
root=Path(__file__).resolve().parent
base=root.parent
workspace=root.parents[2]
rev='82b234b4f4b6300367b8de37373dc3dbae428674'
t='/tmp/beck-combined-707/latest'
for suffix,names in [('main',['LanHost','VanStaging']),('test',['CampaignEmbeddedDesktopTest','VanHumanScaleTest'])]:
    dest=root/suffix;dest.mkdir(exist_ok=True)
    for name in names:
        f='src/'+suffix+'/java/org/beckenburg/'+name+'.java';data=subprocess.check_output(['git','-C',workspace/'main','show',rev+':'+f])
        (dest/(name+'.java')).write_bytes(data)
    classes=root/(suffix+'-classes');classes.mkdir(exist_ok=True)
    cp=':'.join(str(s) for s in [root/'main-classes',base/'beckenburg-game.jar',t+'/tests'])
    subprocess.run(['/tmp/beck-jdk17/bin/javac','-J-Xmx125m','-J-XX:+UseSerialGC','-J-XX:ActiveProcessorCount=2','--release','17','-encoding','UTF-8','-cp',cp,'-d',classes,*dest.glob('*.java')],check=True)
new=root/'beckenburg-game.jar'
replaced={p.relative_to(root/'main-classes').as_posix():p for p in (root/'main-classes').rglob('*.class')}
with zipfile.ZipFile(base/'beckenburg-game.jar') as old,zipfile.ZipFile(new,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as updated:
    for f in old.infolist():
        p=replaced.pop(f.filename,None)
        if p:updated.write(p,f.filename)
        else:
            with old.open(f) as inp,updated.open(f.filename,'w') as fp:
                shutil.copyfileobj(inp,fp,length=65536)
    for k,p in replaced.items():updated.write(p,k)
print(rev,'jar',new.stat().st_size,'bytes',hashlib.file_digest(new.open('rb'),'sha256').hexdigest())
