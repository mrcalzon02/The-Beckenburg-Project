#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
r="$PWD"
j=/tmp/beck-jdk17/bin
classPath="$r/beckenburg-game.jar:$r/test-classes:/tmp/beck-combined-707/latest/tests"
export MALLOC_ARENA_MAX=1 MALLOC_TRIM_THRESHOLD_=65536
"$j/java" -ea -Xms24m -Xmx125m -XX:ActiveProcessorCount=2 -XX:+UseSerialGC -Djava.awt.headless=true -cp "$classPath" org.beckenburg.VanHumanScaleTest > van-human-scale.log 2>&1
mkdir -p host-review
"$j/javac" -J-Xmx80m --release 17 -cp "$classPath" -d host-review /tmp/beck-combined-707/occupancy/CampaignDoorwayReview.java
for trial in 1 2 3;do
    rc=0
    "$j/java" -ea -Xms24m -Xmx100m -XX:ActiveProcessorCount=2 -XX:+UseSerialGC -Djava.awt.headless=true -cp "$classPath:$r/host-review" org.beckenburg.CampaignDoorwayReview > "host-$trial.log" 2>&1 || rc=$?
    echo "$rc" > "host-$trial.exit"
done
for trial in 1 2; do
  d="$r/gui-$trial";mkdir -p "$d/home";cd "$d"
  rc=0
  timeout 110 taskset -c 4,5 "$r/../../combined-door/run-x" "$j/java" -ea -XX:ActiveProcessorCount=2 -XX:+UseSerialGC -Xms35m -Xmx289m -XX:TieredStopAtLevel=1 -XX:MaxHeapFreeRatio=20 -XX:MinHeapFreeRatio=6 -XX:-ShrinkHeapInSteps -XX:ReservedCodeCacheSize=28m -XX:MaxMetaspaceSize=63m -Djava.awt.headless=false -Duser.home="$d/home" -cp "$classPath" org.beckenburg.CampaignEmbeddedDesktopTest > run.log 2>&1 || rc=$?
  echo "$rc" > exit-code.txt
done
