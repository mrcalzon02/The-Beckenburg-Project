package org.beckenburg;

import java.nio.ByteBuffer;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.beckenburg.gpu.*;

public class DoorDiversityReview {
    static String hex(MessageDigest digest, ByteBuffer buffer) {
        return HexFormat.of().formatHex(digest.digest(buffer.array()));
    }

    public static void main(String[] args) throws Exception {
        var start = GpuDesktop.class.getDeclaredMethod("startGpu");
        var stop = GpuDesktop.class.getDeclaredMethod("stopReviewGpu");
        start.setAccessible(true);
        stop.setAccessible(true);
        start.invoke(null);
        try { run(Path.of(args[0])); } finally { stop.invoke(null); }
    }

    static void run(Path output) throws Exception {
        var gl = (OpenGlWorldRenderer) GpuWorldRenderer.active();
        int to=200;
        boolean reverse=Boolean.getBoolean("door.reverse");
        var random=new Random(0xD002_6411L);
        var house=new HouseMap(HouseMap.Site.HOUSE);
        var map=house;
        var view=new SceneRenderer();
        view.setRenderSize(320,200);
        var circuits=new RoomLighting();view.roomLights=circuits;
        boolean side=reverse;
        var scenario=Files.newBufferedWriter(output.resolveSibling("scenarios.csv"));
        scenario.write("frame,site,side,event,hiding,portals,power,restored_vertices,retained_bytes,entries\n");
        var sha = MessageDigest.getInstance("SHA-256");
        try (var csv = Files.newBufferedWriter(output)) {
            csv.write("frame,phase,door_open,door_b_open,window_open,vertices_uploaded_bytes,uploaded_batches,gl_worker_ns,gl_issue_ns,render_thread_cpu_ns,end_to_end_ns,argb_sha256,depth_bits_sha256\n");
            var cpu = java.lang.management.ManagementFactory.getThreadMXBean();
            for (int i=0; i<to; i++) {
                if(i==100)map=new HouseMap(HouseMap.Site.SCHOOL);
                if(i==125)map=house;
                if(i==159)map=new HouseMap(HouseMap.Site.HOUSE);
                var level=map.level();
                var doors=level.portals().stream().filter(p->p.door()).toList();
                var door=doors.stream().filter(p->p.a()==0||p.b()==0).findFirst().orElse(doors.get(0));
                var doorB=doors.stream().filter(p->p.id()!=door.id()).findFirst().orElseThrow();
                var window=level.portals().stream().filter(p->p.kind().equals("window")).findFirst().orElseThrow();
                int event;
                boolean ordinary=i%25<10;
                if(ordinary)event=0;else event=random.nextInt(12);
                if(i==24||i==64||i==107||i==130||i==171)event=2;
                if(i==26||i==69||i==110||i==137||i==178)event=1;
                if(i==48||i==87||i==120||i==158||i==193)event=9;
                if(i==25||i==65||i==112||i==139||i==182)event=4;
                if(i==38||i==78||i==115||i==145||i==189)event=5;
                var phase="mixed-"+event;
                if(i>1&&event==0)map.toggleDoor(door.id(),System.nanoTime()-HouseMap.DOOR_SWING_NANOS);
                if(event==1)map.toggleDoor(doorB.id(),System.nanoTime()-HouseMap.DOOR_SWING_NANOS);
                if(event==2)map.toggleWindow(window.id());
                if(event==3)side=!side;
                if(event==4)circuits.setBreaker(!circuits.breaker());
                if(event==5)circuits.toggle(1);
                if(event==6)circuits.pulse(1,RoomLighting.Interference.MODERATE,view.roomLightTick);
                if(event==7){
                    var lamp=map.fixtures().states().stream().filter(f->f.kind()==HauntedFixtures.Kind.TABLE_LAMP||
                        f.kind()==HauntedFixtures.Kind.TELEVISION).findFirst();
                    if(lamp.isPresent()){var f=lamp.get();map.fixtures().activate(f.id(),f.room(),view.roomLightTick);}
                }
                if(event==8){view.roomLightTick+=6;map.fixtures().advance(view.roomLightTick);}
                if(event==9)map.configureHiding(map.hidingDensity()==70?30:70);
                view.lamp=event==10;view.uvLamp=event==11;
                map.fixtures().power(circuits.supplied());
                view.eyeHeight=door.y()+1.62;view.pitch=-.03;
                double offset=side?-.86:1.4;
                view.x=door.x()+(door.alongX()?0:offset);
                view.z=door.z()+(door.alongX()?offset:0);
                view.yaw=Math.atan2(door.x()-view.x,door.z()-view.z)+(side?.04:0);
                long t=System.nanoTime(), c=cpu.getCurrentThreadCpuTime();
                view.drawPractice(map,List.of(),i/30d);
                c=cpu.getCurrentThreadCpuTime()-c;
                long id=view.submittedGpuFrameId(),deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(12);
                GpuWorldRenderer.Result r;
                while((r=gl.latest())==null||r.frameId()!=id) {
                    if(!gl.ready()||System.nanoTime()>deadline) throw new AssertionError("GL frame "+id+" "+gl.rendererDescription());
                    Thread.sleep(1);
                }
                long e=System.nanoTime()-t;
                var stats=gl.uploadStats();
                var timing=gl.frameTiming();
                if(stats.frameId()!=id||timing.frameId()!=id) throw new AssertionError("Wrong GL frame");
                int visible=0;
                var color=ByteBuffer.allocate(r.argb().length*4);
                var depth=ByteBuffer.allocate(r.depth().length*4);
                for(int p:r.argb()){color.putInt(p);if((p>>>24)!=0)visible++;}
                for(float z:r.depth())depth.putInt(Float.floatToRawIntBits(z));
                if(Boolean.getBoolean("beckenburg.door.capturePixels")){
                    var capture=output.toAbsolutePath().getParent().resolve("pixels");
                    Files.createDirectories(capture);
                    try(var out=new java.util.zip.GZIPOutputStream(Files.newOutputStream(capture.resolve("frame-"+i+".argb.gz")))){
                        out.write(color.array());
                    }
                }
                if(visible<1000)throw new AssertionError("Blank frame");
                csv.write(String.format(Locale.ROOT,"%d,%s,%b,%b,%b,%d,%d,%d,%d,%d,%d,%s,%s%n",i,phase,
                    map.doorOpen(door.id()),map.doorOpen(doorB.id()),map.windowOpen(window.id()),stats.uploadedBytes(),stats.uploadedBatches(),
                    timing.totalNs(),timing.drawIssueNs(),c,e,hex(sha,color),hex(sha,depth)));
                long retained=0,reused=0;int entries=0;
                try{
                    var bytes=SceneRenderer.class.getDeclaredField("archivedPoseBytes");bytes.setAccessible(true);retained=bytes.getLong(view);
                    var hits=SceneRenderer.class.getDeclaredField("restoredPoseVertices");hits.setAccessible(true);reused=hits.getLong(view);
                    var archive=SceneRenderer.class.getDeclaredField("archivedPoses");archive.setAccessible(true);entries=((Map<?,?>)archive.get(view)).size();
                    if(retained>16*1024*1024||entries>8192||retained<0)throw new AssertionError("Archive accounting");
                }catch(NoSuchFieldException baseline){}
                scenario.write(i+","+map.site()+","+side+","+event+","+map.hidingDensity()+",\""+map.doorSnapshot()+":"+map.windowSnapshot()+"\","+circuits.supplied()+","+reused+","+retained+","+entries+"\n");
                scenario.flush();csv.flush();
            }
        }finally{scenario.close();}
    }
}
