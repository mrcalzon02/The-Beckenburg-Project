package org.beckenburg;
public class HouseClockWitness {
    public static void main(String[] args) {
        var map=new HouseMap(HouseMap.Site.HOUSE);
        var light=new FixtureLighting(map);
        var circuits=new RoomLighting();
        System.out.println("step,tick,portal_serial,exact_factor_epoch");
        for(int step=0;step<32;step++){
            if(step>=8)map.toggleDoor(2,System.nanoTime()-HouseMap.DOOR_SWING_NANOS);
            map.fixtures().power(circuits.supplied());map.fixtures().advance(step*5);
            light.frame(circuits,step*5);
            System.out.println(step+","+(step*5)+","+light.housePose().serial()+","+light.housePose().factorEpoch());
        }
    }
}
