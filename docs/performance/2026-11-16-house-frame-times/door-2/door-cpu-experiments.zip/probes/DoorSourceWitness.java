package org.beckenburg;

import java.lang.reflect.Field;
import java.lang.reflect.RecordComponent;
import java.nio.file.*;
import java.util.*;
import java.io.*;

final class DoorSourceWitness {
    private record Snapshot(int[] ids,long[] bits,float[] vertices){}
    private record Mesh(long id,long revision,int material,String kind,float[] vertices,int[] ids){}
    private record Row(int frame,boolean open,Mesh mesh,boolean hasPrior,boolean sourceMatch,boolean payloadMatch,String difference,String changing,String ids){}
    private final Map<Long,Long> revisions=new HashMap<>();
    private final Map<Long,Snapshot> openSeen=new HashMap<>(),closedSeen=new HashMap<>();
    private final List<String[]> rows=new ArrayList<>();
    private long[] previousFactors;
    private final StringBuilder sources=new StringBuilder("frame,source,kind,room,factor_bits,changed\n");
    private static Object get(Object object,String name)throws Exception{
        Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);
    }
    private static String ids(int[] values){return String.join("|",Arrays.stream(values).mapToObj(Integer::toString).toList());}
    private static Mesh mesh(Object obj,String kind,int material,int[] indices)throws Exception{
        return new Mesh((long)get(obj,"id"),(long)get(obj,"revision"),material,kind,(float[])get(obj,"vertices"),indices);
    }
    @SuppressWarnings("unchecked")
    void observe(SceneRenderer view,int frame,boolean open,boolean step)throws Exception{
        var lighting=(FixtureLighting)get(view,"fixtureLighting");
        double[] factors=(double[])get(lighting,"factors");long[] bits=new long[factors.length];
        for(int i=0;i<bits.length;i++)bits[i]=Double.doubleToRawLongBits(factors[i]);
        var changed=new BitSet();
        for(var source:lighting.sources()){
            int i=source.id();if(previousFactors!=null&&bits[i]!=previousFactors[i])changed.set(i);
            sources.append(frame).append(',').append(i).append(',').append(source.kind()).append(',').append(source.room()).append(',').append(Long.toHexString(bits[i])).append(',').append(changed.get(i)).append('\n');
        }
        previousFactors=bits;
        if(step&&frame==18){openSeen.clear();closedSeen.clear();}
        List<Mesh> meshes=new ArrayList<>();
        for(var chunk:(List<?>)get(view,"visibleResidentScenery")){
            var batches=(Map<Integer,?>)get(chunk,"batches"); var deps=(Map<Integer,?>)get(chunk,"dependencies");
            for(var e:batches.entrySet()){
                var d=deps.get(e.getKey());
                meshes.add(mesh(e.getValue(),"world",e.getKey(),d==null?null:(int[])get(d,"ids")));
            }
        }
        for(var e:((Map<?,?>)get(view,"residentShell")).entrySet())
            meshes.add(mesh(e.getValue(),"shell",(int)get(e.getKey(),"material"),null));
        var current=open?openSeen:closedSeen;
        var seen=new HashSet<Long>();
        for(var m:meshes){
            if(!seen.add(m.id))continue;
            long[] relevant=m.ids==null?null:new long[m.ids.length];
            if(m.ids!=null)for(int i=0;i<m.ids.length;i++)relevant[i]=bits[m.ids[i]];
            var prev=current.put(m.id,new Snapshot(m.ids,relevant,m.vertices));
            var priorRevision=revisions.put(m.id,m.revision);
            if(priorRevision==null||priorRevision==m.revision||frame<8||frame>=32)continue;
            var different=new ArrayList<Integer>();int[] currentChanged={};
            if(m.ids!=null){
                currentChanged=Arrays.stream(m.ids).filter(changed::get).toArray();
                if(prev!=null&&prev.ids!=null&&Arrays.equals(m.ids,prev.ids))
                    for(int i=0;i<m.ids.length;i++)if(relevant[i]!=prev.bits[i])different.add(m.ids[i]);
            }
            boolean eligible=m.ids!=null&&prev!=null&&Arrays.equals(m.ids,prev.ids)&&Arrays.equals(relevant,prev.bits);
            rows.add(new String[]{Integer.toString(frame),Boolean.toString(open),Long.toString(m.id),m.kind,Integer.toString(m.material),
                Integer.toString(m.vertices.length/8),Boolean.toString(prev!=null),Boolean.toString(eligible),Boolean.toString(prev!=null&&Arrays.equals(m.vertices,prev.vertices)),
                m.ids==null?"":ids(m.ids),ids(currentChanged),String.join("|",different.stream().map(Object::toString).toList())});
        }
    }
    void write(Path target)throws Exception{
        var cupboards=new HashSet<Integer>();
        for(var face:GlbProps.model("level_hiding_cupboard_worn").triangles())cupboards.add(face.material());
        try(var out=Files.newBufferedWriter(target.resolveSibling("receiver-factors.csv"))){
            out.write("frame,open,id,kind,material,vertices,has_prior,exact_source_match,exact_payload_match,source_ids,factors_changed_this_frame,factors_changed_since_same_pose,cupboard\n");
            for(var r:rows)out.write(String.join(",",r)+","+cupboards.contains(Integer.valueOf(r[4]))+"\n");
        }
        Files.writeString(target.resolveSibling("all-sources.csv"),sources);
    }
}
