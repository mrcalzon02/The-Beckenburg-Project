package org.beckenburg;

import java.util.Map;

/** Exercise both bounds and the no-restore path after eviction, without a GL allocation. */
public final class PoseBudgetReview {
    public static void main(String[] args) throws Exception {
        var view=new SceneRenderer();
        var mesh=Class.forName("org.beckenburg.SceneRenderer$ResidentShell");
        var ctor=mesh.getDeclaredConstructor(int.class,long.class,long.class,long.class,float[].class);
        ctor.setAccessible(true);
        var retain=SceneRenderer.class.getDeclaredMethod("retainPose",mesh,mesh,FixtureLighting.HousePose.class);
        var restore=SceneRenderer.class.getDeclaredMethod("priorPose",mesh,FixtureLighting.HousePose.class);
        var reset=SceneRenderer.class.getDeclaredMethod("clearArchivedPoses");
        retain.setAccessible(true);restore.setAccessible(true);reset.setAccessible(true);
        var memory=SceneRenderer.class.getDeclaredField("archivedPoseBytes");
        var entries=SceneRenderer.class.getDeclaredField("archivedPoses");
        memory.setAccessible(true);entries.setAccessible(true);
        var old=new FixtureLighting.HousePose(1,8,4,"closed");
        var open=new FixtureLighting.HousePose(2,8,4,"open");
        var closed=new FixtureLighting.HousePose(5,8,4,"closed");
        var table=(Map<?,?>)entries.get(view);
        var hist=Class.forName("org.beckenburg.SceneRenderer$ArchivedPose").getDeclaredField("vertices");
        hist.setAccessible(true);
        long peak=0;
        int peakCount=0;
        Object first=null,last=null;
        for(int i=0;i<9000;i++){
            int floats=i<512?32768:8;
            var a=ctor.newInstance(3,0,100L+i,1,new float[floats]);
            var b=ctor.newInstance(3,1,100L+i,2,new float[floats]);
            if(i==0)first=b;last=b;
            retain.invoke(view,null,a,old);retain.invoke(view,a,b,open);
            retain.invoke(view,b,a,new FixtureLighting.HousePose(3,8,4,"closed"));
            retain.invoke(view,a,b,new FixtureLighting.HousePose(4,8,4,"open"));
            long bytes=memory.getLong(view);
            if(bytes>(16L<<20)||bytes<0||table.size()>8192)throw new AssertionError("unbounded");
            if(i%199==0||i==8999){
                long actual=0;
                for(var entry:table.values()){var v=(float[])hist.get(entry);if(v!=null)actual+=4L*v.length;}
                if(actual!=bytes)throw new AssertionError("accounting "+bytes+" vs "+actual);
            }
            peak=Math.max(peak,bytes);peakCount=Math.max(peakCount,table.size());
        }
        if(restore.invoke(view,first,closed)!=null||restore.invoke(view,last,closed)==null)throw new AssertionError("eviction");
        for(var wrong:new FixtureLighting.HousePose[]{
            new FixtureLighting.HousePose(6,8,4,"closed"),new FixtureLighting.HousePose(5,9,4,"closed"),
            new FixtureLighting.HousePose(5,8,5,"closed"),new FixtureLighting.HousePose(5,8,4,"different")})
            if(restore.invoke(view,last,wrong)!=null)throw new AssertionError("wrong pose "+wrong);
        reset.invoke(view);
        if(!table.isEmpty()||memory.getLong(view)!=0)throw new AssertionError("release");
        System.out.println("9,000 resources; peak retained alternate bytes "+peak+"; peak descriptors "+peakCount+
            "; evicted ID, other serial, global topology, source factors and other portals rejected; reset released all");
    }
}
