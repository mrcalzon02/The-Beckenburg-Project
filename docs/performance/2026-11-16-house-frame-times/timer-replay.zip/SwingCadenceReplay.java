import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/** Replay a trial's observed render durations on a real Swing timer and EDT.
 * This isolates event scheduling. No game renderer, networking or GPU is run. */
public final class SwingCadenceReplay {
    record Sample(int render, long start, long end, long work) {}
    public static void main(String[] args) throws Exception {
        boolean deadline = args[0].startsWith("deadline");
        int period = switch (args[0]) {
            case "fixed33" -> 33;
            case "fixed30", "deadline30" -> 30;
            case "deadline20" -> 20;
            default -> throw new IllegalArgumentException("Unknown timer " + args[0]);
        };
        List<Long> work = Files.readAllLines(Path.of(args[1])).stream().map(Long::parseLong).toList();
        var finished = new CountDownLatch(1);
        var samples = new ArrayList<Sample>();
        var inputs = new ArrayList<Long>();
        SwingUtilities.invokeAndWait(() -> {
            Timer input = new Timer(110, event -> inputs.add(System.nanoTime()));
            Timer timer = new Timer(period, null);
            timer.setRepeats(!deadline);
            timer.addActionListener(event -> {
                int index = samples.size();
                long start = System.nanoTime();
                long required = work.get(index);
                long left;
                while ((left = start + required - System.nanoTime()) > 0) LockSupport.parkNanos(left);
                long end = System.nanoTime();
                samples.add(new Sample(index, start, end, required));
                if (samples.size() == work.size()) {
                    timer.stop();
                    input.stop();
                    finished.countDown();
                } else if (deadline) {
                    long remaining = period * 1_000_000L - (end - start);
                    int delay = (int) Math.max(1L, (remaining + 999_999L) / 1_000_000L);
                    timer.setInitialDelay(delay);
                    timer.restart();
                }
            });
            input.start();
            timer.start();
        });
        if (!finished.await(30, TimeUnit.SECONDS)) throw new AssertionError("Timer did not finish");
        var result = new StringBuilder("index,start_ns,end_ns,work_ns\n");
        for (var row : samples)
            result.append(String.format(Locale.ROOT, "%d,%d,%d,%d%n", row.render(), row.start(), row.end(), row.work()));
        Files.writeString(Path.of(args[2]), result);
        Files.write(Path.of(args[3]), inputs.stream().map(String::valueOf).toList());
    }
}
