"""Compute pooled same-process timer delivery, render occupancy and input-event statistics."""
import argparse
import csv
from collections import defaultdict
import math
from pathlib import Path

def nearest(values,q):
    return sorted(values)[math.ceil(len(values)*q)-1]

def summarize(rows):
    render_gaps,inputs,work,occupied,elapsed,post_idle=[],[],0,0,0,[]
    for frames,ticks in rows:
        for a,b in zip(frames,frames[1:]):
            render_gaps.append((b['end_ns']-a['end_ns'])/1e6)
            if 35e6<=a['work_ns']<64e6:
                post_idle.append((b['start_ns']-a['end_ns'])/1e6)
        inputs.extend((b-a)/1e6 for a,b in zip(ticks,ticks[1:]))
        work+=sum(f['work_ns'] for f in frames)
        occupied+=sum(f['end_ns']-f['start_ns'] for f in frames)
        elapsed+=frames[-1]['end_ns']-frames[0]['start_ns']
    return [len(rows),len(render_gaps),*[round(nearest(render_gaps,q),3) for q in (.5,.95,.99)],
            sum(g>100 for g in render_gaps),round(nearest(post_idle,.5),3),round(work/1e6,3),
            round(elapsed/1e6,3),round(100*work/elapsed,2),round(100*occupied/elapsed,2),
            len(inputs),*[round(nearest(inputs,q),3) for q in (.5,.95,.99,1)],sum(g>220 for g in inputs)]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    opts=parser.parse_args()
    groups=defaultdict(list)
    for phase in sorted(opts.directory.glob('replay-[1-9]-*.csv')):
        _,pair,arm=phase.stem.split('-')
        with phase.open() as f:
            frames=[{k:int(v) for k,v in r.items()} for r in csv.DictReader(f)]
        inputs=list(map(int,(opts.directory/f'input-{pair}-{arm}.txt').read_text().splitlines()))
        assert len(inputs)>=2 and all(b>a for a,b in zip(inputs,inputs[1:]))
        with (opts.directory/f'frames-{pair}.csv').open() as f:
            source=[int(r['render_ns']) for r in csv.DictReader(f) if r['phase']=='moving']
        assert source==[r['work_ns'] for r in frames]
        groups[arm,pair].append((frames,inputs))
        groups[arm,'all'].append((frames,inputs))
    cols='arm pair trials frame_intervals frame_p50_ms frame_p95_ms frame_p99_ms over100_ms median_idle_after_35_64_ms prescribed_render_ms elapsed_ms estimated_occupied_percent observed_occupied_percent input_intervals input_p50_ms input_p95_ms input_p99_ms input_max_ms input_over220_ms'.split()
    with (opts.directory/'summary.csv').open('w',newline='') as out:
        writer=csv.writer(out);writer.writerow(cols)
        for k,row in sorted(groups.items()):writer.writerow([*k,*summarize(row)])
if __name__=='__main__':main()
