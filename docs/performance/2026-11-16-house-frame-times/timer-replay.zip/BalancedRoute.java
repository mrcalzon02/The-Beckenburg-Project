package org.beckenburg;

import java.util.prefs.Preferences;

/** Lower-memory local profiling profile. Uses the normal user-selectable balanced setting. */
public final class BalancedRoute {
    public static void main(String[] args) throws Exception {
        Preferences.userNodeForPackage(GraphicsOptions.class).put("detail","BALANCED");
        LanViewportPerformanceReview.main(args);
    }
}
