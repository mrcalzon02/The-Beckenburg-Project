package org.beckenburg;

import java.awt.event.KeyEvent;
import java.lang.reflect.Field;
import java.nio.file.Path;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.prefs.Preferences;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/** Check the actual local investigation panel's timer and visibility transitions. */
public final class CadenceLifecycleReview {
    private record Snapshot(boolean showing, boolean gameplayRunning, boolean renderRunning,
                            int frames, int inputEvents) {}
    private static LanWorldPanel panel;
    private static Timer gameplay, render;
    private static Field count;
    private static final AtomicInteger inputEvents = new AtomicInteger();

    private static <T> T edt(Callable<T> task) throws Exception {
        var work = new FutureTask<>(task);
        SwingUtilities.invokeAndWait(work);
        return work.get();
    }
    private static Field field(String name) throws Exception {
        Field f = LanWorldPanel.class.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }
    private static Snapshot read() throws Exception {
        return edt(() -> new Snapshot(panel.isShowing(),gameplay.isRunning(),render.isRunning(),
            count.getInt(panel),inputEvents.get()));
    }
    private static void awaitFrames(int target) throws Exception {
        long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(30);
        while (System.nanoTime() < end) {
            if (read().frames() >= target) return;
            Thread.sleep(30);
        }
        throw new AssertionError("Scheduled renders stalled. " + read());
    }
    public static void main(String[] args) throws Exception {
        // The fixture measures timer state exclusively. Minimize software rendering cost.
        Preferences.userNodeForPackage(GraphicsOptions.class).put("detail","RETRO");
        int period = Integer.parseInt(args[0]);
        boolean repeats = Boolean.parseBoolean(args[1]);
        count = field("frameCount");
        try (var game = new LocalInvestigation(new ProfileStore(Path.of("profile.properties")),SiteCatalog.Location.HOUSE,
                CharacterVisuals.Hunter.OBSERVER,MissionWeather.Mode.FIXED,EvidenceSignals.Weather.CLEAR,1,null,0)) {
            try {
                edt(() -> {
                    panel=game.openView();
                    panel.setSize(640,360);
                    panel.addNotify();
                    gameplay=(Timer)field("timer").get(panel);
                    render=(Timer)field("renderTimer").get(panel);
                    gameplay.addActionListener(e -> inputEvents.incrementAndGet());
                    var key = new KeyEvent(panel,KeyEvent.KEY_PRESSED,System.currentTimeMillis(),0,
                                            KeyEvent.VK_SPACE,KeyEvent.CHAR_UNDEFINED);
                    panel.keyPressed(key);
                    panel.keyReleased(new KeyEvent(panel,KeyEvent.KEY_RELEASED,System.currentTimeMillis(),0,
                                                    KeyEvent.VK_SPACE,KeyEvent.CHAR_UNDEFINED));
                    if (render.getDelay()!=period || render.isRepeats()!=repeats || gameplay==render ||
                            !gameplay.isRepeats() || gameplay.getDelay()!=110) throw new AssertionError("timer config");
                    return null;
                });
                awaitFrames(3);
                Snapshot visible=read();
                edt(() -> { panel.setVisible(false); return null; });
                Thread.sleep(400);
                Snapshot hidden=read();
                Thread.sleep(400);
                Snapshot later=read();
                System.out.printf("visible %s%nsettled hidden %s%ncontinued hidden %s%n",visible,hidden,later);
                if (later.showing() || later.renderRunning() || !later.gameplayRunning() ||
                        later.frames()!=hidden.frames() || later.inputEvents()<=hidden.inputEvents()) throw new AssertionError("hidden");
                edt(() -> { panel.setVisible(true); return null; });
                awaitFrames(hidden.frames()+3);
                Snapshot resumed=read();
                System.out.println("reshown " + resumed);
                if (!resumed.showing() || !resumed.gameplayRunning()) throw new AssertionError("resume");
                edt(() -> { panel.close(); return null; });
                Snapshot closed=read();
                Thread.sleep(450);
                Snapshot closedLater=read();
                System.out.printf("closed %s%ncontinued closed %s%n",closed,closedLater);
                if (closedLater.renderRunning() || closedLater.gameplayRunning() || closedLater.frames()!=closed.frames() ||
                        closedLater.inputEvents()!=closed.inputEvents()) throw new AssertionError("close");
                System.out.println("PASS");
            } finally {
                edt(() -> { if(panel!=null) {panel.close();panel.removeNotify();} return null; });
            }
        }
    }
}
