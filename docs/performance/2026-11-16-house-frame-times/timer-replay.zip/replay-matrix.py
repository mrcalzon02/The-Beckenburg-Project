"""Replay every moving frame in each of four native solo trials on all Swing timer arms."""
import argparse
import csv
import io
import subprocess
from pathlib import Path
from zipfile import ZipFile

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive',type=Path,help='windows-opengl.zip from the benchmark checkpoint')
    parser.add_argument('output',type=Path)
    parser.add_argument('--java',default='java')
    parser.add_argument('--javac',default='javac')
    opts=parser.parse_args()
    out=opts.output.resolve()
    out.mkdir(exist_ok=True, parents=True)
    subprocess.run([opts.javac,'--release','17','-d',str(out),str(Path(__file__).with_name('SwingCadenceReplay.java'))],check=True)
    orders=[('fixed33','fixed30','deadline20','deadline30'),('fixed30','deadline30','fixed33','deadline20'),
            ('deadline30','deadline20','fixed30','fixed33'),('deadline20','fixed33','deadline30','fixed30')]
    with ZipFile(opts.archive) as z:
        for pair,order in enumerate(orders,1):
            name=f'physical/gpu/pair-{pair}-solo-candidate/frames.csv'
            rows=list(csv.DictReader(io.TextIOWrapper(z.open(name))))
            # Include all measured moving renders, including the first one used to anchor intervals.
            raw=z.read(name)
            (out/f'frames-{pair}.csv').write_bytes(raw)
            costs=out/f'walk-{pair}.txt'
            costs.write_text(''.join(row['render_ns']+'\n' for row in rows if row['phase']=='moving'))
            for arm in order:
                subprocess.run([opts.java,'-Djava.awt.headless=true','-cp',str(out),'SwingCadenceReplay',arm,str(costs),
                                str(out/f'replay-{pair}-{arm}.csv'),str(out/f'input-{pair}-{arm}.txt')],check=True)
                print(f'Finished {pair} {arm}',flush=True)
if __name__=='__main__':main()
