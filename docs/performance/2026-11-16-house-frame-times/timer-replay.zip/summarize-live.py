"""Compute nearest-rank distinct nonnegative OpenGL-frame completion gaps by arm and trial."""
import csv
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

def rank(values,fraction):return sorted(values)[math.ceil(len(values)*fraction)-1]
def intervals(frames):
    previous=None
    for r in frames:
        current=int(r['composited_gl_frame_id'])
        if current<0 or (previous and current==previous[0]):continue
        ns=int(r['time_ns'])
        if previous:yield (ns-previous[1])/1e6
        previous=(current,ns)
def stats(v):
    return [len(v),*(round(rank(v,q),3) for q in [.5,.95,.99]),sum(x>50 for x in v),sum(x>100 for x in v),round(max(v),3)]
root=Path(sys.argv[1])
writer=csv.writer(sys.stdout)
writer.writerow("pair mode arm phase n p50_ms p95_ms p99_ms over50 over100 max_ms route_m".split())
all_g=defaultdict(list)
for d in sorted(root.glob('[1-9]-*-*')):
    if not (d/'exit-code.txt').exists() or (d/'exit-code.txt').read_text().strip()!='0':continue
    pair,mode,arm=d.name.split('-')
    rows=list(csv.DictReader((d/'frames.csv').open()))
    summary=dict(line.split('=',1) for line in (d/'summary.txt').read_text().splitlines())
    for phase in ('idle','moving','stopping'):
        frames=[r for r in rows if r['phase']==phase]
        gaps=list(intervals(frames))
        if phase=='stopping':
            assert all(r['inside_sanctuary']=='true' for r in frames)
            assert (int(frames[-1]['time_ns'])-int(frames[0]['time_ns']))/1e9>3
        assert gaps and min(gaps)>0
        all_g[mode,arm,phase].extend(gaps)
        writer.writerow([pair,mode,arm,phase,*stats(gaps),summary['max_travel_metres']])
for key,gaps in sorted(all_g.items()):
    writer.writerow(['all',*key,*stats(gaps),''])
