"""Describe observed software panel work and completion timestamps, grouped by phase and pose."""
import csv
import io
import itertools
import math
import statistics
import sys
from collections import defaultdict
from zipfile import ZipFile

cols='mode arm phase where n repeated_or_skipped_id prev_render_p50_ms start_gap_p50_ms end_gap_p50_ms unaccounted_p50_ms effects_p50_ms'.split()
def m(v):return round(statistics.median(v),3)
groups=defaultdict(list)
with ZipFile(sys.argv[1]) as z:
    for name in sorted(z.namelist()):
        if not(name.startswith('pair-') and name.endswith('/frames.csv')):continue
        _,pair,mode,arm=name.split('/')[0].split('-')
        seq=list(csv.DictReader(io.TextIOWrapper(z.open(name))))
        for a,b in zip(seq,seq[1:]):
            ph=b['phase']
            if a['phase']!=ph or ph not in ('idle','moving','stopping'):continue
            gap=(int(b['time_ns'])-int(a['time_ns']))/1e6
            prev=int(a['render_ns'])/1e6
            cost=int(b['render_ns'])/1e6
            begin=gap-cost+prev; idle=gap-cost
            delta=int(b['composited_gl_frame_id'])-int(a['composited_gl_frame_id'])
            where='inside' if b['inside_sanctuary']=='true' else 'outside'
            groups[mode,arm,ph,where].append((delta,prev,begin,gap,idle,int(b['effects_ns'])/1e6))
writer=csv.writer(sys.stdout);writer.writerow(cols)
for k,g in sorted(groups.items()):
    writer.writerow([*k,len(g),sum(row[0]!=1 for row in g),*[m([r[i] for r in g]) for i in range(1,6)]])
