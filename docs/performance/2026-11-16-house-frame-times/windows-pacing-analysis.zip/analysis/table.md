| Role | Arm | Phase | Intervals | p50 ms | p95 ms | p99 ms | Over 50 ms | Over 100 ms | Pairs at target |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| Solo | v0.1.335 | Idle | 2368 | 33.62 | 35.63 | 37.07 | 3 | 0 | 0/4 |
| Solo | v0.1.335 | Walking | 292 | 33.74 | 73.39 | 122.21 | 47 | 6 | 0/4 |
| Solo | v0.1.335 | Stopping inside | 292 | 67.63 | 70.04 | 71.89 | 292 | 0 | 0/4 |
| Solo | Four-lane, repeating 30 ms | Idle | 2599 | 30.66 | 33.71 | 35.35 | 1 | 0 | 0/4 |
| Solo | Four-lane, repeating 30 ms | Walking | 370 | 30.59 | 43.59 | 82.33 | 13 | 0 | 0/4 |
| Solo | Four-lane, repeating 30 ms | Stopping inside | 650 | 30.54 | 38.19 | 39.60 | 0 | 0 | 0/4 |
| Solo | Four-lane, 30 ms deadline | Idle | 2531 | 31.48 | 34.55 | 36.13 | 0 | 0 | 0/4 |
| Solo | Four-lane, 30 ms deadline | Walking | 367 | 31.30 | 44.63 | 79.89 | 13 | 0 | 0/4 |
| Solo | Four-lane, 30 ms deadline | Stopping inside | 630 | 31.46 | 39.33 | 40.99 | 0 | 0 | 0/4 |
| Solo | Four-lane, 20 ms deadline | Idle | 3678 | 21.54 | 23.81 | 26.80 | 0 | 0 | 4/4 |
| Solo | Four-lane, 20 ms deadline | Walking | 527 | 21.41 | 32.40 | 71.64 | 13 | 1 | 3/4 |
| Solo | Four-lane, 20 ms deadline | Stopping inside | 925 | 21.53 | 23.60 | 30.43 | 0 | 0 | 4/4 |
| Three-seat TCP | v0.1.335 | Idle | 2370 | 33.62 | 35.79 | 36.89 | 0 | 0 | 0/4 |
| Three-seat TCP | v0.1.335 | Walking | 255 | 33.86 | 88.15 | 371.04 | 47 | 10 | 0/4 |
| Three-seat TCP | v0.1.335 | Stopping inside | 292 | 67.68 | 70.18 | 72.39 | 292 | 0 | 0/4 |
| Three-seat TCP | Four-lane, repeating 30 ms | Idle | 2599 | 30.64 | 33.71 | 35.08 | 0 | 0 | 1/4 |
| Three-seat TCP | Four-lane, repeating 30 ms | Walking | 371 | 30.73 | 43.23 | 89.18 | 12 | 0 | 0/4 |
| Three-seat TCP | Four-lane, repeating 30 ms | Stopping inside | 648 | 30.60 | 38.12 | 39.96 | 0 | 0 | 0/4 |
| Three-seat TCP | Four-lane, 30 ms deadline | Idle | 2533 | 31.48 | 34.62 | 36.06 | 0 | 0 | 0/4 |
| Three-seat TCP | Four-lane, 30 ms deadline | Walking | 363 | 31.45 | 44.75 | 89.33 | 14 | 0 | 0/4 |
| Three-seat TCP | Four-lane, 30 ms deadline | Stopping inside | 630 | 31.47 | 38.34 | 40.46 | 0 | 0 | 0/4 |
| Three-seat TCP | Four-lane, 20 ms deadline | Idle | 3687 | 21.50 | 23.88 | 26.50 | 0 | 0 | 4/4 |
| Three-seat TCP | Four-lane, 20 ms deadline | Walking | 525 | 21.46 | 32.67 | 66.33 | 15 | 0 | 3/4 |
| Three-seat TCP | Four-lane, 20 ms deadline | Stopping inside | 929 | 21.34 | 25.86 | 30.69 | 0 | 0 | 4/4 |
