# Physical House viewport pacing audit

Run 44002135665 used the Core30 i7-10700 and GTX 1660 SUPER. Each block ran solo and a rendered hunter with a remote hunter and human ghost on independent loopback connections. Every timer variant used the identical four-lane shader, original 110 ms gameplay timer, assets and 960×540 internal render target. v0.1.335 serves as the original game control.

The three experimental arms differ only in scheduling the visual callback. The control also predates v0.1.336 remote-hunter sprite preloading. The controller verified the candidate game source and normalized SHA-256 of the driver and every overlay. All 96 phase summaries were independently recomputed. Full authoritative network rounds ran on the .335 and deadline20 arms. The timed routes cover all four arms.

Each percentile pools intervals between successive distinct, nonnegative GL frames within a single trial and phase. Gaps across phases or processes are excluded. The target count records individual trials with a p95 no greater than 33.3 ms.

| Arm | Mode | Phase | Intervals | p50 ms | p95 ms | p99 ms | >100 ms | Trials on target |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| v0.1.335 | Solo | Idle | 2368 | 33.62 | 35.63 | 37.07 | 0 | 0/4 |
| v0.1.335 | Solo | Walking | 292 | 33.74 | 73.39 | 122.21 | 6 | 0/4 |
| v0.1.335 | Solo | Stopping | 292 | 67.63 | 70.04 | 71.89 | 0 | 0/4 |
| v0.1.335 | Three-seat | Idle | 2370 | 33.62 | 35.79 | 36.89 | 0 | 0/4 |
| v0.1.335 | Three-seat | Walking | 255 | 33.86 | 88.15 | 371.04 | 10 | 0/4 |
| v0.1.335 | Three-seat | Stopping | 292 | 67.68 | 70.18 | 72.39 | 0 | 0/4 |
| Repeating 30 ms | Solo | Idle | 2599 | 30.66 | 33.71 | 35.35 | 0 | 0/4 |
| Repeating 30 ms | Solo | Walking | 370 | 30.59 | 43.59 | 82.33 | 0 | 0/4 |
| Repeating 30 ms | Solo | Stopping | 650 | 30.54 | 38.19 | 39.60 | 0 | 0/4 |
| Repeating 30 ms | Three-seat | Idle | 2599 | 30.64 | 33.71 | 35.08 | 0 | 1/4 |
| Repeating 30 ms | Three-seat | Walking | 371 | 30.73 | 43.23 | 89.18 | 0 | 0/4 |
| Repeating 30 ms | Three-seat | Stopping | 648 | 30.60 | 38.12 | 39.96 | 0 | 0/4 |
| Deadline 30 ms | Solo | Idle | 2531 | 31.48 | 34.55 | 36.13 | 0 | 0/4 |
| Deadline 30 ms | Solo | Walking | 367 | 31.30 | 44.63 | 79.89 | 0 | 0/4 |
| Deadline 30 ms | Solo | Stopping | 630 | 31.46 | 39.33 | 40.99 | 0 | 0/4 |
| Deadline 30 ms | Three-seat | Idle | 2533 | 31.48 | 34.62 | 36.06 | 0 | 0/4 |
| Deadline 30 ms | Three-seat | Walking | 363 | 31.45 | 44.75 | 89.33 | 0 | 0/4 |
| Deadline 30 ms | Three-seat | Stopping | 630 | 31.47 | 38.34 | 40.46 | 0 | 0/4 |
| Deadline 20 ms | Solo | Idle | 3678 | 21.54 | 23.81 | 26.80 | 0 | 4/4 |
| Deadline 20 ms | Solo | Walking | 527 | 21.41 | 32.40 | 71.64 | 1 | 3/4 |
| Deadline 20 ms | Solo | Stopping | 925 | 21.53 | 23.60 | 30.43 | 0 | 4/4 |
| Deadline 20 ms | Three-seat | Idle | 3687 | 21.50 | 23.88 | 26.50 | 0 | 4/4 |
| Deadline 20 ms | Three-seat | Walking | 525 | 21.46 | 32.67 | 66.33 | 0 | 3/4 |
| Deadline 20 ms | Three-seat | Stopping | 929 | 21.34 | 25.86 | 30.69 | 0 | 4/4 |

## Matched comparisons

| Mode | Phase | .335 → fixed30 | Fixed30 → deadline30 | Fixed30 → deadline20 | Deadline30 → deadline20 |
| --- | ---: | ---: | ---: | ---: | ---: |
| Solo | Idle | 4/4 | 0/4 | 4/4 | 4/4 |
| Solo | Walking | 4/4 | 2/4 | 4/4 | 4/4 |
| Solo | Stopping | 4/4 | 0/4 | 4/4 | 4/4 |
| Three-seat | Idle | 4/4 | 0/4 | 4/4 | 4/4 |
| Three-seat | Walking | 4/4 | 1/4 | 4/4 | 4/4 |
| Three-seat | Stopping | 4/4 | 2/4 | 4/4 | 4/4 |

Rows count paired comparisons with a lower p95. See frame-paired.csv for median and range of the signed paired changes. The three-second walk spends time on both sides of the dome. The table below assigns an interval only when both endpoints lie on the indicated side. Four transition intervals per role and arm are retained separately in moving-domain.csv.

| Arm | Mode | Inside count | Inside p95 ms | Outside count | Outside p95 ms | Worst crossing ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| v0.1.335 | Solo | 56 | 122.21 | 232 | 35.63 | 23.93 |
| v0.1.335 | Three-seat | 58 | 371.04 | 193 | 35.89 | 33.37 |
| Repeating 30 ms | Solo | 115 | 70.41 | 251 | 32.32 | 90.62 |
| Repeating 30 ms | Three-seat | 111 | 72.01 | 256 | 32.52 | 96.74 |
| Deadline 30 ms | Solo | 108 | 63.83 | 255 | 33.05 | 97.17 |
| Deadline 30 ms | Three-seat | 107 | 62.19 | 252 | 32.68 | 92.92 |
| Deadline 20 ms | Solo | 158 | 53.74 | 365 | 22.83 | 85.23 |
| Deadline 20 ms | Three-seat | 153 | 55.88 | 368 | 22.76 | 86.35 |

## Process CPU and state delivery

Process CPU core-equivalents equal the sum of process CPU time divided by elapsed wall time over the four trials. A value of 1.00 represents one fully occupied logical processor over that phase. CPU includes the renderer, game, host, TCP peers and other JVM threads. It excludes GPU execution and CPU time of other processes. Per-trial ranges and process CPU milliseconds per delivered frame are in cpu-pooled.csv.

| Arm | Mode | Idle cores | Walking cores | Stopping cores |
| --- | ---: | ---: | ---: | ---: |
| v0.1.335 | Solo | 1.1243 | 0.8136 | 0.8654 |
| v0.1.335 | Three-seat | 1.1181 | 0.9762 | 0.8621 |
| Repeating 30 ms | Solo | 0.6484 | 1.0516 | 0.6387 |
| Repeating 30 ms | Three-seat | 0.6808 | 1.119 | 0.8371 |
| Deadline 30 ms | Solo | 0.6615 | 1.0397 | 0.5989 |
| Deadline 30 ms | Three-seat | 0.6308 | 1.1356 | 0.5702 |
| Deadline 20 ms | Solo | 0.8021 | 1.1971 | 0.8011 |
| Deadline 20 ms | Three-seat | 0.8669 | 1.2293 | 1.391 |

Queue delay runs from the decoded STATE callback on the socket listener to its dispatch on the Swing event thread immediately before handling. Phases are assigned at arrival and include dispatches after a boundary. state-pooled.csv also gives a sensitivity check restricted to states with both endpoints inside the phase’s measured frame window. Keyboard input-to-display latency needs its own timestamps.

| Arm | Phase | STATE records | p50 ms | p95 ms | p99 ms | Maximum ms | >100 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| v0.1.335 | Idle | 160 | 9.02 | 23.63 | 26.14 | 26.50 | 0 |
| v0.1.335 | Walking | 117 | 0.09 | 64.37 | 196.65 | 271.53 | 3 |
| v0.1.335 | Stopping | 44 | 9.61 | 42.82 | 47.48 | 47.48 | 0 |
| Repeating 30 ms | Idle | 160 | 0.10 | 4.59 | 6.45 | 6.70 | 0 |
| Repeating 30 ms | Walking | 132 | 0.08 | 4.22 | 50.08 | 70.36 | 0 |
| Repeating 30 ms | Stopping | 44 | 0.11 | 7.73 | 13.55 | 13.55 | 0 |
| Deadline 30 ms | Idle | 160 | 0.10 | 4.75 | 6.65 | 6.65 | 0 |
| Deadline 30 ms | Walking | 132 | 0.07 | 3.25 | 20.85 | 47.09 | 0 |
| Deadline 30 ms | Stopping | 44 | 0.10 | 7.21 | 9.86 | 9.86 | 0 |
| Deadline 20 ms | Idle | 160 | 0.11 | 6.19 | 6.84 | 9.38 | 0 |
| Deadline 20 ms | Walking | 132 | 0.08 | 3.00 | 19.34 | 51.76 | 0 |
| Deadline 20 ms | Stopping | 44 | 0.11 | 7.70 | 8.00 | 8.00 | 0 |

All 32 routes crossed the dome boundary. All 16 TCP runs recorded authoritative movement and a visible peer. The final step covered 0.310–0.310 m. Each final stable pose had at least 74 frames. The raw ZIP SHA-256 is `7608a57d8c8b21ec9d70ac4f18cf6c882456130c12e576a4722a98e60fdbcf37`. Recompute the audit with `python audit.py raw.zip output-dir`. The original frame CSVs, CPU boundary counters and incoming state timestamps remain in the worker archive.
