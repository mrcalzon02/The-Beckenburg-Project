"""Render an evidence summary from audited Core30 four-arm pacing CSVs."""
from pathlib import Path
import csv
import hashlib
import sys

out=Path(sys.argv[1]);raw=Path(sys.argv[2])
def read(name):return list(csv.DictReader((out/name).open()))
fps={(r['arm'],r['mode'],r['phase']):r for r in read('frame-pooled.csv')}
cpus={(r['arm'],r['mode'],r['phase']):r for r in read('cpu-pooled.csv')}
state={(r['arm'],r['phase']):r for r in read('state-pooled.csv') if r['sample_set']=='arrival'}
domain={(r['arm'],r['mode'],r['interval_endpoints']):r for r in read('moving-domain.csv')}
pairs=read('frame-paired.csv'); routes=read('routes.csv'); stops=read('stop-camera.csv')
modes=('solo','tcp'); phs=('idle','moving','stopping'); arms=('baseline','fixed','deadline30','candidate')
labels={'baseline':'v0.1.335','fixed':'Repeating 30 ms','deadline30':'Deadline 30 ms','candidate':'Deadline 20 ms','solo':'Solo','tcp':'Three-seat','moving':'Walking','idle':'Idle','stopping':'Stopping'}
def f(v):return f'{float(v):.2f}'
def row(values):return '| '+' | '.join(map(str,values))+' |'
def table(head,values):
    return [row(head),row(['---']+['---:']*(len(head)-1)),*[row(r) for r in values]]
def value(r,column,default='n/a'):return r.get(column,default) if r else default
d=['# Physical House viewport pacing audit','',
    'Run 44002135665 used the Core30 i7-10700 and GTX 1660 SUPER. Each block ran solo and a rendered hunter with a remote hunter and human ghost on independent loopback connections. Every timer variant used the identical four-lane shader, original 110 ms gameplay timer, assets and 960×540 internal render target. v0.1.335 serves as the original game control.','',
    'The three experimental arms differ only in scheduling the visual callback. The control also predates v0.1.336 remote-hunter sprite preloading. The controller verified the candidate game source and normalized SHA-256 of the driver and every overlay. All 96 phase summaries were independently recomputed. Full authoritative network rounds ran on the .335 and deadline20 arms. The timed routes cover all four arms.','',
    'Each percentile pools intervals between successive distinct, nonnegative GL frames within a single trial and phase. Gaps across phases or processes are excluded. The target count records individual trials with a p95 no greater than 33.3 ms.','',
    *table(['Arm','Mode','Phase','Intervals','p50 ms','p95 ms','p99 ms','>100 ms','Trials on target'],[
        [labels[a],labels[m],labels[p],v['n'],f(v['p50_ms']),f(v['p95_ms']),f(v['p99_ms']),v['over100'],v['trial_p95_on_target']+'/4']
        for a in arms for m in modes for p in phs for v in [fps[a,m,p]]]),'',
    '## Matched comparisons','',
    *table(['Mode','Phase','.335 → fixed30','Fixed30 → deadline30','Fixed30 → deadline20','Deadline30 → deadline20'],[
        [labels[m],labels[p],*[next(r['pairs_lower_p95'] for r in pairs if (r['mode'],r['phase'],r['before_arm'],r['after_arm'])==(m,p,a,b))+'/4'
        for a,b in [('baseline','fixed'),('fixed','deadline30'),('fixed','candidate'),('deadline30','candidate')]]] for m in modes for p in phs]),'',
    'Rows count paired comparisons with a lower p95. See frame-paired.csv for median and range of the signed paired changes. The three-second walk spends time on both sides of the dome. The table below assigns an interval only when both endpoints lie on the indicated side. Four transition intervals per role and arm are retained separately in moving-domain.csv.','',
    *table(['Arm','Mode','Inside count','Inside p95 ms','Outside count','Outside p95 ms','Worst crossing ms'],[
        [labels[a],labels[m],domain[a,m,'inside']['n'],f(domain[a,m,'inside']['frame_p95_ms']),domain[a,m,'outside']['n'],
         f(domain[a,m,'outside']['frame_p95_ms']),f(domain[a,m,'crossing']['max_ms'])] for a in arms for m in modes]),'',
    '## Process CPU and state delivery','',
    'Process CPU core-equivalents equal the sum of process CPU time divided by elapsed wall time over the four trials. A value of 1.00 represents one fully occupied logical processor over that phase. CPU includes the renderer, game, host, TCP peers and other JVM threads. It excludes GPU execution and CPU time of other processes. Per-trial ranges and process CPU milliseconds per delivered frame are in cpu-pooled.csv.','',
    *table(['Arm','Mode','Idle cores','Walking cores','Stopping cores'],[
        [labels[a],labels[m],*[value(cpus.get((a,m,p)),'pooled_cores') for p in phs]] for a in arms for m in modes]),'',
    'Queue delay runs from the decoded STATE callback on the socket listener to its dispatch on the Swing event thread immediately before handling. Phases are assigned at arrival and include dispatches after a boundary. state-pooled.csv also gives a sensitivity check restricted to states with both endpoints inside the phase’s measured frame window. Keyboard input-to-display latency needs its own timestamps.','',
    *table(['Arm','Phase','STATE records','p50 ms','p95 ms','p99 ms','Maximum ms','>100 ms'],[
        [labels[a],labels[p],s['n'],f(s['queue_p50_ms']),f(s['queue_p95_ms']),f(s['queue_p99_ms']),f(s['queue_max_ms']),s['over100']]
        for a in arms for p in phs for s in [state[a,p]]]),'',
    f"All {len(routes)} routes crossed the dome boundary. All {len([r for r in routes if r['mode']=='tcp'])} TCP runs recorded authoritative movement and a visible peer. The final step covered {min(float(r['step_metres']) for r in stops):.3f}–{max(float(r['step_metres']) for r in stops):.3f} m. Each final stable pose had at least {min(int(r['stable_frames']) for r in stops)} frames. The raw ZIP SHA-256 is `{hashlib.sha256(raw.read_bytes()).hexdigest()}`. Recompute the audit with `python audit.py raw.zip output-dir`. The original frame CSVs, CPU boundary counters and incoming state timestamps remain in the worker archive.",'']
(out/'README.md').write_text('\n'.join(d))
