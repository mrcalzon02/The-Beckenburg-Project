"""Audit the House one-step stop and trace distinct-GL gaps around exact pose ordinals."""
import argparse
import csv
import io
import itertools
import json
from pathlib import Path
from zipfile import ZipFile

POSE = ("x", "eye", "z", "yaw", "pitch")


def report(raw, dest):
    dest.mkdir(exist_ok=True, parents=True)
    with ZipFile(raw) as z, (dest / "route-audit.csv").open("w", newline="") as audit_f, (dest / "pose-events.csv").open("w", newline="") as events_f:
        audit = csv.writer(audit_f)
        events = csv.writer(events_f)
        audit.writerow(("trial", "route", "rendered_hunters", "other_tcp_peers", "visible_peer_hunters", "accepted_steps", "max_travel_m", "walk_inside_frames", "walk_outside_frames", "final_hold_frames", "stop_inside_frames", "state_updates"))
        events.writerow(("trial", "phase", "panel_row", "pose_ordinal", "inside", "gl_frame", "ending_effects_ms", "gap_ms", "gap_phase_start", "distinct_frame", "near_sixth_on_final_hold"))
        manifest = json.loads(z.read("provenance.json"))
        arms = {"baseline", "prototype", "candidate"} if manifest["route"] == "sanctuary-stop" else {"baseline", "serial", "shader", "candidate"}
        expect = {f"pair-{n}-{mode}-{arm}" for n in range(1, 5) for mode in ("solo", "tcp") for arm in arms}
        actual = {name.split("/")[0] for name in z.namelist() if name.endswith("/frames.csv")}
        assert expect == actual, f"Missing {sorted(expect - actual)}. Unexpected {sorted(actual - expect)}"
        for trial in sorted(actual):
            rows = list(csv.DictReader(io.TextIOWrapper(z.open(trial + "/frames.csv"), encoding="utf-8-sig")))
            s = dict(line.split("=", 1) for line in z.read(trial + "/summary.txt").decode().splitlines() if "=" in line)
            tcp = "-tcp-" in trial
            states = (len(z.read(trial + "/state.csv").splitlines()) - 1) if tcp else 0
            assert int(s["rendered_hunters"]) == 1 and int(s["other_tcp_peers"]) == (2 if tcp else 0)
            assert not tcp or (int(s["visible_peer_hunters"]) > 0 and int(s["accepted_steps"]) > 0 and states > 0)
            moving = [r for r in rows if r["phase"] == "moving"]
            phases = [r["phase"] for r in rows]
            stopped = [r for r in rows if r["phase"] == "stopping"]
            groups = [list(group) for _, group in itertools.groupby(stopped, key=lambda r: tuple(r[k] for k in POSE))]
            final_start = len(rows) - len(groups[-1])
            assert phases[-1] == "stopping" and all(r["phase"] == "stopping" for r in rows[final_start:])
            inside = sum(r["inside_sanctuary"] == "true" for r in moving)
            assert 0 < inside < len(moving) and all(r["inside_sanctuary"] == "true" for r in stopped)
            audit.writerow((trial, manifest["route"], s["rendered_hunters"], s["other_tcp_peers"], s["visible_peer_hunters"], s["accepted_steps"], s["max_travel_metres"], inside, len(moving)-inside, len(groups[-1]), len(stopped), states))
            prev_t = prev_phase = last_pose = None
            ord_ = 0
            seen = set()
            for row_index, r in enumerate(rows):
                pose = tuple(r[k] for k in POSE)
                ord_ = ord_ + 1 if pose == last_pose else 1
                last_pose = pose
                fid, stamp = int(r["composited_gl_frame_id"]), int(r["time_ns"])
                distinct = fid >= 0 and fid not in seen
                gap = (stamp-prev_t)/1e6 if distinct and prev_t is not None else None
                selected = (r["phase"] == "stopping" and 0 <= row_index-final_start <= 11) or (r["phase"] in ("moving", "stopping") and gap is not None and gap > 100)
                if selected:
                    events.writerow((trial, r["phase"], row_index+1, ord_, r["inside_sanctuary"], fid, round(int(r["effects_ns"])/1e6, 3), "" if gap is None else round(gap, 3), prev_phase, distinct, r["phase"] == "stopping" and 0 <= row_index-final_start <= 11))
                if distinct:
                    seen.add(fid)
                    prev_t, prev_phase = stamp, r["phase"]
        for arm in ("baseline", "candidate"):
            report = z.read(arm + "-full-round.txt").decode()
            assert "Beckenburg full multiplayer round: PASS" in report and "both hunters received the winning settlement" in report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("raw", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report(args.raw, args.output)
