"""Validate the Core30 four-arm shading trial and study local TCP state delivery on the EDT."""
import argparse
import csv
import io
import json
import math
from collections import defaultdict
from pathlib import Path
from zipfile import ZipFile

PHASES=('idle','moving','stopping')
ARMS=('baseline','serial','shader','candidate')
SHAS={'serial_lf_sha256':'691a62b8a0519eb1ab1585969baa17af9bdbf12a0d50cd3464de84b46b503756',
      'shader_lf_sha256':'de95f3d3f4b5b415787094c48c95dbc0b526c5b651ca430b3dd114478c3a4401',
      'timer_lf_sha256':'2eb99d17142cd9a436a0aa51f7d84bdc053434661f51160e86d0b96ee6bf2416',
      'test_driver_lf_sha256':'9a435d1a75ecc7dcbbe0bc1e1b606c0dd4e605bce797262a703eb2c650d8048b'}

def rank(v,q):return sorted(v)[math.ceil(q*len(v))-1]
def rows(z,n):return list(csv.DictReader(io.TextIOWrapper(z.open(n),encoding='utf-8-sig')))
def stats(v):return [len(v),*[round(rank(v,q),3) for q in (.5,.95,.99,1)],sum(x>33.3 for x in v),sum(x>100 for x in v)]
def csvout(p,cols,data):
    with p.open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(cols.split())
        writer.writerows(data)
def collect(z,out,legacy=False):
    provenance=json.loads(z.read('provenance.json'))
    if legacy: arms=('baseline','prototype','candidate')
    else:
        assert provenance['route']=='sanctuary-shading' and provenance['controller_sha']=='4ad98efe62492a700c292a0ca04e158ad457f51e'
        assert provenance['revisions']=={'baseline':'dc7e497e74f3b0303ef72e1c7b17df764a3ebf7d','candidate':'1b0d74f66e8a183368ad75f4d3972b08827424b1'}
        manifest=json.loads(z.read('compiled-overlays.json'))
        for k,v in SHAS.items():assert manifest[k]==v,k
        arms=ARMS
    assert provenance['runner']=='OLD-CORE30-homebrew' and provenance['backend']=='gpu' and provenance['outer_pairs']==4
    paths=set(z.namelist())
    expected={f'pair-{pair}-{mode}-{arm}' for pair in range(1,5) for mode in ('solo','tcp') for arm in arms}
    assert expected=={n.split('/')[0] for n in paths if n.startswith('pair-')}
    for name in ['baseline','candidate']:
        report=z.read(name+'-full-round.txt').decode()
        assert all(s in report for s in ['full multiplayer round: PASS','spectral privacy enforced','evidence tools measured and shared','both hunters received the winning settlement','Post-round commands rejected']),name
        assert 'PASS Beckenburg full LAN' in z.read(name+'-e2e.log').decode()
    strata=defaultdict(list); stop_poses=[]
    groups=defaultdict(list); pressure=defaultdict(lambda:[0,0,0]); report=[]; audits=[]
    for t in sorted(expected):
        _,pair,mode,arm=t.split('-')
        for name in ['run.log','summary.txt','frames.csv','composited-intervals.csv']:
            assert f'{t}/{name}' in paths
        sf=f'{t}/state.csv';assert (sf in paths)==(mode=='tcp')
        summary=dict(x.split('=',1) for x in z.read(t+'/summary.txt').decode().splitlines())
        assert '1660 SUPER' in summary['renderer'] and float(summary['max_travel_metres'])>.1
        assert int(summary['rendered_hunters'])==1
        if mode=='tcp':assert int(summary['other_tcp_peers'])==2 and int(summary['visible_peer_hunters'])>=1 and int(summary['accepted_steps'])>0
        s=rows(z,sf) if mode=='tcp' else []
        ref={r['phase']:r for r in rows(z,t+'/composited-intervals.csv')}
        assert set(ref)==set(PHASES)
        frames=rows(z,t+'/frames.csv')
        assert all((int(r['width']),int(r['height']))==(960,540) for r in frames if r['phase'] in PHASES)
        moving=[r for r in frames if r['phase']=='moving']
        assert any(r['inside_sanctuary']=='false' for r in moving)
        for phase in PHASES:
            rs=[r for r in frames if r['phase']==phase]
            if phase=='stopping':assert all(r['inside_sanctuary']=='true' for r in rs)
            aligned=[];selected=[];last_id=None
            for r in rs:
                fid=int(r['composited_gl_frame_id'])
                if fid<0 or fid==last_id:continue
                aligned.append(int(r['time_ns']));selected.append(r)
                last_id=fid
            gaps=[(b-a)/1e6 for a,b in zip(aligned,aligned[1:])]
            assert min(gaps)>0
            if phase=='moving':
                for a,b,gap in zip(selected,selected[1:],gaps):
                    sa=a['inside_sanctuary'];sb=b['inside_sanctuary']
                    band='crossing' if sa!=sb else ('inside' if sb=='true' else 'outside')
                    strata[mode,arm,band].append(gap)
            if phase=='stopping':
                last=rs[-1];fields=('x','eye','z','yaw','pitch');pose=lambda r:tuple(r[k] for k in fields)
                i=len(rs)-1
                while i>0 and pose(rs[i-1])==pose(last):i-=1
                assert len(rs)-i>=12 and (int(last['time_ns'])-int(rs[i]['time_ns']))>=3_000_000_000
                before=[r for r in frames if r['phase']=='settling'][-1]
                step=math.hypot(*(float(last[k])-float(before[k]) for k in ('x','z')))
                assert .1<step<.5
                stop_poses.append([pair,mode,arm,*pose(last),round(step,4),len(rs)-i])
            p=ref[phase]
            assert len(gaps)==int(p['intervals'])
            for prob,k in [(0.5,'p50_ms'),(.95,'p95_ms'),(.99,'p99_ms')]: assert abs(rank(gaps,prob)-float(p[k]))<.00051,(t,phase,k)
            for threshold,k in [(33.3,'over_33_3_ms'),(50,'over_50_ms'),(100,'over_100_ms')]:
                assert int(p[k])==sum(x>threshold for x in gaps),(t,phase,k)
            t0=int(rs[0]['time_ns']);t1=int(rs[-1]['time_ns'])
            pr=pressure[(arm,mode,phase)]
            pr[0]+=sum(int(r['render_ns']) for r in rs[1:]);pr[1]+=t1-t0;pr[2]+=len(gaps)
            audits.append((pair,arm,mode,phase,len(rs),len(gaps),p['p95_ms'],summary['max_travel_metres']))
            if mode!='tcp':continue
            arrival=[r for r in s if r['phase']==phase]
            assert arrival
            assert all(int(r['edt_dispatch_ns'])>=int(r['client_received_ns']) for r in arrival)
            assert all(int(b['host_tick'])>=int(a['host_tick']) for a,b in zip(arrival,arrival[1:]))
            inside=[r for r in arrival if t0<=int(r['client_received_ns'])<=int(r['edt_dispatch_ns'])<=t1]
            for name,sub in [('arrival',arrival),('interior',inside)]:
                wait=[(int(r['edt_dispatch_ns'])-int(r['client_received_ns']))/1e6 for r in sub]
                assert wait
                groups[arm,phase,name]+=wait
                report.append([pair,arm,phase,name,*stats(wait)])
    repcols='pair arm phase sample_set n queue_p50_ms queue_p95_ms queue_p99_ms queue_max_ms over33_3 over100'
    csvout(out/'state-trials.csv',repcols,report)
    csvout(out/'state-pooled.csv',repcols.replace('pair ', 'trial_count ', 1),([4,*k,*stats(v)] for k,v in sorted(groups.items())))
    by_trial={(str(pair),arm,phase):v for pair,arm,phase,filter_name,*v in report if filter_name=='arrival'}
    contrasts=[('baseline','prototype'),('prototype','candidate')] if legacy else [('baseline','serial'),('serial','shader'),('shader','candidate')]
    paired=[]
    for first,second in contrasts:
        for phase in PHASES:
            for pair in map(str,range(1,5)):
                a=by_trial[pair,first,phase];b=by_trial[pair,second,phase]
                paired.append([pair,phase,first,second,a[0],b[0],a[2],b[2],round(b[2]-a[2],3),a[4],b[4]])
    csvout(out/'state-paired.csv','pair phase before_arm after_arm before_n after_n before_p95_ms after_p95_ms difference_ms before_max_ms after_max_ms',paired)
    csvout(out/'renderer-pressure.csv','arm mode phase rendered_pct_edt_wall delivered_fps',([*k,round(a/b*100,3),round(n*1e9/b,3)] for k,(a,b,n) in sorted(pressure.items())))
    csvout(out/'trial-audit.csv','pair arm mode phase rendered_count distinct_intervals p95_ms travel_m',audits)
    csvout(out/'moving-domain.csv','mode arm interval_endpoints n frame_p50_ms frame_p95_ms frame_p99_ms max_ms over33_3 over100',([*k,*stats(v)] for k,v in sorted(strata.items())))
    csvout(out/'stop-camera.csv','pair mode arm x eye z yaw pitch step_metres stable_frames',stop_poses)
    print(f'{len(expected)} trial directories; {len(audits)} trial phases matched stored count, quantiles and thresholds; {len(expected)//2} TCP state streams; two complete gameplay reports.')
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--rehearse-earlier-three-arm',action='store_true')
    opts=parser.parse_args();opts.output.mkdir(exist_ok=True,parents=True)
    with ZipFile(opts.zip) as z:collect(z,opts.output,opts.rehearse_earlier_three_arm)
if __name__=='__main__':main()
