# Independent audit of run 43993545950

The raw worker archive has SHA-256 `c66c3fbfaa43394f837a4ac68caa2377ef4c6e788e1c261efe342fe70e9745cf`. All 32 expected trials and all 16 TCP state streams were present. Recalculation matched all 96 per-trial phase summaries, including frame counts, p50, p95, p99 and all three thresholds. The final held pose was identical in all 32 trials after one 0.31 m step. Raw frames show 960×540 internal rendering on the physical NVIDIA GTX 1660 SUPER.

The four-lane shader improved p95 against serial shading in all 24 paired role/phase comparisons. Both use the same game JAR and unchanged 33 ms visual timer. Changing only the four-lane visual timer from 33 to 30 ms lowered p95 in 22 of 24 comparisons, including three of four walking runs for each mode. Four-lane/30 ms improved p95 against v0.1.335 in all 24 comparisons. None of the 24 candidate per-trial p95 measurements reached 33.3 ms. The best solo idle trial was 33.379 ms. Baseline TCP also lacks the v0.1.336 remote-hunter preload shared by the other three arms.

Walking out of the van sampled two different workloads. With four lanes and the 30 ms timer, intervals whose endpoints both remained inside the sanctuary had p95 of 72.873 ms solo and 60.100 ms over TCP. Fully outside intervals had p95 of 32.463 and 32.585 ms. Each trial contributed one boundary crossing. Those crossings peaked at 92.955 and 96.291 ms. Frame durations and render counts can change with timer cadence, so these distributions retain the observed sample counts.

## Local TCP state dispatch

The listener timestamps a decoded STATE record on the socket receive thread, posts an EDT task, and captures the second timestamp immediately before the panel handles that event. The following values are pooled nearest-rank receive-to-dispatch delays. They measure client queueing for authoritative game state. They exclude the time spent rendering after dispatch, keyboard-to-host transit and physical display presentation.

| Arm | Idle p95 ms | Walking p95 ms | Stopping p95 ms |
|---|---:|---:|---:|
| v0.1.335 | 23.910 | 32.575 | 42.335 |
| Serial cache, 33 ms timer | 6.342 | 8.845 | 6.769 |
| Four lanes, 33 ms timer | 6.017 | 8.379 | 5.337 |
| Four lanes, 30 ms timer | 5.266 | 4.259 | 6.721 |

Each arm had 160 idle STATE samples and 44 stopping samples. Walking had 123 baseline samples and 132 for each other arm. The 30 ms arm's maxima were 6.824, 55.770, and 7.430 ms in idle, walking and stopping. Its 132 walking samples include two over 33.3 ms and none over 100 ms. The baseline had three of 123 over 100 ms. The short walking and stopping sequences limit tail resolution. All-arm TCP gameplay remains a separate question from these queue durations. The .335 and final four-lane/30 ms headless network rounds reached the correct evidence, ritual and payouts. The two intermediate arms ran the real three-seat walking and stopping route.

`state-trials.csv` and `state-pooled.csv` include every state tagged with the phase when it arrived. The interior subset further requires both timestamps to fall between the first and last observed rendered frames in the phase. `state-paired.csv` uses the uncensored arrival set. `renderer-pressure.csv` divides all instrumented render durations ending within each phase interval by elapsed wall time. That yields 22.5–31.8% for the four-lane/30 ms arm, across the six role/phase combinations. CPU core utilization requires separate process counters.

Recompute locally with `python audit-shading.py raw.zip output-dir`.
